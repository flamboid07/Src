﻿Public Class CDU30
    Private Sub ENBID1TextBox_TextChanged(sender As Object, e As EventArgs)
        If ListBox1.Visible = True Then
            ListBox1.Visible = False
        Else
            ListBox1.Visible = True
        End If
    End Sub

    Private Sub ContextMenuStrip1_Opening(sender As Object, e As System.ComponentModel.CancelEventArgs)

    End Sub

    Private Sub ENBID1TextBox_MouseHover(sender As Object, e As EventArgs)

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub ENBID1TextBox_MouseLeave(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click_2(sender As Object, e As EventArgs) Handles Button3.Click
        If ListBox1.Visible = True Then
            ListBox1.Visible = False
        Else
            ListBox1.Visible = True
        End If
    End Sub

    Private Sub ENBID1_search_Click(sender As Object, e As EventArgs) Handles ENBID1_search.Click
        ''this is connected to the CMD1.pl script on the desktop..

        'get desktop folder path
        'Dim foldername = My.Computer.FileSystem.SpecialDirectories.Desktop
        ''here load up param as a string to send to perl script
        'Dim paramstring = Replace(selection, ",", " ")
        ''send command to perl script
        'Dim foldername = "c:\users\Arvind\Desktop"
        Dim foldername = "G:\source"

        Dim joinParams As String

        'eNodeId = ENBID1TextBox.Text
        ' Dim eNodeId As String = ListBox1.SelectedItem.ToString()
        Dim eNodeId As String = "614401"

        joinParams = cascadeID & " " & eNodeId

        Dim paramstring = joinParams.Insert(Len(joinParams), " ")

        ' For I = 0 To options.Count() - 1
        'Debug.Print(I & " = " & options(I))

        'Next
        Debug.Print("Value = " & joinParams)


        Dim oProcess As New Process()
        ''Dim oStartInfo As New ProcessStartInfo("perl.exe", foldername + "\CMD1.pl " + paramstring)
        ''Dim oStartInfo As New ProcessStartInfo("perl.exe", foldername + "\ReadCSVFile.pl " + paramstring)
        Dim oStartInfo As New ProcessStartInfo("perl.exe", foldername + "\read-csv-4.pl " + joinParams)
        oStartInfo.UseShellExecute = False
        oStartInfo.RedirectStandardOutput = True
        oProcess.StartInfo = oStartInfo
        oProcess.Start()

        Dim sOutput As String
        Using oStreamReader As System.IO.StreamReader = oProcess.StandardOutput
            sOutput = oStreamReader.ReadToEnd()
        End Using

        ''Dim records = Split(sOutput, vbNewLine)
        ''Dim records = Split(sOutput, vbCrLf)
        ''Dim twodim(1, 58) As String


        Dim ForNewline = Split(sOutput, vbNewLine)
        Dim record_cnt = ForNewline(0)
        Dim arr_index = record_cnt + 1

        Dim TddFlag As Boolean = False
        Dim FddFlag As Boolean = False



        Dim records = Split(sOutput, vbNewLine)
        Debug.Print("Record-Count" + record_cnt)

        Dim twodim(record_cnt, 58) As String

        Dim PRTFDD(9, 3) As String
        Dim PRTTDD(3, 3) As String
        Dim TgtTable(11, 11) As String
        Dim loop1 = 0
        Dim loop2 = 0

        '  For y = 0 To Split(sOutput, vbCrLf).Count - 1
        'For y = 0 To 1
        For y = 1 To arr_index - 1
            'System.Console.WriteLine("record=", record)
            Debug.Print("Record" + records(y))
            Dim fields = Split(records(y), " ")

            ' Check to see if site if TDD or FDD.  
            If fields(2) = "TDD" Then
                TddFlag = True
                'For loop1 = 0 To 2
                PRTTDD(loop1, 0) = fields(33)
                PRTTDD(loop1, 1) = fields(34)
                PRTTDD(loop1, 2) = fields(35)
                loop1 = loop1 + 1
                'Next
            End If

            If fields(2) = "FDD" Then
                FddFlag = True
                PRTFDD(loop2, 0) = fields(33)
                PRTFDD(loop2, 1) = fields(34)
                PRTFDD(loop2, 2) = fields(35)
                loop2 = loop2 + 1
            End If

            '7, 2, 21, 44, 45,46,47,33,34,39,40,41
            TgtTable(y - 1, 0) = fields(7)
            TgtTable(y - 1, 1) = fields(2)
            TgtTable(y - 1, 2) = fields(21)
            TgtTable(y - 1, 3) = fields(44)
            TgtTable(y - 1, 4) = fields(45)
            TgtTable(y - 1, 5) = fields(46)
            TgtTable(y - 1, 6) = fields(47)
            TgtTable(y - 1, 7) = fields(33)
            TgtTable(y - 1, 8) = fields(34)
            TgtTable(y - 1, 9) = fields(39)
            TgtTable(y - 1, 10) = fields(40)
            TgtTable(y - 1, 11) = fields(41)

            For x = 0 To Split(records(y), " ").Count - 1

                twodim(y, x) = fields(x)
                Debug.Print("field" + twodim(y, x))

            Next
        Next
        'TDD Audit
        If (TddFlag) Then
            ENBIdName.Text = twodim(1, 5)   'eNodeID-TDD
            textBox26.Text = twodim(1, 4)  'eNodeBName-TDD
            textBox27.Text = twodim(1, 5)  'eNodeBName-TDD
            textBox8.Text = twodim(1, 6)   'LSM Name
            textBox7.Text = twodim(1, 6)   'LSM IP
            textBox11.Text = twodim(1, 17)   'Cabinet
            textBox10.Text = twodim(1, 32)  ''TAC(Hex)

            textBox9.Text = twodim(1, 8)   'eNB OAM VLAN
            textBox6.Text = twodim(1, 12)    'eNB SB VLAN
            textBox5.Text = twodim(1, 16)    'TDD BH Port
            TextBox64.Text = twodim(1, 10)    'TDD BH Port
            TextBox65.Text = twodim(1, 11)    'TDD BH Port
            TextBox66.Text = twodim(1, 14)    'TDD BH Port
            TextBox67.Text = twodim(1, 15)    'TDD BH Port

            If PRTTDD(0, 0) <> "" Then
                TextBox56.Text = PRTTDD(0, 0) 'PCI Alpha
            End If
            If PRTTDD(0, 1) <> "" Then
                TextBox57.Text = PRTTDD(0, 1) 'Rach Alpha
            End If
            If PRTTDD(0, 2) <> "" Then
                TextBox58.Text = PRTTDD(0, 2) 'Tilt Alpha
            End If
            If PRTTDD(1, 0) <> "" Then
                TextBox60.Text = PRTTDD(1, 0) 'PCI Beta
            End If
            If PRTTDD(1, 1) <> "" Then
                TextBox61.Text = PRTTDD(1, 1) ' Rach Beta
            End If
            If PRTTDD(1, 2) <> "" Then
                TextBox62.Text = PRTTDD(1, 2) ' Tilt Beta
            End If
            If PRTTDD(2, 0) <> "" Then
                TextBox55.Text = PRTTDD(2, 0) 'PCI Gamma
            End If
            If PRTTDD(2, 1) <> "" Then
                TextBox59.Text = PRTTDD(2, 1) ' Rach Gamma
            End If
            If PRTTDD(2, 2) <> "" Then
                TextBox63.Text = PRTTDD(2, 2) 'Tilt Gamma
            End If

        End If

        'FDD Audit
        If (FddFlag) Then
            textBox34.Text = twodim(2, 18)    'eNodeB Name'
            textBox35.Text = twodim(2, 4)   'eNodeB ID'
            textBox30.Text = twodim(2, 20)   'LSM Name
            textBox31.Text = twodim(2, 6)    'LSM IP
            textBox37.Text = twodim(2, 17)   'Cabinet
            textBox36.Text = twodim(2, 32)   'TAC(Hex)

            textBox40.Text = twodim(2, 8)   'eNB OAL VLAN
            textBox39.Text = twodim(2, 12)  'eNB SB VLAN
            textBox38.Text = twodim(2, 16) 'FDD BH Port

            TextBox51.Text = twodim(2, 10)    'TDD BH Port
            TextBox52.Text = twodim(2, 11)    'TDD BH Port
            TextBox53.Text = twodim(2, 14)    'TDD BH Port
            TextBox54.Text = twodim(2, 15)    'TDD BH Port

            If PRTFDD(0, 0) <> "" Then
                TextBox42.Text = PRTFDD(0, 0) 'PCI Alpha
            End If
            If PRTFDD(0, 1) <> "" Then
                TextBox43.Text = PRTFDD(0, 1) 'Rach Alpha
            End If
            If PRTFDD(0, 2) <> "" Then
                TextBox44.Text = PRTFDD(0, 2) 'Tilt Alpha
            End If
            If PRTFDD(1, 0) <> "" Then
                TextBox46.Text = PRTFDD(1, 0) 'PCI Beta
            End If
            If PRTFDD(1, 1) <> "" Then
                TextBox47.Text = PRTFDD(1, 1) ' Rach Beta
            End If
            If PRTFDD(1, 2) <> "" Then
                TextBox48.Text = PRTFDD(1, 2) ' Tilt Beta
            End If
            If PRTFDD(2, 0) <> "" Then
                TextBox50.Text = PRTFDD(2, 0) 'PCI Gamma
            End If
            If PRTFDD(2, 1) <> "" Then
                TextBox45.Text = PRTFDD(2, 1) ' Rach Gamma
            End If
            If PRTFDD(2, 2) <> "" Then
                TextBox49.Text = PRTFDD(2, 2) 'Tilt Gamma
            End If

        End If

        'CDU30 Audit
        ENodeBNameTextbox.Text = twodim(1, 10)
        ENodeBIdTextbox.Text = twodim(1, 10)
        LsmNameTextbox.Text = twodim(1, 20)
        LsmrIpTextbox.Text = twodim(1, 10)
        CabinetTextBox.Text = twodim(1, 31)
        TacTextBox.Text = twodim(1, 32)
        textBox2.Text = twodim(1, 24) 'CSR OAM IP
        textBox3.Text = twodim(1, 25) 'MMBS OAM IP
        textBox17.Text = twodim(1, 28) 'CSR S&B IP
        textBox15.Text = twodim(1, 29) 'CSR S&B IP
        textBox19.Text = twodim(1, 22) 'CDU30 OAM Vlan
        textBox18.Text = twodim(1, 26) ' CDU30 S&B Vlan
        textBox21.Text = twodim(1, 30) 'CDU30 BH POrt 

        Dim TB As TextBox
        Dim i As Integer = 0
        Dim j As Integer = 0
        Dim count As Integer = 0


        'For intermed As Int32 = 116 To 258

        'TB = Me.Controls("textBox" & intermed)
        'If (TgtTable(i, count) <> "") Then
        'TB.Text = TgtTable(i, count)
        'End If
        'If (count Mod 11 = 0) Then
        'i = i + 1
        'count = 0
        'End If
        'count = count + 1
        'Next
        If TgtTable(0, 0) <> "" Then
            TextBox116.Text = TgtTable(0, 0)
        End If
        If TgtTable(0, 1) <> "" Then
            TextBox117.Text = TgtTable(0, 1)
        End If
        If TgtTable(0, 2) <> "" Then
            TextBox118.Text = TgtTable(0, 2)
        End If
        If TgtTable(0, 3) <> "" Then
            TextBox119.Text = TgtTable(0, 3)
        End If
        If TgtTable(0, 4) <> "" Then
            TextBox120.Text = TgtTable(0, 4)
        End If
        If TgtTable(0, 5) <> "" Then
            TextBox121.Text = TgtTable(0, 5)
        End If
        If TgtTable(0, 6) <> "" Then
            TextBox122.Text = TgtTable(0, 6)
        End If
        If TgtTable(0, 7) <> "" Then
            TextBox123.Text = TgtTable(0, 7)
        End If
        If TgtTable(0, 8) <> "" Then
            TextBox124.Text = TgtTable(0, 8)
        End If
        If TgtTable(0, 9) <> "" Then
            TextBox125.Text = TgtTable(0, 9)
        End If
        If TgtTable(0, 10) <> "" Then
            TextBox126.Text = TgtTable(0, 10)
        End If
        If TgtTable(0, 11) <> "" Then
            TextBox127.Text = TgtTable(0, 11)
        End If

        '1
        If TgtTable(0, 0) <> "" Then
            TextBox128.Text = TgtTable(0, 0)
        End If
        If TgtTable(1, 1) <> "" Then
            TextBox129.Text = TgtTable(1, 1)
        End If
        If TgtTable(1, 2) <> "" Then
            TextBox130.Text = TgtTable(1, 2)
        End If
        If TgtTable(1, 3) <> "" Then
            TextBox131.Text = TgtTable(1, 3)
        End If
        If TgtTable(1, 4) <> "" Then
            TextBox132.Text = TgtTable(1, 4)
        End If
        If TgtTable(1, 5) <> "" Then
            TextBox133.Text = TgtTable(1, 5)
        End If
        If TgtTable(1, 6) <> "" Then
            TextBox134.Text = TgtTable(1, 6)
        End If
        If TgtTable(1, 7) <> "" Then
            TextBox135.Text = TgtTable(1, 7)
        End If
        If TgtTable(1, 8) <> "" Then
            TextBox136.Text = TgtTable(1, 8)
        End If
        If TgtTable(1, 9) <> "" Then
            TextBox137.Text = TgtTable(1, 9)
        End If
        If TgtTable(1, 10) <> "" Then
            TextBox138.Text = TgtTable(1, 10)
        End If
        If TgtTable(1, 11) <> "" Then
            TextBox139.Text = TgtTable(1, 11)
        End If
        '2222
        If TgtTable(2, 0) <> "" Then
            TextBox140.Text = TgtTable(2, 0)
        End If
        If TgtTable(2, 1) <> "" Then
            TextBox141.Text = TgtTable(2, 1)
        End If
        If TgtTable(2, 2) <> "" Then
            TextBox142.Text = TgtTable(2, 2)
        End If
        If TgtTable(2, 3) <> "" Then
            TextBox143.Text = TgtTable(2, 3)
        End If
        If TgtTable(2, 4) <> "" Then
            TextBox144.Text = TgtTable(2, 4)
        End If
        If TgtTable(2, 5) <> "" Then
            TextBox145.Text = TgtTable(2, 5)
        End If
        If TgtTable(2, 6) <> "" Then
            TextBox146.Text = TgtTable(2, 6)
        End If
        If TgtTable(2, 7) <> "" Then
            TextBox147.Text = TgtTable(2, 7)
        End If
        If TgtTable(2, 8) <> "" Then
            TextBox148.Text = TgtTable(2, 8)
        End If
        If TgtTable(2, 9) <> "" Then
            TextBox149.Text = TgtTable(2, 9)
        End If
        If TgtTable(2, 10) <> "" Then
            TextBox150.Text = TgtTable(2, 10)
        End If
        If TgtTable(2, 11) <> "" Then
            TextBox151.Text = TgtTable(2, 11)
        End If

        '3333333
        If TgtTable(3, 0) <> "" Then
            TextBox152.Text = TgtTable(3, 0)
        End If
        If TgtTable(3, 1) <> "" Then
            TextBox153.Text = TgtTable(3, 1)
        End If
        If TgtTable(3, 2) <> "" Then
            TextBox154.Text = TgtTable(3, 2)
        End If
        If TgtTable(3, 3) <> "" Then
            TextBox155.Text = TgtTable(3, 3)
        End If
        If TgtTable(3, 4) <> "" Then
            TextBox156.Text = TgtTable(3, 4)
        End If
        If TgtTable(3, 5) <> "" Then
            TextBox157.Text = TgtTable(3, 5)
        End If
        If TgtTable(3, 6) <> "" Then
            TextBox158.Text = TgtTable(3, 6)
        End If
        If TgtTable(3, 7) <> "" Then
            TextBox159.Text = TgtTable(3, 7)
        End If
        If TgtTable(3, 8) <> "" Then
            TextBox160.Text = TgtTable(3, 8)
        End If
        If TgtTable(3, 9) <> "" Then
            TextBox161.Text = TgtTable(3, 9)
        End If
        If TgtTable(3, 10) <> "" Then
            TextBox162.Text = TgtTable(3, 10)
        End If
        If TgtTable(3, 11) <> "" Then
            TextBox163.Text = TgtTable(3, 11)
        End If

        '4
        If TgtTable(4, 0) <> "" Then
            TextBox164.Text = TgtTable(4, 0)
        End If
        If TgtTable(4, 1) <> "" Then
            TextBox165.Text = TgtTable(4, 1)
        End If
        If TgtTable(4, 2) <> "" Then
            TextBox166.Text = TgtTable(4, 2)
        End If
        If TgtTable(4, 3) <> "" Then
            TextBox167.Text = TgtTable(4, 3)
        End If
        If TgtTable(4, 4) <> "" Then
            TextBox168.Text = TgtTable(4, 4)
        End If
        If TgtTable(4, 5) <> "" Then
            TextBox169.Text = TgtTable(4, 5)
        End If
        If TgtTable(4, 6) <> "" Then
            TextBox170.Text = TgtTable(4, 6)
        End If
        If TgtTable(4, 7) <> "" Then
            TextBox171.Text = TgtTable(4, 7)
        End If
        If TgtTable(4, 8) <> "" Then
            TextBox172.Text = TgtTable(4, 8)
        End If
        If TgtTable(4, 9) <> "" Then
            TextBox173.Text = TgtTable(4, 9)
        End If
        If TgtTable(4, 10) <> "" Then
            TextBox174.Text = TgtTable(4, 10)
        End If
        If TgtTable(4, 11) <> "" Then
            TextBox175.Text = TgtTable(4, 11)
        End If
        '55555
        If TgtTable(5, 0) <> "" Then
            TextBox176.Text = TgtTable(5, 0)
        End If
        If TgtTable(5, 1) <> "" Then
            TextBox177.Text = TgtTable(5, 1)
        End If
        If TgtTable(5, 2) <> "" Then
            TextBox178.Text = TgtTable(5, 2)
        End If
        If TgtTable(5, 3) <> "" Then
            TextBox179.Text = TgtTable(5, 3)
        End If
        If TgtTable(5, 4) <> "" Then
            TextBox180.Text = TgtTable(5, 4)
        End If
        If TgtTable(5, 5) <> "" Then
            TextBox181.Text = TgtTable(5, 5)
        End If
        If TgtTable(5, 6) <> "" Then
            TextBox182.Text = TgtTable(5, 6)
        End If
        If TgtTable(5, 7) <> "" Then
            TextBox183.Text = TgtTable(5, 7)
        End If
        If TgtTable(5, 8) <> "" Then
            TextBox184.Text = TgtTable(5, 8)
        End If
        If TgtTable(5, 9) <> "" Then
            TextBox185.Text = TgtTable(5, 9)
        End If
        If TgtTable(5, 10) <> "" Then
            TextBox186.Text = TgtTable(5, 10)
        End If
        If TgtTable(5, 11) <> "" Then
            TextBox187.Text = TgtTable(5, 11)
        End If
        '66666

        If TgtTable(6, 0) <> "" Then
            TextBox189.Text = TgtTable(6, 0)
        End If
        If TgtTable(6, 1) <> "" Then
            TextBox190.Text = TgtTable(6, 1)
        End If
        If TgtTable(6, 2) <> "" Then
            TextBox191.Text = TgtTable(6, 2)
        End If
        If TgtTable(6, 3) <> "" Then
            TextBox192.Text = TgtTable(6, 3)
        End If
        If TgtTable(6, 4) <> "" Then
            TextBox193.Text = TgtTable(6, 4)
        End If
        If TgtTable(6, 5) <> "" Then
            TextBox194.Text = TgtTable(6, 5)
        End If
        If TgtTable(6, 6) <> "" Then
            TextBox195.Text = TgtTable(6, 6)
        End If
        If TgtTable(6, 7) <> "" Then
            TextBox196.Text = TgtTable(6, 7)
        End If
        If TgtTable(6, 8) <> "" Then
            TextBox197.Text = TgtTable(6, 8)
        End If
        If TgtTable(6, 9) <> "" Then
            TextBox198.Text = TgtTable(6, 9)
        End If
        If TgtTable(6, 10) <> "" Then
            TextBox199.Text = TgtTable(6, 10)
        End If
        If TgtTable(6, 11) <> "" Then
            TextBox200.Text = TgtTable(6, 11)
        End If

        '777777

        If TgtTable(7, 0) <> "" Then
            TextBox201.Text = TgtTable(7, 0)
        End If
        If TgtTable(7, 1) <> "" Then
            TextBox202.Text = TgtTable(7, 1)
        End If
        If TgtTable(7, 2) <> "" Then
            TextBox203.Text = TgtTable(7, 2)
        End If
        If TgtTable(7, 3) <> "" Then
            TextBox204.Text = TgtTable(7, 3)
        End If
        If TgtTable(7, 4) <> "" Then
            TextBox205.Text = TgtTable(7, 4)
        End If
        If TgtTable(7, 5) <> "" Then
            TextBox206.Text = TgtTable(7, 5)
        End If
        If TgtTable(7, 6) <> "" Then
            TextBox207.Text = TgtTable(7, 6)
        End If
        If TgtTable(7, 7) <> "" Then
            TextBox208.Text = TgtTable(7, 7)
        End If
        If TgtTable(7, 8) <> "" Then
            TextBox209.Text = TgtTable(7, 8)
        End If
        If TgtTable(7, 9) <> "" Then
            TextBox210.Text = TgtTable(7, 9)
        End If
        If TgtTable(7, 10) <> "" Then
            TextBox211.Text = TgtTable(7, 10)
        End If
        If TgtTable(7, 11) <> "" Then
            TextBox212.Text = TgtTable(7, 11)
        End If

        If TgtTable(8, 0) <> "" Then
            TextBox213.Text = TgtTable(8, 0)
        End If
        If TgtTable(8, 1) <> "" Then
            TextBox214.Text = TgtTable(8, 1)
        End If
        If TgtTable(8, 2) <> "" Then
            TextBox215.Text = TgtTable(8, 2)
        End If
        If TgtTable(8, 3) <> "" Then
            TextBox216.Text = TgtTable(8, 3)
        End If
        If TgtTable(8, 4) <> "" Then
            TextBox217.Text = TgtTable(8, 4)
        End If
        If TgtTable(8, 5) <> "" Then
            TextBox218.Text = TgtTable(8, 5)
        End If
        If TgtTable(8, 6) <> "" Then
            TextBox219.Text = TgtTable(8, 6)
        End If
        If TgtTable(8, 7) <> "" Then
            TextBox220.Text = TgtTable(8, 7)
        End If
        If TgtTable(8, 8) <> "" Then
            TextBox221.Text = TgtTable(8, 8)
        End If
        If TgtTable(8, 9) <> "" Then
            TextBox222.Text = TgtTable(8, 9)
        End If
        If TgtTable(8, 10) <> "" Then
            TextBox223.Text = TgtTable(8, 10)
        End If
        If TgtTable(8, 11) <> "" Then
            TextBox224.Text = TgtTable(8, 11)
        End If

        '''99999
        If TgtTable(9, 0) <> "" Then
            TextBox225.Text = TgtTable(9, 0)
        End If
        If TgtTable(9, 1) <> "" Then
            TextBox226.Text = TgtTable(9, 1)
        End If
        If TgtTable(9, 2) <> "" Then
            TextBox227.Text = TgtTable(9, 2)
        End If
        If TgtTable(9, 3) <> "" Then
            TextBox228.Text = TgtTable(9, 3)
        End If
        If TgtTable(9, 4) <> "" Then
            TextBox229.Text = TgtTable(9, 4)
        End If
        If TgtTable(9, 5) <> "" Then
            TextBox230.Text = TgtTable(9, 5)
        End If
        If TgtTable(9, 6) <> "" Then
            TextBox231.Text = TgtTable(9, 6)
        End If
        If TgtTable(9, 7) <> "" Then
            TextBox232.Text = TgtTable(9, 7)
        End If
        If TgtTable(9, 8) <> "" Then
            TextBox233.Text = TgtTable(9, 8)
        End If
        If TgtTable(9, 9) <> "" Then
            TextBox234.Text = TgtTable(9, 9)
        End If
        If TgtTable(9, 10) <> "" Then
            TextBox235.Text = TgtTable(9, 10)
        End If
        If TgtTable(9, 11) <> "" Then
            TextBox236.Text = TgtTable(9, 11)
        End If

        '''10101010
        If TgtTable(10, 0) <> "" Then
            TextBox237.Text = TgtTable(10, 0)
        End If
        If TgtTable(10, 1) <> "" Then
            TextBox238.Text = TgtTable(10, 1)
        End If
        If TgtTable(10, 2) <> "" Then
            TextBox239.Text = TgtTable(10, 2)
        End If
        If TgtTable(10, 3) <> "" Then
            TextBox240.Text = TgtTable(10, 3)
        End If
        If TgtTable(10, 4) <> "" Then
            TextBox241.Text = TgtTable(10, 4)
        End If
        If TgtTable(10, 5) <> "" Then
            TextBox242.Text = TgtTable(10, 5)
        End If
        If TgtTable(10, 6) <> "" Then
            TextBox243.Text = TgtTable(10, 6)
        End If
        If TgtTable(10, 7) <> "" Then
            TextBox244.Text = TgtTable(10, 7)
        End If
        If TgtTable(10, 8) <> "" Then
            TextBox245.Text = TgtTable(10, 8)
        End If
        If TgtTable(10, 9) <> "" Then
            TextBox246.Text = TgtTable(10, 9)
        End If
        If TgtTable(10, 10) <> "" Then
            TextBox247.Text = TgtTable(10, 10)
        End If
        If TgtTable(10, 11) <> "" Then
            TextBox248.Text = TgtTable(10, 11)
        End If

        '''11111111
        If TgtTable(11, 0) <> "" Then
            TextBox249.Text = TgtTable(11, 0)
        End If
        If TgtTable(11, 1) <> "" Then
            TextBox250.Text = TgtTable(11, 1)
        End If
        If TgtTable(11, 2) <> "" Then
            TextBox251.Text = TgtTable(11, 2)
        End If
        If TgtTable(11, 3) <> "" Then
            TextBox252.Text = TgtTable(11, 3)
        End If
        If TgtTable(11, 4) <> "" Then
            TextBox253.Text = TgtTable(11, 4)
        End If
        If TgtTable(11, 5) <> "" Then
            TextBox254.Text = TgtTable(11, 5)
        End If
        If TgtTable(11, 6) <> "" Then
            TextBox255.Text = TgtTable(11, 6)
        End If
        If TgtTable(11, 7) <> "" Then
            TextBox256.Text = TgtTable(11, 7)
        End If
        If TgtTable(11, 8) <> "" Then
            TextBox257.Text = TgtTable(11, 8)
        End If
        If TgtTable(11, 9) <> "" Then
            TextBox258.Text = TgtTable(11, 9)
        End If
        If TgtTable(11, 10) <> "" Then
            TextBox259.Text = TgtTable(11, 10)
        End If
        If TgtTable(11, 11) <> "" Then
            TextBox189.Text = TgtTable(11, 11)
        End If

    End Sub



    Private Sub TextBox52_TextChanged(sender As Object, e As EventArgs) Handles TextBox52.TextChanged

    End Sub

    Private Sub TextBox57_TextChanged(sender As Object, e As EventArgs) Handles TextBox57.TextChanged

    End Sub

    Private Sub TargetPanel_Paint(sender As Object, e As PaintEventArgs) Handles TargetPanel.Paint

    End Sub
End Class