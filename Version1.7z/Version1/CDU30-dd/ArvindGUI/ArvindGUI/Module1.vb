﻿Module Module1
    ''these are the global variables
    Public consolidated As Collection
    Public options As Collection
    Public selection
    Public cascadeID
End Module
