﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TDD
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox21 = New System.Windows.Forms.TextBox()
        Me.label10 = New System.Windows.Forms.Label()
        Me.tableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox18 = New System.Windows.Forms.TextBox()
        Me.textBox19 = New System.Windows.Forms.TextBox()
        Me.label8 = New System.Windows.Forms.Label()
        Me.label7 = New System.Windows.Forms.Label()
        Me.tableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox6 = New System.Windows.Forms.TextBox()
        Me.textBox5 = New System.Windows.Forms.TextBox()
        Me.label6 = New System.Windows.Forms.Label()
        Me.label5 = New System.Windows.Forms.Label()
        Me.name_id = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox22 = New System.Windows.Forms.TextBox()
        Me.textBox20 = New System.Windows.Forms.TextBox()
        Me.textBox9 = New System.Windows.Forms.TextBox()
        Me.textBox10 = New System.Windows.Forms.TextBox()
        Me.TddLabel = New System.Windows.Forms.TextBox()
        Me.tableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox24 = New System.Windows.Forms.TextBox()
        Me.textBox23 = New System.Windows.Forms.TextBox()
        Me.textBox8 = New System.Windows.Forms.TextBox()
        Me.textBox7 = New System.Windows.Forms.TextBox()
        Me.button1 = New System.Windows.Forms.Button()
        Me.ENBIdTextBox = New System.Windows.Forms.TextBox()
        Me.tableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.label31 = New System.Windows.Forms.Label()
        Me.label32 = New System.Windows.Forms.Label()
        Me.label33 = New System.Windows.Forms.Label()
        Me.label34 = New System.Windows.Forms.Label()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.label13 = New System.Windows.Forms.Label()
        Me.tableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.label9 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label12 = New System.Windows.Forms.Label()
        Me.label11 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.tableLayoutPanel5.SuspendLayout()
        Me.tableLayoutPanel4.SuspendLayout()
        Me.tableLayoutPanel2.SuspendLayout()
        Me.name_id.SuspendLayout()
        Me.tableLayoutPanel3.SuspendLayout()
        Me.tableLayoutPanel6.SuspendLayout()
        Me.tableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tableLayoutPanel5
        '
        Me.tableLayoutPanel5.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel5.ColumnCount = 1
        Me.tableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.27027!))
        Me.tableLayoutPanel5.Controls.Add(Me.textBox21, 0, 1)
        Me.tableLayoutPanel5.Controls.Add(Me.label10, 0, 0)
        Me.tableLayoutPanel5.Location = New System.Drawing.Point(1093, 323)
        Me.tableLayoutPanel5.Name = "tableLayoutPanel5"
        Me.tableLayoutPanel5.RowCount = 2
        Me.tableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.tableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.tableLayoutPanel5.Size = New System.Drawing.Size(171, 144)
        Me.tableLayoutPanel5.TabIndex = 50
        '
        'textBox21
        '
        Me.textBox21.Location = New System.Drawing.Point(6, 90)
        Me.textBox21.Multiline = True
        Me.textBox21.Name = "textBox21"
        Me.textBox21.Size = New System.Drawing.Size(159, 48)
        Me.textBox21.TabIndex = 16
        '
        'label10
        '
        Me.label10.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label10.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label10.Location = New System.Drawing.Point(6, 5)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(159, 77)
        Me.label10.TabIndex = 23
        Me.label10.Text = "CDU30 BH" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Port"
        Me.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tableLayoutPanel4
        '
        Me.tableLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel4.ColumnCount = 2
        Me.tableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.27027!))
        Me.tableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.72973!))
        Me.tableLayoutPanel4.Controls.Add(Me.textBox18, 1, 1)
        Me.tableLayoutPanel4.Controls.Add(Me.textBox19, 0, 1)
        Me.tableLayoutPanel4.Controls.Add(Me.label8, 1, 0)
        Me.tableLayoutPanel4.Controls.Add(Me.label7, 0, 0)
        Me.tableLayoutPanel4.Location = New System.Drawing.Point(705, 325)
        Me.tableLayoutPanel4.Name = "tableLayoutPanel4"
        Me.tableLayoutPanel4.RowCount = 2
        Me.tableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.tableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.tableLayoutPanel4.Size = New System.Drawing.Size(373, 144)
        Me.tableLayoutPanel4.TabIndex = 49
        '
        'textBox18
        '
        Me.textBox18.Location = New System.Drawing.Point(191, 90)
        Me.textBox18.Multiline = True
        Me.textBox18.Name = "textBox18"
        Me.textBox18.Size = New System.Drawing.Size(176, 48)
        Me.textBox18.TabIndex = 16
        '
        'textBox19
        '
        Me.textBox19.Location = New System.Drawing.Point(6, 90)
        Me.textBox19.Multiline = True
        Me.textBox19.Name = "textBox19"
        Me.textBox19.Size = New System.Drawing.Size(176, 48)
        Me.textBox19.TabIndex = 16
        '
        'label8
        '
        Me.label8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label8.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label8.Location = New System.Drawing.Point(192, 5)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(174, 77)
        Me.label8.TabIndex = 3
        Me.label8.Text = "eNB S&B" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "VLAN"
        Me.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label7
        '
        Me.label7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label7.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label7.Location = New System.Drawing.Point(7, 5)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(174, 77)
        Me.label7.TabIndex = 23
        Me.label7.Text = "eNB OAM" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "VLAN"
        Me.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tableLayoutPanel2
        '
        Me.tableLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel2.ColumnCount = 2
        Me.tableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel2.Controls.Add(Me.textBox6, 1, 1)
        Me.tableLayoutPanel2.Controls.Add(Me.textBox5, 0, 1)
        Me.tableLayoutPanel2.Controls.Add(Me.label6, 1, 0)
        Me.tableLayoutPanel2.Controls.Add(Me.label5, 0, 0)
        Me.tableLayoutPanel2.Location = New System.Drawing.Point(92, 372)
        Me.tableLayoutPanel2.Name = "tableLayoutPanel2"
        Me.tableLayoutPanel2.RowCount = 2
        Me.tableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tableLayoutPanel2.Size = New System.Drawing.Size(452, 97)
        Me.tableLayoutPanel2.TabIndex = 51
        '
        'textBox6
        '
        Me.textBox6.Location = New System.Drawing.Point(230, 53)
        Me.textBox6.Multiline = True
        Me.textBox6.Name = "textBox6"
        Me.textBox6.Size = New System.Drawing.Size(216, 38)
        Me.textBox6.TabIndex = 16
        '
        'textBox5
        '
        Me.textBox5.Location = New System.Drawing.Point(6, 53)
        Me.textBox5.Multiline = True
        Me.textBox5.Name = "textBox5"
        Me.textBox5.Size = New System.Drawing.Size(215, 38)
        Me.textBox5.TabIndex = 16
        '
        'label6
        '
        Me.label6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label6.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label6.Location = New System.Drawing.Point(230, 6)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(215, 38)
        Me.label6.TabIndex = 3
        Me.label6.Text = "TAC(Hex)"
        Me.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label5
        '
        Me.label5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label5.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label5.Location = New System.Drawing.Point(6, 6)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(215, 38)
        Me.label5.TabIndex = 2
        Me.label5.Text = "Cabinet"
        Me.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'name_id
        '
        Me.name_id.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.name_id.BackColor = System.Drawing.Color.Transparent
        Me.name_id.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.name_id.ColumnCount = 2
        Me.name_id.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.name_id.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.name_id.Controls.Add(Me.textBox22, 0, 0)
        Me.name_id.Controls.Add(Me.textBox20, 0, 1)
        Me.name_id.Controls.Add(Me.textBox9, 1, 0)
        Me.name_id.Controls.Add(Me.textBox10, 1, 1)
        Me.name_id.Location = New System.Drawing.Point(92, 99)
        Me.name_id.Name = "name_id"
        Me.name_id.RowCount = 2
        Me.name_id.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.name_id.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.name_id.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.name_id.Size = New System.Drawing.Size(548, 82)
        Me.name_id.TabIndex = 43
        '
        'textBox22
        '
        Me.textBox22.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox22.Location = New System.Drawing.Point(6, 6)
        Me.textBox22.Multiline = True
        Me.textBox22.Name = "textBox22"
        Me.textBox22.Size = New System.Drawing.Size(263, 30)
        Me.textBox22.TabIndex = 27
        Me.textBox22.Text = "eNodeB Name"
        Me.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox20
        '
        Me.textBox20.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox20.Location = New System.Drawing.Point(6, 45)
        Me.textBox20.Multiline = True
        Me.textBox20.Name = "textBox20"
        Me.textBox20.Size = New System.Drawing.Size(263, 31)
        Me.textBox20.TabIndex = 26
        Me.textBox20.Text = "eNodeB ID"
        Me.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox9
        '
        Me.textBox9.Location = New System.Drawing.Point(278, 6)
        Me.textBox9.Multiline = True
        Me.textBox9.Name = "textBox9"
        Me.textBox9.Size = New System.Drawing.Size(264, 25)
        Me.textBox9.TabIndex = 16
        '
        'textBox10
        '
        Me.textBox10.Location = New System.Drawing.Point(278, 45)
        Me.textBox10.Multiline = True
        Me.textBox10.Name = "textBox10"
        Me.textBox10.Size = New System.Drawing.Size(264, 25)
        Me.textBox10.TabIndex = 16
        '
        'TddLabel
        '
        Me.TddLabel.BackColor = System.Drawing.Color.White
        Me.TddLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TddLabel.Location = New System.Drawing.Point(10, 19)
        Me.TddLabel.Multiline = True
        Me.TddLabel.Name = "TddLabel"
        Me.TddLabel.Size = New System.Drawing.Size(59, 606)
        Me.TddLabel.TabIndex = 41
        Me.TddLabel.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "T" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "D" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "D"
        Me.TddLabel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tableLayoutPanel3
        '
        Me.tableLayoutPanel3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel3.ColumnCount = 2
        Me.tableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel3.Controls.Add(Me.textBox24, 0, 1)
        Me.tableLayoutPanel3.Controls.Add(Me.textBox23, 0, 0)
        Me.tableLayoutPanel3.Controls.Add(Me.textBox8, 1, 0)
        Me.tableLayoutPanel3.Controls.Add(Me.textBox7, 1, 1)
        Me.tableLayoutPanel3.Location = New System.Drawing.Point(92, 198)
        Me.tableLayoutPanel3.Name = "tableLayoutPanel3"
        Me.tableLayoutPanel3.RowCount = 2
        Me.tableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tableLayoutPanel3.Size = New System.Drawing.Size(548, 84)
        Me.tableLayoutPanel3.TabIndex = 44
        '
        'textBox24
        '
        Me.textBox24.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox24.Location = New System.Drawing.Point(6, 46)
        Me.textBox24.Multiline = True
        Me.textBox24.Name = "textBox24"
        Me.textBox24.Size = New System.Drawing.Size(263, 32)
        Me.textBox24.TabIndex = 28
        Me.textBox24.Text = "LSMR IP"
        Me.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox23
        '
        Me.textBox23.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox23.Location = New System.Drawing.Point(6, 6)
        Me.textBox23.Multiline = True
        Me.textBox23.Name = "textBox23"
        Me.textBox23.Size = New System.Drawing.Size(263, 31)
        Me.textBox23.TabIndex = 29
        Me.textBox23.Text = "LSM Name"
        Me.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox8
        '
        Me.textBox8.Location = New System.Drawing.Point(278, 6)
        Me.textBox8.Name = "textBox8"
        Me.textBox8.Size = New System.Drawing.Size(264, 26)
        Me.textBox8.TabIndex = 16
        '
        'textBox7
        '
        Me.textBox7.Location = New System.Drawing.Point(278, 46)
        Me.textBox7.Name = "textBox7"
        Me.textBox7.Size = New System.Drawing.Size(264, 26)
        Me.textBox7.TabIndex = 16
        '
        'button1
        '
        Me.button1.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.button1.Location = New System.Drawing.Point(1022, 30)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(236, 46)
        Me.button1.TabIndex = 45
        Me.button1.Text = "TDD Audit"
        Me.button1.UseVisualStyleBackColor = True
        '
        'ENBIdTextBox
        '
        Me.ENBIdTextBox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ENBIdTextBox.Location = New System.Drawing.Point(92, 27)
        Me.ENBIdTextBox.Multiline = True
        Me.ENBIdTextBox.Name = "ENBIdTextBox"
        Me.ENBIdTextBox.Size = New System.Drawing.Size(336, 41)
        Me.ENBIdTextBox.TabIndex = 42
        Me.ENBIdTextBox.Text = "eNB ID 1 "
        Me.ENBIdTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tableLayoutPanel6
        '
        Me.tableLayoutPanel6.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.tableLayoutPanel6.ColumnCount = 2
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.45454!))
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.54546!))
        Me.tableLayoutPanel6.Controls.Add(Me.label31, 0, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.label32, 0, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.label33, 0, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.label34, 0, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox16, 1, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox17, 1, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox25, 1, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox26, 1, 3)
        Me.tableLayoutPanel6.Location = New System.Drawing.Point(674, 528)
        Me.tableLayoutPanel6.Name = "tableLayoutPanel6"
        Me.tableLayoutPanel6.RowCount = 4
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.5!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.5!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 19.0!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tableLayoutPanel6.Size = New System.Drawing.Size(595, 104)
        Me.tableLayoutPanel6.TabIndex = 60
        '
        'label31
        '
        Me.label31.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label31.BackColor = System.Drawing.Color.OldLace
        Me.label31.Location = New System.Drawing.Point(4, 83)
        Me.label31.Name = "label31"
        Me.label31.Size = New System.Drawing.Size(263, 19)
        Me.label31.TabIndex = 12
        Me.label31.Text = "MMBS S&B IP"
        Me.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label32
        '
        Me.label32.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label32.BackColor = System.Drawing.Color.OldLace
        Me.label32.Location = New System.Drawing.Point(4, 1)
        Me.label32.Name = "label32"
        Me.label32.Size = New System.Drawing.Size(263, 26)
        Me.label32.TabIndex = 9
        Me.label32.Text = "CSROAMIP"
        Me.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label33
        '
        Me.label33.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label33.BackColor = System.Drawing.Color.OldLace
        Me.label33.Location = New System.Drawing.Point(4, 28)
        Me.label33.Name = "label33"
        Me.label33.Size = New System.Drawing.Size(263, 28)
        Me.label33.TabIndex = 10
        Me.label33.Text = "MMBS OAMIP"
        Me.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label34
        '
        Me.label34.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label34.BackColor = System.Drawing.Color.OldLace
        Me.label34.Location = New System.Drawing.Point(4, 57)
        Me.label34.Name = "label34"
        Me.label34.Size = New System.Drawing.Size(263, 25)
        Me.label34.TabIndex = 11
        Me.label34.Text = "CSR&BIP "
        Me.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(274, 4)
        Me.TextBox16.Multiline = True
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(315, 20)
        Me.TextBox16.TabIndex = 13
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(274, 31)
        Me.TextBox17.Multiline = True
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(315, 20)
        Me.TextBox17.TabIndex = 14
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(274, 60)
        Me.TextBox25.Multiline = True
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(315, 19)
        Me.TextBox25.TabIndex = 15
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(274, 86)
        Me.TextBox26.Multiline = True
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(315, 14)
        Me.TextBox26.TabIndex = 16
        '
        'label13
        '
        Me.label13.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.label13.BackColor = System.Drawing.Color.DarkGray
        Me.label13.Location = New System.Drawing.Point(674, 486)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(599, 38)
        Me.label13.TabIndex = 59
        Me.label13.Text = "4G IP Plan"
        Me.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tableLayoutPanel1
        '
        Me.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.tableLayoutPanel1.ColumnCount = 4
        Me.tableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 121.0!))
        Me.tableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 125.0!))
        Me.tableLayoutPanel1.Controls.Add(Me.TextBox15, 3, 3)
        Me.tableLayoutPanel1.Controls.Add(Me.TextBox14, 2, 3)
        Me.tableLayoutPanel1.Controls.Add(Me.TextBox13, 1, 3)
        Me.tableLayoutPanel1.Controls.Add(Me.TextBox12, 3, 2)
        Me.tableLayoutPanel1.Controls.Add(Me.TextBox11, 2, 2)
        Me.tableLayoutPanel1.Controls.Add(Me.TextBox4, 1, 2)
        Me.tableLayoutPanel1.Controls.Add(Me.TextBox3, 3, 1)
        Me.tableLayoutPanel1.Controls.Add(Me.TextBox2, 2, 1)
        Me.tableLayoutPanel1.Controls.Add(Me.label9, 0, 1)
        Me.tableLayoutPanel1.Controls.Add(Me.label3, 2, 0)
        Me.tableLayoutPanel1.Controls.Add(Me.label4, 3, 0)
        Me.tableLayoutPanel1.Controls.Add(Me.label1, 0, 0)
        Me.tableLayoutPanel1.Controls.Add(Me.label2, 1, 0)
        Me.tableLayoutPanel1.Controls.Add(Me.label12, 0, 3)
        Me.tableLayoutPanel1.Controls.Add(Me.label11, 0, 2)
        Me.tableLayoutPanel1.Controls.Add(Me.TextBox1, 1, 1)
        Me.tableLayoutPanel1.Location = New System.Drawing.Point(92, 486)
        Me.tableLayoutPanel1.Name = "tableLayoutPanel1"
        Me.tableLayoutPanel1.RowCount = 4
        Me.tableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 58.33333!))
        Me.tableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.66667!))
        Me.tableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28.0!))
        Me.tableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26.0!))
        Me.tableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tableLayoutPanel1.Size = New System.Drawing.Size(576, 146)
        Me.tableLayoutPanel1.TabIndex = 58
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(452, 121)
        Me.TextBox15.Multiline = True
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(120, 21)
        Me.TextBox15.TabIndex = 19
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(330, 121)
        Me.TextBox14.Multiline = True
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(115, 21)
        Me.TextBox14.TabIndex = 18
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(167, 121)
        Me.TextBox13.Multiline = True
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(156, 21)
        Me.TextBox13.TabIndex = 17
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(452, 92)
        Me.TextBox12.Multiline = True
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(120, 22)
        Me.TextBox12.TabIndex = 16
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(330, 92)
        Me.TextBox11.Multiline = True
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(115, 22)
        Me.TextBox11.TabIndex = 15
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(167, 92)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(156, 22)
        Me.TextBox4.TabIndex = 14
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(452, 55)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(120, 28)
        Me.TextBox3.TabIndex = 13
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(330, 55)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(115, 28)
        Me.TextBox2.TabIndex = 12
        '
        'label9
        '
        Me.label9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label9.BackColor = System.Drawing.Color.OldLace
        Me.label9.Location = New System.Drawing.Point(4, 57)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(156, 26)
        Me.label9.TabIndex = 8
        Me.label9.Text = "Alpha"
        Me.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label3
        '
        Me.label3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label3.BackColor = System.Drawing.Color.DarkGray
        Me.label3.Location = New System.Drawing.Point(330, 7)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(115, 38)
        Me.label3.TabIndex = 7
        Me.label3.Text = "RACH"
        Me.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label4
        '
        Me.label4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label4.BackColor = System.Drawing.Color.DarkGray
        Me.label4.Location = New System.Drawing.Point(457, 7)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(109, 38)
        Me.label4.TabIndex = 6
        Me.label4.Text = "Tilt"
        Me.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label1
        '
        Me.label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label1.BackColor = System.Drawing.Color.DarkGray
        Me.label1.Location = New System.Drawing.Point(4, 7)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(156, 38)
        Me.label1.TabIndex = 5
        Me.label1.Text = "Sector"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label2
        '
        Me.label2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label2.BackColor = System.Drawing.Color.DarkGray
        Me.label2.Location = New System.Drawing.Point(167, 7)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(156, 38)
        Me.label2.TabIndex = 4
        Me.label2.Text = "PCI"
        Me.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label12
        '
        Me.label12.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label12.BackColor = System.Drawing.Color.OldLace
        Me.label12.Location = New System.Drawing.Point(4, 121)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(156, 21)
        Me.label12.TabIndex = 10
        Me.label12.Text = "Gamma"
        Me.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label11
        '
        Me.label11.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label11.BackColor = System.Drawing.Color.OldLace
        Me.label11.Location = New System.Drawing.Point(4, 93)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(156, 20)
        Me.label11.TabIndex = 9
        Me.label11.Text = "Beta"
        Me.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(167, 55)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(156, 28)
        Me.TextBox1.TabIndex = 11
        '
        'TDD
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSalmon
        Me.ClientSize = New System.Drawing.Size(1278, 644)
        Me.Controls.Add(Me.tableLayoutPanel6)
        Me.Controls.Add(Me.label13)
        Me.Controls.Add(Me.tableLayoutPanel1)
        Me.Controls.Add(Me.tableLayoutPanel5)
        Me.Controls.Add(Me.tableLayoutPanel4)
        Me.Controls.Add(Me.tableLayoutPanel2)
        Me.Controls.Add(Me.name_id)
        Me.Controls.Add(Me.TddLabel)
        Me.Controls.Add(Me.tableLayoutPanel3)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.ENBIdTextBox)
        Me.Name = "TDD"
        Me.Text = "TDD"
        Me.tableLayoutPanel5.ResumeLayout(False)
        Me.tableLayoutPanel5.PerformLayout()
        Me.tableLayoutPanel4.ResumeLayout(False)
        Me.tableLayoutPanel4.PerformLayout()
        Me.tableLayoutPanel2.ResumeLayout(False)
        Me.tableLayoutPanel2.PerformLayout()
        Me.name_id.ResumeLayout(False)
        Me.name_id.PerformLayout()
        Me.tableLayoutPanel3.ResumeLayout(False)
        Me.tableLayoutPanel3.PerformLayout()
        Me.tableLayoutPanel6.ResumeLayout(False)
        Me.tableLayoutPanel6.PerformLayout()
        Me.tableLayoutPanel1.ResumeLayout(False)
        Me.tableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents tableLayoutPanel5 As TableLayoutPanel
    Private WithEvents textBox21 As TextBox
    Private WithEvents label10 As Label
    Private WithEvents tableLayoutPanel4 As TableLayoutPanel
    Private WithEvents textBox18 As TextBox
    Private WithEvents textBox19 As TextBox
    Private WithEvents label8 As Label
    Private WithEvents label7 As Label
    Private WithEvents tableLayoutPanel2 As TableLayoutPanel
    Private WithEvents textBox6 As TextBox
    Private WithEvents textBox5 As TextBox
    Private WithEvents label6 As Label
    Private WithEvents label5 As Label
    Private WithEvents name_id As TableLayoutPanel
    Private WithEvents textBox22 As TextBox
    Private WithEvents textBox20 As TextBox
    Private WithEvents textBox9 As TextBox
    Private WithEvents textBox10 As TextBox
    Private WithEvents TddLabel As TextBox
    Private WithEvents tableLayoutPanel3 As TableLayoutPanel
    Private WithEvents textBox24 As TextBox
    Private WithEvents textBox23 As TextBox
    Private WithEvents textBox8 As TextBox
    Private WithEvents textBox7 As TextBox
    Private WithEvents button1 As Button
    Private WithEvents ENBIdTextBox As TextBox
    Private WithEvents tableLayoutPanel6 As TableLayoutPanel
    Private WithEvents label31 As Label
    Private WithEvents label32 As Label
    Private WithEvents label33 As Label
    Private WithEvents label34 As Label
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents TextBox25 As TextBox
    Friend WithEvents TextBox26 As TextBox
    Private WithEvents label13 As Label
    Private WithEvents tableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Private WithEvents label9 As Label
    Private WithEvents label3 As Label
    Private WithEvents label4 As Label
    Private WithEvents label1 As Label
    Private WithEvents label2 As Label
    Private WithEvents label12 As Label
    Private WithEvents label11 As Label
    Friend WithEvents TextBox1 As TextBox
End Class
