﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Cdu30Button = New System.Windows.Forms.Button()
        Me.TddButton = New System.Windows.Forms.Button()
        Me.FddButton = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.BackColor = System.Drawing.Color.RosyBrown
        Me.Panel1.Controls.Add(Me.Cdu30Button)
        Me.Panel1.Controls.Add(Me.TddButton)
        Me.Panel1.Controls.Add(Me.FddButton)
        Me.Panel1.Location = New System.Drawing.Point(12, 10)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(455, 317)
        Me.Panel1.TabIndex = 19
        '
        'Cdu30Button
        '
        Me.Cdu30Button.BackColor = System.Drawing.Color.NavajoWhite
        Me.Cdu30Button.Location = New System.Drawing.Point(156, 204)
        Me.Cdu30Button.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Cdu30Button.Name = "Cdu30Button"
        Me.Cdu30Button.Size = New System.Drawing.Size(130, 40)
        Me.Cdu30Button.TabIndex = 2
        Me.Cdu30Button.Text = "CDU30"
        Me.Cdu30Button.UseVisualStyleBackColor = False
        '
        'TddButton
        '
        Me.TddButton.BackColor = System.Drawing.Color.NavajoWhite
        Me.TddButton.Location = New System.Drawing.Point(156, 122)
        Me.TddButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TddButton.Name = "TddButton"
        Me.TddButton.Size = New System.Drawing.Size(130, 40)
        Me.TddButton.TabIndex = 1
        Me.TddButton.Text = "TDD"
        Me.TddButton.UseVisualStyleBackColor = False
        '
        'FddButton
        '
        Me.FddButton.BackColor = System.Drawing.Color.NavajoWhite
        Me.FddButton.Location = New System.Drawing.Point(156, 36)
        Me.FddButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.FddButton.Name = "FddButton"
        Me.FddButton.Size = New System.Drawing.Size(130, 40)
        Me.FddButton.TabIndex = 0
        Me.FddButton.Text = "FDD"
        Me.FddButton.UseVisualStyleBackColor = False
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(479, 343)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form3"
        Me.Text = "Form3"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Cdu30Button As Button
    Friend WithEvents TddButton As Button
    Friend WithEvents FddButton As Button
End Class
