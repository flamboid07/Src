﻿Public Class Form3
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ''here i grab options collection.. and build the options panel.. 
        ''one option per item found in searchm then added to groupbox
        ''For i As Integer = 1 To options.Count
        ''Dim rdo As New RadioButton
        ''Dim bits = Split(options.Item(i), ",")
        ''rdo.Name = "rdo" + CStr(i)
        ''rdo.Text = bits(1)
        ''rdo.Location = New Point(5, 30 * i)
        ''Panel1.Controls.Add(rdo)

        ''Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        selection = ""
        ''this checks which option was selected then sends off to the CMD panel
        For i = 1 To options.Count
            Dim matches() As Control
            matches = Me.Controls.Find("rdo" + CStr(i), True)
            If matches.Length > 0 Then
                Dim rb As RadioButton = DirectCast(matches(0), RadioButton)
                If rb.Checked = True Then
                    selection = options.Item(i)
                    Exit For
                End If
            End If

        Next

        If selection <> "" Then
            Form4.Show()
            Me.Close()
        Else
            MsgBox("nothing selected!")
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) 
        ''HOME BUTTON
        Form2.Show()
        Me.Close()

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub FddButton_Click(sender As Object, e As EventArgs) Handles FddButton.Click
        FDD.Show()
    End Sub

    Private Sub TddButton_Click(sender As Object, e As EventArgs) Handles TddButton.Click
        TDD.Show()
    End Sub

    Private Sub Cdu30Button_Click(sender As Object, e As EventArgs) Handles Cdu30Button.Click
        CDU30.Show()
    End Sub
End Class