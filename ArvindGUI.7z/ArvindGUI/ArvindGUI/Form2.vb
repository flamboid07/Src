﻿Imports Excel = Microsoft.Office.Interop.Excel
Imports System.IO

Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ''checks first for whether consolidated list has been built
        If consolidated Is Nothing Then
            ''list not build.. calls for refresh
            MsgBox("please refresh consolidated first")
        Else
            ''consolidated list is built, now search for search string in list
            If TextBox1.Text = "" Then
                ''empty search string..
                MsgBox("please enter a search string")
            Else
                ''build options list from matched search strings
                options = New Collection()
                cascadeID = TextBox1.Text
                For Each x In consolidated
                    Dim bits = Split(x, ",")
                    If TextBox1.Text = bits(1) Then
                        options.Add(x)
                    End If

                Next
                If options.Count > 0 Then
                    ''load up options panel
                    Form3.Show()
                    'Me.Close()
                Else
                    ''no search results
                    MsgBox("no rows were located with that search string")
                End If

            End If
        End If



    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ''this reads file in from desktop.
        'creat new collection to hold params
        consolidated = New Collection()

        Try
            'open consolidated csv file for reading
            Dim reader As StreamReader = My.Computer.FileSystem.OpenTextFileReader(My.Computer.FileSystem.SpecialDirectories.Desktop + "\consolidated-XLSX.csv")
            'Dim reader As StreamReader = My.Computer.FileSystem.OpenTextFileReader("G:\csv\consolidated-XLSX.csv")
            'Dim reader As StreamReader = My.Computer.FileSystem.OpenTextFileReader("C:\Users\Bhargava\Desktop\csv\consolidated-XLSX.csv")

            'declare string to read into
            Dim a As String
            Do
                'read line from csv
                a = reader.ReadLine
                Try
                    'if last char is a comma, remove it
                    If Mid(a, Len(a), 1) = "," Then
                        a = Mid(a, 1, Len(a) - 1)
                    End If
                    'add to collection
                    consolidated.Add(a)
                Catch
                End Try

            Loop Until a Is Nothing
            'close file
            reader.Close()
        Catch err As Exception
            MsgBox(err.ToString)

        End Try
        MsgBox(CStr(consolidated.Count) + " rows read in!")

    End Sub

    Public Sub consolidate()
        ''this reads the excel file in that is to be consolidated.. then simply concat all of the worksheets and read into collection for searching
        ''here i build the consolidated collection

        ''open the file dialog to select input xlsx for consolidation
        OpenFileDialog1.ShowDialog()

        Dim filename = OpenFileDialog1.FileName
        If filename <> "" Then
            consolidated = New Collection()


            ''initialise excel variables for reading xlsx sheets into program
            Dim xlApp As New Excel.Application
            Dim xlWorkBook As Excel.Workbook
            Dim xlWorkSheet As Excel.Worksheet
            xlWorkBook = xlApp.Workbooks.Open(filename)
            'loop over all sheets
            For i = 1 To xlWorkBook.Sheets.Count
                xlWorkSheet = xlWorkBook.Worksheets(i)
                ''loop over all rows
                For r = 2 To 10
                    Dim rowstr = ""
                    ''loop over all columns
                    For c = 1 To 9
                        rowstr = rowstr + CStr(xlWorkSheet.Cells(r, c).value) + ","
                    Next
                    If rowstr <> ",,,,,,,,," Then
                        'if rowstr is a valid entry,,add to consolidated list
                        consolidated.Add(rowstr)
                    End If
                Next
            Next


            ''clear excel variables
            xlApp.Quit()
            releaseObject(xlApp)
            releaseObject(xlWorkBook)
            releaseObject(xlWorkSheet)

            Try
                'open csv file for writing
                'Dim writer As StreamWriter = My.Computer.FileSystem.OpenTextFileWriter("C:\Users\Bhargava\Desktop\csv\consolidated-xlsx", False)
                Dim writer As StreamWriter = My.Computer.FileSystem.OpenTextFileWriter("C:\users\Arvind\Desktop\consolidated-XLSX.csv", False)
                'Dim writer As StreamWriter = My.Computer.FileSystem.OpenTextFileWriter("G:\csv\consolidated-XLSX.csv", False)
                Dim a As String

                For Each x In consolidated
                    'write line to file
                    writer.WriteLine(x)
                Next
                'close file
                writer.Close()
            Catch
            End Try
        End If
        MsgBox("done!")

    End Sub
    Private Sub releaseObject(ByVal obj As Object)
        'helper function for excel
        Try
            'releases dynamic excel variable from memory
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            'manual garbage collection
            GC.Collect()
        End Try
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class