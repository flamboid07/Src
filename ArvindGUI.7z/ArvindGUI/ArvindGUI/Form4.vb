﻿Public Class Form4
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ''here i get selection.. and fill the datagridview up
        ''split selection up by commas into separate params
        Dim bits = Split(selection, ",")
        For y = 0 To bits.Count - 2
            ''create new row in grid
            DataGridView1.Rows.Add()
            'add param to grid
            DataGridView1.Rows(y).Cells(0).Value = bits(y)
        Next
        DataGridView1.Rows(bits.Count - 1).Cells(0).Value = bits(bits.Count - 1)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        'HOME button
        Form2.Show()
        Me.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ''this is connected to the CMD1.pl script on the desktop..

        'get desktop folder path
        Dim foldername = My.Computer.FileSystem.SpecialDirectories.Desktop
        ''here load up param as a string to send to perl script
        Dim paramstring = Replace(selection, ",", " ")
        ''send command to perl script


        Dim oProcess As New Process()
        Dim oStartInfo As New ProcessStartInfo("perl.exe", foldername + "\CMD1.pl " + paramstring)
        oStartInfo.UseShellExecute = False
        oStartInfo.RedirectStandardOutput = True
        oProcess.StartInfo = oStartInfo
        oProcess.Start()

        Dim sOutput As String
        Using oStreamReader As System.IO.StreamReader = oProcess.StandardOutput
            sOutput = oStreamReader.ReadToEnd()
        End Using
        Dim bits = Split(sOutput, " ")

        For y = 0 To Split(selection, ",").Count - 1

            'add param to grid
            DataGridView1.Rows(y).Cells(1).Value = bits(y)

        Next
    End Sub
End Class