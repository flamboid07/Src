﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CDU30
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TacTextBox = New System.Windows.Forms.TextBox()
        Me.tableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox18 = New System.Windows.Forms.TextBox()
        Me.textBox19 = New System.Windows.Forms.TextBox()
        Me.label8 = New System.Windows.Forms.Label()
        Me.label7 = New System.Windows.Forms.Label()
        Me.textBox24 = New System.Windows.Forms.TextBox()
        Me.textBox23 = New System.Windows.Forms.TextBox()
        Me.LsmNameTextbox = New System.Windows.Forms.TextBox()
        Me.LsmrIpTextbox = New System.Windows.Forms.TextBox()
        Me.ENodeBName_label = New System.Windows.Forms.TextBox()
        Me.textBox20 = New System.Windows.Forms.TextBox()
        Me.ENodeBIdTextbox = New System.Windows.Forms.TextBox()
        Me.tableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox17 = New System.Windows.Forms.TextBox()
        Me.textBox15 = New System.Windows.Forms.TextBox()
        Me.textBox14 = New System.Windows.Forms.TextBox()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.textBox3 = New System.Windows.Forms.TextBox()
        Me.textBox12 = New System.Windows.Forms.TextBox()
        Me.textBox13 = New System.Windows.Forms.TextBox()
        Me.textBox16 = New System.Windows.Forms.TextBox()
        Me.ENBID1_search = New System.Windows.Forms.Button()
        Me.ENodeBNameTextbox = New System.Windows.Forms.TextBox()
        Me.CabinetTextBox = New System.Windows.Forms.TextBox()
        Me.label30 = New System.Windows.Forms.Label()
        Me.name_id = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox22 = New System.Windows.Forms.TextBox()
        Me.textBox25 = New System.Windows.Forms.TextBox()
        Me.textBox26 = New System.Windows.Forms.TextBox()
        Me.textBox27 = New System.Windows.Forms.TextBox()
        Me.tableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.TextBox259 = New System.Windows.Forms.TextBox()
        Me.TextBox258 = New System.Windows.Forms.TextBox()
        Me.TextBox257 = New System.Windows.Forms.TextBox()
        Me.TextBox256 = New System.Windows.Forms.TextBox()
        Me.TextBox255 = New System.Windows.Forms.TextBox()
        Me.TextBox254 = New System.Windows.Forms.TextBox()
        Me.TextBox253 = New System.Windows.Forms.TextBox()
        Me.TextBox252 = New System.Windows.Forms.TextBox()
        Me.TextBox251 = New System.Windows.Forms.TextBox()
        Me.TextBox250 = New System.Windows.Forms.TextBox()
        Me.TextBox249 = New System.Windows.Forms.TextBox()
        Me.TextBox248 = New System.Windows.Forms.TextBox()
        Me.TextBox247 = New System.Windows.Forms.TextBox()
        Me.TextBox246 = New System.Windows.Forms.TextBox()
        Me.TextBox245 = New System.Windows.Forms.TextBox()
        Me.TextBox244 = New System.Windows.Forms.TextBox()
        Me.TextBox243 = New System.Windows.Forms.TextBox()
        Me.TextBox242 = New System.Windows.Forms.TextBox()
        Me.TextBox241 = New System.Windows.Forms.TextBox()
        Me.TextBox240 = New System.Windows.Forms.TextBox()
        Me.TextBox239 = New System.Windows.Forms.TextBox()
        Me.TextBox238 = New System.Windows.Forms.TextBox()
        Me.TextBox237 = New System.Windows.Forms.TextBox()
        Me.TextBox236 = New System.Windows.Forms.TextBox()
        Me.TextBox235 = New System.Windows.Forms.TextBox()
        Me.TextBox234 = New System.Windows.Forms.TextBox()
        Me.TextBox233 = New System.Windows.Forms.TextBox()
        Me.TextBox232 = New System.Windows.Forms.TextBox()
        Me.TextBox231 = New System.Windows.Forms.TextBox()
        Me.TextBox230 = New System.Windows.Forms.TextBox()
        Me.TextBox229 = New System.Windows.Forms.TextBox()
        Me.TextBox228 = New System.Windows.Forms.TextBox()
        Me.TextBox227 = New System.Windows.Forms.TextBox()
        Me.TextBox226 = New System.Windows.Forms.TextBox()
        Me.TextBox225 = New System.Windows.Forms.TextBox()
        Me.TextBox224 = New System.Windows.Forms.TextBox()
        Me.TextBox223 = New System.Windows.Forms.TextBox()
        Me.TextBox222 = New System.Windows.Forms.TextBox()
        Me.TextBox221 = New System.Windows.Forms.TextBox()
        Me.TextBox220 = New System.Windows.Forms.TextBox()
        Me.TextBox219 = New System.Windows.Forms.TextBox()
        Me.TextBox218 = New System.Windows.Forms.TextBox()
        Me.TextBox217 = New System.Windows.Forms.TextBox()
        Me.TextBox216 = New System.Windows.Forms.TextBox()
        Me.TextBox215 = New System.Windows.Forms.TextBox()
        Me.TextBox214 = New System.Windows.Forms.TextBox()
        Me.TextBox213 = New System.Windows.Forms.TextBox()
        Me.TextBox212 = New System.Windows.Forms.TextBox()
        Me.TextBox211 = New System.Windows.Forms.TextBox()
        Me.TextBox210 = New System.Windows.Forms.TextBox()
        Me.TextBox209 = New System.Windows.Forms.TextBox()
        Me.TextBox208 = New System.Windows.Forms.TextBox()
        Me.TextBox207 = New System.Windows.Forms.TextBox()
        Me.TextBox206 = New System.Windows.Forms.TextBox()
        Me.TextBox205 = New System.Windows.Forms.TextBox()
        Me.TextBox204 = New System.Windows.Forms.TextBox()
        Me.TextBox203 = New System.Windows.Forms.TextBox()
        Me.TextBox202 = New System.Windows.Forms.TextBox()
        Me.TextBox201 = New System.Windows.Forms.TextBox()
        Me.TextBox200 = New System.Windows.Forms.TextBox()
        Me.TextBox199 = New System.Windows.Forms.TextBox()
        Me.TextBox198 = New System.Windows.Forms.TextBox()
        Me.TextBox197 = New System.Windows.Forms.TextBox()
        Me.TextBox196 = New System.Windows.Forms.TextBox()
        Me.TextBox195 = New System.Windows.Forms.TextBox()
        Me.TextBox194 = New System.Windows.Forms.TextBox()
        Me.TextBox193 = New System.Windows.Forms.TextBox()
        Me.TextBox192 = New System.Windows.Forms.TextBox()
        Me.TextBox191 = New System.Windows.Forms.TextBox()
        Me.TextBox190 = New System.Windows.Forms.TextBox()
        Me.TextBox189 = New System.Windows.Forms.TextBox()
        Me.TextBox188 = New System.Windows.Forms.TextBox()
        Me.TextBox187 = New System.Windows.Forms.TextBox()
        Me.TextBox186 = New System.Windows.Forms.TextBox()
        Me.TextBox185 = New System.Windows.Forms.TextBox()
        Me.TextBox184 = New System.Windows.Forms.TextBox()
        Me.TextBox183 = New System.Windows.Forms.TextBox()
        Me.TextBox182 = New System.Windows.Forms.TextBox()
        Me.TextBox181 = New System.Windows.Forms.TextBox()
        Me.TextBox180 = New System.Windows.Forms.TextBox()
        Me.TextBox179 = New System.Windows.Forms.TextBox()
        Me.TextBox178 = New System.Windows.Forms.TextBox()
        Me.TextBox177 = New System.Windows.Forms.TextBox()
        Me.TextBox176 = New System.Windows.Forms.TextBox()
        Me.TextBox175 = New System.Windows.Forms.TextBox()
        Me.TextBox174 = New System.Windows.Forms.TextBox()
        Me.TextBox173 = New System.Windows.Forms.TextBox()
        Me.TextBox172 = New System.Windows.Forms.TextBox()
        Me.TextBox171 = New System.Windows.Forms.TextBox()
        Me.TextBox170 = New System.Windows.Forms.TextBox()
        Me.TextBox169 = New System.Windows.Forms.TextBox()
        Me.TextBox168 = New System.Windows.Forms.TextBox()
        Me.TextBox167 = New System.Windows.Forms.TextBox()
        Me.TextBox166 = New System.Windows.Forms.TextBox()
        Me.TextBox165 = New System.Windows.Forms.TextBox()
        Me.TextBox164 = New System.Windows.Forms.TextBox()
        Me.TextBox163 = New System.Windows.Forms.TextBox()
        Me.TextBox162 = New System.Windows.Forms.TextBox()
        Me.TextBox161 = New System.Windows.Forms.TextBox()
        Me.TextBox160 = New System.Windows.Forms.TextBox()
        Me.TextBox159 = New System.Windows.Forms.TextBox()
        Me.TextBox158 = New System.Windows.Forms.TextBox()
        Me.TextBox157 = New System.Windows.Forms.TextBox()
        Me.TextBox156 = New System.Windows.Forms.TextBox()
        Me.TextBox155 = New System.Windows.Forms.TextBox()
        Me.TextBox154 = New System.Windows.Forms.TextBox()
        Me.TextBox153 = New System.Windows.Forms.TextBox()
        Me.TextBox152 = New System.Windows.Forms.TextBox()
        Me.TextBox151 = New System.Windows.Forms.TextBox()
        Me.TextBox150 = New System.Windows.Forms.TextBox()
        Me.TextBox149 = New System.Windows.Forms.TextBox()
        Me.TextBox148 = New System.Windows.Forms.TextBox()
        Me.TextBox147 = New System.Windows.Forms.TextBox()
        Me.TextBox146 = New System.Windows.Forms.TextBox()
        Me.TextBox145 = New System.Windows.Forms.TextBox()
        Me.TextBox144 = New System.Windows.Forms.TextBox()
        Me.TextBox143 = New System.Windows.Forms.TextBox()
        Me.TextBox142 = New System.Windows.Forms.TextBox()
        Me.TextBox141 = New System.Windows.Forms.TextBox()
        Me.TextBox140 = New System.Windows.Forms.TextBox()
        Me.TextBox139 = New System.Windows.Forms.TextBox()
        Me.TextBox138 = New System.Windows.Forms.TextBox()
        Me.TextBox137 = New System.Windows.Forms.TextBox()
        Me.TextBox136 = New System.Windows.Forms.TextBox()
        Me.TextBox135 = New System.Windows.Forms.TextBox()
        Me.TextBox134 = New System.Windows.Forms.TextBox()
        Me.TextBox133 = New System.Windows.Forms.TextBox()
        Me.TextBox132 = New System.Windows.Forms.TextBox()
        Me.TextBox131 = New System.Windows.Forms.TextBox()
        Me.TextBox130 = New System.Windows.Forms.TextBox()
        Me.TextBox129 = New System.Windows.Forms.TextBox()
        Me.TextBox128 = New System.Windows.Forms.TextBox()
        Me.TextBox127 = New System.Windows.Forms.TextBox()
        Me.TextBox126 = New System.Windows.Forms.TextBox()
        Me.TextBox125 = New System.Windows.Forms.TextBox()
        Me.TextBox124 = New System.Windows.Forms.TextBox()
        Me.TextBox123 = New System.Windows.Forms.TextBox()
        Me.TextBox122 = New System.Windows.Forms.TextBox()
        Me.TextBox121 = New System.Windows.Forms.TextBox()
        Me.TextBox120 = New System.Windows.Forms.TextBox()
        Me.TextBox119 = New System.Windows.Forms.TextBox()
        Me.TextBox118 = New System.Windows.Forms.TextBox()
        Me.TextBox117 = New System.Windows.Forms.TextBox()
        Me.TextBox116 = New System.Windows.Forms.TextBox()
        Me.label17 = New System.Windows.Forms.Label()
        Me.label16 = New System.Windows.Forms.Label()
        Me.label15 = New System.Windows.Forms.Label()
        Me.label14 = New System.Windows.Forms.Label()
        Me.label13 = New System.Windows.Forms.Label()
        Me.label12 = New System.Windows.Forms.Label()
        Me.label11 = New System.Windows.Forms.Label()
        Me.label9 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.TddLabel = New System.Windows.Forms.TextBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.tableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox21 = New System.Windows.Forms.TextBox()
        Me.label10 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.cdu30Grow_Button = New System.Windows.Forms.Button()
        Me.tableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.TargetPanel = New System.Windows.Forms.Panel()
        Me.ENBID1TextBox = New System.Windows.Forms.TextBox()
        Me.Cdu30Env_button = New System.Windows.Forms.Button()
        Me.Cdu30Atp = New System.Windows.Forms.Button()
        Me.Cdu30Comm_Button = New System.Windows.Forms.Button()
        Me.Cdu30Audit_Button = New System.Windows.Forms.Button()
        Me.Name_idTable = New System.Windows.Forms.TableLayoutPanel()
        Me.tableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox39 = New System.Windows.Forms.TextBox()
        Me.textBox40 = New System.Windows.Forms.TextBox()
        Me.label38 = New System.Windows.Forms.Label()
        Me.label39 = New System.Windows.Forms.Label()
        Me.tableLayoutPanel17 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox38 = New System.Windows.Forms.TextBox()
        Me.label37 = New System.Windows.Forms.Label()
        Me.tableLayoutPanel16 = New System.Windows.Forms.TableLayoutPanel()
        Me.tableLayoutPanel15 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox36 = New System.Windows.Forms.TextBox()
        Me.textBox37 = New System.Windows.Forms.TextBox()
        Me.label35 = New System.Windows.Forms.Label()
        Me.label36 = New System.Windows.Forms.Label()
        Me.panel2 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel12 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.TextBox64 = New System.Windows.Forms.TextBox()
        Me.TextBox65 = New System.Windows.Forms.TextBox()
        Me.TextBox66 = New System.Windows.Forms.TextBox()
        Me.TextBox67 = New System.Windows.Forms.TextBox()
        Me.TableLayoutPanel11 = New System.Windows.Forms.TableLayoutPanel()
        Me.TextBox55 = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.TextBox56 = New System.Windows.Forms.TextBox()
        Me.TextBox57 = New System.Windows.Forms.TextBox()
        Me.TextBox58 = New System.Windows.Forms.TextBox()
        Me.TextBox59 = New System.Windows.Forms.TextBox()
        Me.TextBox60 = New System.Windows.Forms.TextBox()
        Me.TextBox61 = New System.Windows.Forms.TextBox()
        Me.TextBox62 = New System.Windows.Forms.TextBox()
        Me.TextBox63 = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.button2 = New System.Windows.Forms.Button()
        Me.ENBIdName = New System.Windows.Forms.TextBox()
        Me.tableLayoutPanel7 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.textBox4 = New System.Windows.Forms.TextBox()
        Me.textBox8 = New System.Windows.Forms.TextBox()
        Me.textBox7 = New System.Windows.Forms.TextBox()
        Me.tableLayoutPanel8 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox5 = New System.Windows.Forms.TextBox()
        Me.label18 = New System.Windows.Forms.Label()
        Me.tableLayoutPanel9 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox6 = New System.Windows.Forms.TextBox()
        Me.textBox9 = New System.Windows.Forms.TextBox()
        Me.label19 = New System.Windows.Forms.Label()
        Me.label20 = New System.Windows.Forms.Label()
        Me.tableLayoutPanel10 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox10 = New System.Windows.Forms.TextBox()
        Me.textBox11 = New System.Windows.Forms.TextBox()
        Me.label21 = New System.Windows.Forms.Label()
        Me.label22 = New System.Windows.Forms.Label()
        Me.SourcePanel = New System.Windows.Forms.Panel()
        Me.panel3 = New System.Windows.Forms.Panel()
        Me.button1 = New System.Windows.Forms.Button()
        Me.ENBIdTextBox = New System.Windows.Forms.TextBox()
        Me.tableLayoutPanel13 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox28 = New System.Windows.Forms.TextBox()
        Me.textBox29 = New System.Windows.Forms.TextBox()
        Me.textBox30 = New System.Windows.Forms.TextBox()
        Me.textBox31 = New System.Windows.Forms.TextBox()
        Me.tableLayoutPanel14 = New System.Windows.Forms.TableLayoutPanel()
        Me.textBox32 = New System.Windows.Forms.TextBox()
        Me.textBox33 = New System.Windows.Forms.TextBox()
        Me.textBox34 = New System.Windows.Forms.TextBox()
        Me.textBox35 = New System.Windows.Forms.TextBox()
        Me.label40 = New System.Windows.Forms.Label()
        Me.tableLayoutPanel18 = New System.Windows.Forms.TableLayoutPanel()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.label41 = New System.Windows.Forms.Label()
        Me.label42 = New System.Windows.Forms.Label()
        Me.label43 = New System.Windows.Forms.Label()
        Me.label44 = New System.Windows.Forms.Label()
        Me.label45 = New System.Windows.Forms.Label()
        Me.label47 = New System.Windows.Forms.Label()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.TextBox44 = New System.Windows.Forms.TextBox()
        Me.TextBox45 = New System.Windows.Forms.TextBox()
        Me.TextBox46 = New System.Windows.Forms.TextBox()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.TextBox49 = New System.Windows.Forms.TextBox()
        Me.label46 = New System.Windows.Forms.Label()
        Me.tableLayoutPanel19 = New System.Windows.Forms.TableLayoutPanel()
        Me.label48 = New System.Windows.Forms.Label()
        Me.label49 = New System.Windows.Forms.Label()
        Me.label50 = New System.Windows.Forms.Label()
        Me.label51 = New System.Windows.Forms.Label()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.TextBox52 = New System.Windows.Forms.TextBox()
        Me.TextBox53 = New System.Windows.Forms.TextBox()
        Me.TextBox54 = New System.Windows.Forms.TextBox()
        Me.textBox41 = New System.Windows.Forms.TextBox()
        Me.tableLayoutPanel4.SuspendLayout()
        Me.tableLayoutPanel3.SuspendLayout()
        Me.name_id.SuspendLayout()
        Me.tableLayoutPanel6.SuspendLayout()
        Me.tableLayoutPanel5.SuspendLayout()
        Me.tableLayoutPanel2.SuspendLayout()
        Me.TargetPanel.SuspendLayout()
        Me.Name_idTable.SuspendLayout()
        Me.tableLayoutPanel1.SuspendLayout()
        Me.tableLayoutPanel17.SuspendLayout()
        Me.tableLayoutPanel16.SuspendLayout()
        Me.tableLayoutPanel15.SuspendLayout()
        Me.panel2.SuspendLayout()
        Me.TableLayoutPanel12.SuspendLayout()
        Me.TableLayoutPanel11.SuspendLayout()
        Me.tableLayoutPanel7.SuspendLayout()
        Me.tableLayoutPanel8.SuspendLayout()
        Me.tableLayoutPanel9.SuspendLayout()
        Me.tableLayoutPanel10.SuspendLayout()
        Me.SourcePanel.SuspendLayout()
        Me.panel3.SuspendLayout()
        Me.tableLayoutPanel13.SuspendLayout()
        Me.tableLayoutPanel14.SuspendLayout()
        Me.tableLayoutPanel18.SuspendLayout()
        Me.tableLayoutPanel19.SuspendLayout()
        Me.SuspendLayout()
        '
        'TacTextBox
        '
        Me.TacTextBox.Location = New System.Drawing.Point(230, 53)
        Me.TacTextBox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TacTextBox.Multiline = True
        Me.TacTextBox.Name = "TacTextBox"
        Me.TacTextBox.Size = New System.Drawing.Size(216, 36)
        Me.TacTextBox.TabIndex = 16
        '
        'tableLayoutPanel4
        '
        Me.tableLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel4.ColumnCount = 2
        Me.tableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.27027!))
        Me.tableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.72973!))
        Me.tableLayoutPanel4.Controls.Add(Me.textBox18, 1, 1)
        Me.tableLayoutPanel4.Controls.Add(Me.textBox19, 0, 1)
        Me.tableLayoutPanel4.Controls.Add(Me.label8, 1, 0)
        Me.tableLayoutPanel4.Controls.Add(Me.label7, 0, 0)
        Me.tableLayoutPanel4.Location = New System.Drawing.Point(592, 913)
        Me.tableLayoutPanel4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tableLayoutPanel4.Name = "tableLayoutPanel4"
        Me.tableLayoutPanel4.RowCount = 2
        Me.tableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.tableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.tableLayoutPanel4.Size = New System.Drawing.Size(374, 151)
        Me.tableLayoutPanel4.TabIndex = 39
        '
        'textBox18
        '
        Me.textBox18.Location = New System.Drawing.Point(192, 95)
        Me.textBox18.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox18.Multiline = True
        Me.textBox18.Name = "textBox18"
        Me.textBox18.Size = New System.Drawing.Size(174, 49)
        Me.textBox18.TabIndex = 16
        '
        'textBox19
        '
        Me.textBox19.Location = New System.Drawing.Point(6, 95)
        Me.textBox19.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox19.Multiline = True
        Me.textBox19.Name = "textBox19"
        Me.textBox19.Size = New System.Drawing.Size(175, 49)
        Me.textBox19.TabIndex = 16
        '
        'label8
        '
        Me.label8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label8.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label8.Location = New System.Drawing.Point(193, 7)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(174, 76)
        Me.label8.TabIndex = 3
        Me.label8.Text = "eNB S&B" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "VLAN"
        Me.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label7
        '
        Me.label7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label7.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label7.Location = New System.Drawing.Point(7, 7)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(174, 76)
        Me.label7.TabIndex = 23
        Me.label7.Text = "eNB OAM" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "VLAN"
        Me.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'textBox24
        '
        Me.textBox24.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox24.Location = New System.Drawing.Point(6, 50)
        Me.textBox24.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox24.Multiline = True
        Me.textBox24.Name = "textBox24"
        Me.textBox24.Size = New System.Drawing.Size(263, 33)
        Me.textBox24.TabIndex = 28
        Me.textBox24.Text = "LSMR IP"
        Me.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox23
        '
        Me.textBox23.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox23.Location = New System.Drawing.Point(6, 7)
        Me.textBox23.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox23.Multiline = True
        Me.textBox23.Name = "textBox23"
        Me.textBox23.Size = New System.Drawing.Size(263, 32)
        Me.textBox23.TabIndex = 29
        Me.textBox23.Text = "LSM Name"
        Me.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LsmNameTextbox
        '
        Me.LsmNameTextbox.Location = New System.Drawing.Point(278, 7)
        Me.LsmNameTextbox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.LsmNameTextbox.Multiline = True
        Me.LsmNameTextbox.Name = "LsmNameTextbox"
        Me.LsmNameTextbox.Size = New System.Drawing.Size(264, 32)
        Me.LsmNameTextbox.TabIndex = 16
        '
        'LsmrIpTextbox
        '
        Me.LsmrIpTextbox.Location = New System.Drawing.Point(278, 50)
        Me.LsmrIpTextbox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.LsmrIpTextbox.Multiline = True
        Me.LsmrIpTextbox.Name = "LsmrIpTextbox"
        Me.LsmrIpTextbox.Size = New System.Drawing.Size(264, 33)
        Me.LsmrIpTextbox.TabIndex = 16
        '
        'ENodeBName_label
        '
        Me.ENodeBName_label.BackColor = System.Drawing.Color.LemonChiffon
        Me.ENodeBName_label.Location = New System.Drawing.Point(6, 7)
        Me.ENodeBName_label.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ENodeBName_label.Multiline = True
        Me.ENodeBName_label.Name = "ENodeBName_label"
        Me.ENodeBName_label.Size = New System.Drawing.Size(262, 32)
        Me.ENodeBName_label.TabIndex = 27
        Me.ENodeBName_label.Text = "eNodeB Name"
        Me.ENodeBName_label.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox20
        '
        Me.textBox20.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox20.Location = New System.Drawing.Point(6, 50)
        Me.textBox20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox20.Multiline = True
        Me.textBox20.Name = "textBox20"
        Me.textBox20.Size = New System.Drawing.Size(262, 33)
        Me.textBox20.TabIndex = 26
        Me.textBox20.Text = "eNodeB ID"
        Me.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ENodeBIdTextbox
        '
        Me.ENodeBIdTextbox.Location = New System.Drawing.Point(278, 50)
        Me.ENodeBIdTextbox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ENodeBIdTextbox.Multiline = True
        Me.ENodeBIdTextbox.Name = "ENodeBIdTextbox"
        Me.ENodeBIdTextbox.Size = New System.Drawing.Size(264, 33)
        Me.ENodeBIdTextbox.TabIndex = 16
        '
        'tableLayoutPanel3
        '
        Me.tableLayoutPanel3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel3.ColumnCount = 2
        Me.tableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel3.Controls.Add(Me.textBox17, 1, 2)
        Me.tableLayoutPanel3.Controls.Add(Me.textBox15, 1, 3)
        Me.tableLayoutPanel3.Controls.Add(Me.textBox14, 0, 3)
        Me.tableLayoutPanel3.Controls.Add(Me.textBox2, 1, 0)
        Me.tableLayoutPanel3.Controls.Add(Me.textBox3, 1, 1)
        Me.tableLayoutPanel3.Controls.Add(Me.textBox12, 0, 0)
        Me.tableLayoutPanel3.Controls.Add(Me.textBox13, 0, 1)
        Me.tableLayoutPanel3.Controls.Add(Me.textBox16, 0, 2)
        Me.tableLayoutPanel3.Location = New System.Drawing.Point(14, 909)
        Me.tableLayoutPanel3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tableLayoutPanel3.Name = "tableLayoutPanel3"
        Me.tableLayoutPanel3.RowCount = 4
        Me.tableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tableLayoutPanel3.Size = New System.Drawing.Size(548, 158)
        Me.tableLayoutPanel3.TabIndex = 38
        '
        'textBox17
        '
        Me.textBox17.Location = New System.Drawing.Point(278, 83)
        Me.textBox17.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox17.Multiline = True
        Me.textBox17.Name = "textBox17"
        Me.textBox17.Size = New System.Drawing.Size(264, 27)
        Me.textBox17.TabIndex = 23
        '
        'textBox15
        '
        Me.textBox15.Location = New System.Drawing.Point(278, 121)
        Me.textBox15.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox15.Multiline = True
        Me.textBox15.Name = "textBox15"
        Me.textBox15.Size = New System.Drawing.Size(264, 30)
        Me.textBox15.TabIndex = 20
        '
        'textBox14
        '
        Me.textBox14.BackColor = System.Drawing.SystemColors.Info
        Me.textBox14.Location = New System.Drawing.Point(6, 121)
        Me.textBox14.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox14.Multiline = True
        Me.textBox14.Name = "textBox14"
        Me.textBox14.Size = New System.Drawing.Size(262, 29)
        Me.textBox14.TabIndex = 19
        Me.textBox14.Text = "MMBSS&B IP"
        Me.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(278, 7)
        Me.textBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox2.Multiline = True
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(264, 27)
        Me.textBox2.TabIndex = 16
        '
        'textBox3
        '
        Me.textBox3.Location = New System.Drawing.Point(278, 45)
        Me.textBox3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox3.Multiline = True
        Me.textBox3.Name = "textBox3"
        Me.textBox3.Size = New System.Drawing.Size(262, 27)
        Me.textBox3.TabIndex = 16
        '
        'textBox12
        '
        Me.textBox12.BackColor = System.Drawing.SystemColors.Info
        Me.textBox12.Location = New System.Drawing.Point(6, 7)
        Me.textBox12.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox12.Multiline = True
        Me.textBox12.Name = "textBox12"
        Me.textBox12.Size = New System.Drawing.Size(262, 25)
        Me.textBox12.TabIndex = 17
        Me.textBox12.Text = "CSROAM IP"
        Me.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox13
        '
        Me.textBox13.BackColor = System.Drawing.SystemColors.Info
        Me.textBox13.Location = New System.Drawing.Point(6, 45)
        Me.textBox13.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox13.Multiline = True
        Me.textBox13.Name = "textBox13"
        Me.textBox13.Size = New System.Drawing.Size(262, 25)
        Me.textBox13.TabIndex = 18
        Me.textBox13.Text = "MMBS OAM IP"
        Me.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox16
        '
        Me.textBox16.BackColor = System.Drawing.SystemColors.Info
        Me.textBox16.Location = New System.Drawing.Point(6, 83)
        Me.textBox16.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox16.Multiline = True
        Me.textBox16.Name = "textBox16"
        Me.textBox16.Size = New System.Drawing.Size(262, 25)
        Me.textBox16.TabIndex = 23
        Me.textBox16.Text = "CSRS&B IP"
        Me.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ENBID1_search
        '
        Me.ENBID1_search.Font = New System.Drawing.Font("Georgia", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ENBID1_search.Location = New System.Drawing.Point(4, 58)
        Me.ENBID1_search.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ENBID1_search.Name = "ENBID1_search"
        Me.ENBID1_search.Size = New System.Drawing.Size(295, 40)
        Me.ENBID1_search.TabIndex = 37
        Me.ENBID1_search.Text = "Search"
        Me.ENBID1_search.UseVisualStyleBackColor = True
        '
        'ENodeBNameTextbox
        '
        Me.ENodeBNameTextbox.Location = New System.Drawing.Point(278, 7)
        Me.ENodeBNameTextbox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ENodeBNameTextbox.Multiline = True
        Me.ENodeBNameTextbox.Name = "ENodeBNameTextbox"
        Me.ENodeBNameTextbox.Size = New System.Drawing.Size(264, 32)
        Me.ENodeBNameTextbox.TabIndex = 16
        '
        'CabinetTextBox
        '
        Me.CabinetTextBox.Location = New System.Drawing.Point(6, 53)
        Me.CabinetTextBox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CabinetTextBox.Multiline = True
        Me.CabinetTextBox.Name = "CabinetTextBox"
        Me.CabinetTextBox.Size = New System.Drawing.Size(215, 36)
        Me.CabinetTextBox.TabIndex = 16
        '
        'label30
        '
        Me.label30.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.label30.BackColor = System.Drawing.Color.DarkGray
        Me.label30.Location = New System.Drawing.Point(662, 392)
        Me.label30.Name = "label30"
        Me.label30.Size = New System.Drawing.Size(575, 38)
        Me.label30.TabIndex = 63
        Me.label30.Text = "4G IP Plan"
        Me.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'name_id
        '
        Me.name_id.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.name_id.BackColor = System.Drawing.Color.Transparent
        Me.name_id.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.name_id.ColumnCount = 2
        Me.name_id.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.name_id.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.name_id.Controls.Add(Me.textBox22, 0, 0)
        Me.name_id.Controls.Add(Me.textBox25, 0, 1)
        Me.name_id.Controls.Add(Me.textBox26, 1, 0)
        Me.name_id.Controls.Add(Me.textBox27, 1, 1)
        Me.name_id.Location = New System.Drawing.Point(83, 66)
        Me.name_id.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.name_id.Name = "name_id"
        Me.name_id.RowCount = 2
        Me.name_id.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.name_id.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.name_id.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.name_id.Size = New System.Drawing.Size(548, 82)
        Me.name_id.TabIndex = 61
        '
        'textBox22
        '
        Me.textBox22.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox22.Location = New System.Drawing.Point(6, 5)
        Me.textBox22.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox22.Multiline = True
        Me.textBox22.Name = "textBox22"
        Me.textBox22.Size = New System.Drawing.Size(262, 29)
        Me.textBox22.TabIndex = 27
        Me.textBox22.Text = "eNodeB Name"
        Me.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox25
        '
        Me.textBox25.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox25.Location = New System.Drawing.Point(6, 44)
        Me.textBox25.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox25.Multiline = True
        Me.textBox25.Name = "textBox25"
        Me.textBox25.Size = New System.Drawing.Size(262, 30)
        Me.textBox25.TabIndex = 26
        Me.textBox25.Text = "eNodeB ID"
        Me.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox26
        '
        Me.textBox26.Location = New System.Drawing.Point(278, 5)
        Me.textBox26.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox26.Multiline = True
        Me.textBox26.Name = "textBox26"
        Me.textBox26.Size = New System.Drawing.Size(264, 32)
        Me.textBox26.TabIndex = 16
        '
        'textBox27
        '
        Me.textBox27.Location = New System.Drawing.Point(278, 44)
        Me.textBox27.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox27.Multiline = True
        Me.textBox27.Name = "textBox27"
        Me.textBox27.Size = New System.Drawing.Size(264, 33)
        Me.textBox27.TabIndex = 16
        '
        'tableLayoutPanel6
        '
        Me.tableLayoutPanel6.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tableLayoutPanel6.AutoScroll = True
        Me.tableLayoutPanel6.BackColor = System.Drawing.Color.Transparent
        Me.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.tableLayoutPanel6.ColumnCount = 12
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.147953!))
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.585138!))
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.09251!))
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.371613!))
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.370374!))
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.370374!))
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.370374!))
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.927344!))
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.689528!))
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.611911!))
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.09251!))
        Me.tableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.370374!))
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox259, 11, 12)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox258, 10, 12)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox257, 9, 12)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox256, 8, 12)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox255, 7, 12)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox254, 6, 12)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox253, 5, 12)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox252, 4, 12)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox251, 3, 12)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox250, 2, 12)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox249, 1, 12)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox248, 0, 12)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox247, 11, 11)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox246, 10, 11)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox245, 9, 11)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox244, 8, 11)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox243, 7, 11)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox242, 6, 11)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox241, 5, 11)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox240, 4, 11)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox239, 3, 11)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox238, 2, 11)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox237, 1, 11)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox236, 0, 11)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox235, 11, 10)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox234, 10, 10)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox233, 9, 10)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox232, 8, 10)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox231, 7, 10)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox230, 6, 10)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox229, 5, 10)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox228, 4, 10)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox227, 3, 10)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox226, 2, 10)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox225, 1, 10)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox224, 0, 10)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox223, 11, 9)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox222, 10, 9)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox221, 9, 9)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox220, 8, 9)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox219, 7, 9)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox218, 6, 9)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox217, 5, 9)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox216, 4, 9)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox215, 3, 9)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox214, 2, 9)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox213, 1, 9)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox212, 0, 9)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox211, 11, 8)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox210, 10, 8)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox209, 9, 8)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox208, 8, 8)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox207, 7, 8)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox206, 6, 8)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox205, 5, 8)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox204, 4, 8)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox203, 3, 8)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox202, 2, 8)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox201, 1, 8)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox200, 0, 8)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox199, 11, 7)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox198, 10, 7)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox197, 9, 7)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox196, 8, 7)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox195, 7, 7)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox194, 6, 7)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox193, 5, 7)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox192, 4, 7)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox191, 3, 7)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox190, 2, 7)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox189, 1, 7)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox188, 0, 7)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox187, 11, 6)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox186, 10, 6)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox185, 9, 6)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox184, 8, 6)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox183, 7, 6)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox182, 6, 6)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox181, 5, 6)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox180, 4, 6)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox179, 3, 6)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox178, 2, 6)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox177, 1, 6)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox176, 0, 6)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox175, 11, 5)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox174, 10, 5)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox173, 9, 5)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox172, 8, 5)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox171, 7, 5)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox170, 6, 5)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox169, 5, 5)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox168, 4, 5)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox167, 3, 5)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox166, 2, 5)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox165, 1, 5)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox164, 0, 5)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox163, 11, 4)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox162, 10, 4)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox161, 9, 4)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox160, 8, 4)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox159, 7, 4)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox158, 6, 4)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox157, 5, 4)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox156, 4, 4)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox155, 3, 4)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox154, 2, 4)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox153, 1, 4)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox152, 0, 4)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox151, 11, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox150, 10, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox149, 9, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox148, 8, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox147, 7, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox146, 6, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox145, 5, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox144, 4, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox143, 3, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox142, 2, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox141, 1, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox140, 0, 3)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox139, 11, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox138, 10, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox137, 9, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox136, 8, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox135, 7, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox134, 6, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox133, 5, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox132, 4, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox131, 3, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox130, 2, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox129, 1, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox128, 0, 2)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox127, 11, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox126, 10, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox125, 9, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox124, 8, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox123, 7, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox122, 6, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox121, 5, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox120, 4, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox119, 3, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox118, 2, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox117, 1, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.TextBox116, 0, 1)
        Me.tableLayoutPanel6.Controls.Add(Me.label17, 11, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.label16, 10, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.label15, 9, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.label14, 8, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.label13, 7, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.label12, 6, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.label11, 5, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.label9, 4, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.label4, 3, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.label3, 2, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.label1, 0, 0)
        Me.tableLayoutPanel6.Controls.Add(Me.label2, 1, 0)
        Me.tableLayoutPanel6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tableLayoutPanel6.Location = New System.Drawing.Point(3, 455)
        Me.tableLayoutPanel6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tableLayoutPanel6.Name = "tableLayoutPanel6"
        Me.tableLayoutPanel6.RowCount = 13
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.0!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.25!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.25!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.25!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.25!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.25!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.25!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.25!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.25!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.25!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.25!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.25!))
        Me.tableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.25!))
        Me.tableLayoutPanel6.Size = New System.Drawing.Size(1254, 446)
        Me.tableLayoutPanel6.TabIndex = 41
        '
        'TextBox259
        '
        Me.TextBox259.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox259.Location = New System.Drawing.Point(1147, 412)
        Me.TextBox259.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox259.Multiline = True
        Me.TextBox259.Name = "TextBox259"
        Me.TextBox259.Size = New System.Drawing.Size(103, 31)
        Me.TextBox259.TabIndex = 235
        '
        'TextBox258
        '
        Me.TextBox258.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox258.Location = New System.Drawing.Point(1021, 412)
        Me.TextBox258.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox258.Multiline = True
        Me.TextBox258.Name = "TextBox258"
        Me.TextBox258.Size = New System.Drawing.Size(119, 31)
        Me.TextBox258.TabIndex = 234
        '
        'TextBox257
        '
        Me.TextBox257.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox257.Location = New System.Drawing.Point(901, 412)
        Me.TextBox257.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox257.Multiline = True
        Me.TextBox257.Name = "TextBox257"
        Me.TextBox257.Size = New System.Drawing.Size(113, 31)
        Me.TextBox257.TabIndex = 233
        '
        'TextBox256
        '
        Me.TextBox256.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox256.Location = New System.Drawing.Point(805, 412)
        Me.TextBox256.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox256.Multiline = True
        Me.TextBox256.Name = "TextBox256"
        Me.TextBox256.Size = New System.Drawing.Size(89, 31)
        Me.TextBox256.TabIndex = 232
        '
        'TextBox255
        '
        Me.TextBox255.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox255.Location = New System.Drawing.Point(731, 412)
        Me.TextBox255.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox255.Multiline = True
        Me.TextBox255.Name = "TextBox255"
        Me.TextBox255.Size = New System.Drawing.Size(67, 31)
        Me.TextBox255.TabIndex = 231
        '
        'TextBox254
        '
        Me.TextBox254.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox254.Location = New System.Drawing.Point(627, 412)
        Me.TextBox254.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox254.Multiline = True
        Me.TextBox254.Name = "TextBox254"
        Me.TextBox254.Size = New System.Drawing.Size(97, 31)
        Me.TextBox254.TabIndex = 230
        '
        'TextBox253
        '
        Me.TextBox253.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox253.Location = New System.Drawing.Point(523, 412)
        Me.TextBox253.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox253.Multiline = True
        Me.TextBox253.Name = "TextBox253"
        Me.TextBox253.Size = New System.Drawing.Size(97, 31)
        Me.TextBox253.TabIndex = 229
        '
        'TextBox252
        '
        Me.TextBox252.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox252.Location = New System.Drawing.Point(419, 412)
        Me.TextBox252.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox252.Multiline = True
        Me.TextBox252.Name = "TextBox252"
        Me.TextBox252.Size = New System.Drawing.Size(97, 31)
        Me.TextBox252.TabIndex = 228
        '
        'TextBox251
        '
        Me.TextBox251.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox251.Location = New System.Drawing.Point(302, 412)
        Me.TextBox251.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox251.Multiline = True
        Me.TextBox251.Name = "TextBox251"
        Me.TextBox251.Size = New System.Drawing.Size(110, 31)
        Me.TextBox251.TabIndex = 227
        '
        'TextBox250
        '
        Me.TextBox250.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox250.Location = New System.Drawing.Point(176, 412)
        Me.TextBox250.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox250.Multiline = True
        Me.TextBox250.Name = "TextBox250"
        Me.TextBox250.Size = New System.Drawing.Size(119, 31)
        Me.TextBox250.TabIndex = 226
        '
        'TextBox249
        '
        Me.TextBox249.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox249.Location = New System.Drawing.Point(81, 412)
        Me.TextBox249.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox249.Multiline = True
        Me.TextBox249.Name = "TextBox249"
        Me.TextBox249.Size = New System.Drawing.Size(88, 31)
        Me.TextBox249.TabIndex = 225
        '
        'TextBox248
        '
        Me.TextBox248.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox248.Location = New System.Drawing.Point(4, 412)
        Me.TextBox248.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox248.Multiline = True
        Me.TextBox248.Name = "TextBox248"
        Me.TextBox248.Size = New System.Drawing.Size(70, 31)
        Me.TextBox248.TabIndex = 224
        '
        'TextBox247
        '
        Me.TextBox247.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox247.Location = New System.Drawing.Point(1147, 380)
        Me.TextBox247.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox247.Multiline = True
        Me.TextBox247.Name = "TextBox247"
        Me.TextBox247.Size = New System.Drawing.Size(103, 27)
        Me.TextBox247.TabIndex = 223
        '
        'TextBox246
        '
        Me.TextBox246.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox246.Location = New System.Drawing.Point(1021, 380)
        Me.TextBox246.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox246.Multiline = True
        Me.TextBox246.Name = "TextBox246"
        Me.TextBox246.Size = New System.Drawing.Size(119, 27)
        Me.TextBox246.TabIndex = 222
        '
        'TextBox245
        '
        Me.TextBox245.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox245.Location = New System.Drawing.Point(901, 380)
        Me.TextBox245.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox245.Multiline = True
        Me.TextBox245.Name = "TextBox245"
        Me.TextBox245.Size = New System.Drawing.Size(113, 27)
        Me.TextBox245.TabIndex = 221
        '
        'TextBox244
        '
        Me.TextBox244.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox244.Location = New System.Drawing.Point(805, 380)
        Me.TextBox244.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox244.Multiline = True
        Me.TextBox244.Name = "TextBox244"
        Me.TextBox244.Size = New System.Drawing.Size(89, 27)
        Me.TextBox244.TabIndex = 220
        '
        'TextBox243
        '
        Me.TextBox243.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox243.Location = New System.Drawing.Point(731, 380)
        Me.TextBox243.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox243.Multiline = True
        Me.TextBox243.Name = "TextBox243"
        Me.TextBox243.Size = New System.Drawing.Size(67, 27)
        Me.TextBox243.TabIndex = 219
        '
        'TextBox242
        '
        Me.TextBox242.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox242.Location = New System.Drawing.Point(627, 380)
        Me.TextBox242.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox242.Multiline = True
        Me.TextBox242.Name = "TextBox242"
        Me.TextBox242.Size = New System.Drawing.Size(97, 27)
        Me.TextBox242.TabIndex = 218
        '
        'TextBox241
        '
        Me.TextBox241.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox241.Location = New System.Drawing.Point(523, 380)
        Me.TextBox241.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox241.Multiline = True
        Me.TextBox241.Name = "TextBox241"
        Me.TextBox241.Size = New System.Drawing.Size(97, 27)
        Me.TextBox241.TabIndex = 217
        '
        'TextBox240
        '
        Me.TextBox240.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox240.Location = New System.Drawing.Point(419, 380)
        Me.TextBox240.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox240.Multiline = True
        Me.TextBox240.Name = "TextBox240"
        Me.TextBox240.Size = New System.Drawing.Size(97, 27)
        Me.TextBox240.TabIndex = 216
        '
        'TextBox239
        '
        Me.TextBox239.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox239.Location = New System.Drawing.Point(302, 380)
        Me.TextBox239.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox239.Multiline = True
        Me.TextBox239.Name = "TextBox239"
        Me.TextBox239.Size = New System.Drawing.Size(110, 27)
        Me.TextBox239.TabIndex = 215
        '
        'TextBox238
        '
        Me.TextBox238.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox238.Location = New System.Drawing.Point(176, 380)
        Me.TextBox238.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox238.Multiline = True
        Me.TextBox238.Name = "TextBox238"
        Me.TextBox238.Size = New System.Drawing.Size(119, 27)
        Me.TextBox238.TabIndex = 214
        '
        'TextBox237
        '
        Me.TextBox237.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox237.Location = New System.Drawing.Point(81, 380)
        Me.TextBox237.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox237.Multiline = True
        Me.TextBox237.Name = "TextBox237"
        Me.TextBox237.Size = New System.Drawing.Size(88, 27)
        Me.TextBox237.TabIndex = 213
        '
        'TextBox236
        '
        Me.TextBox236.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox236.Location = New System.Drawing.Point(4, 380)
        Me.TextBox236.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox236.Multiline = True
        Me.TextBox236.Name = "TextBox236"
        Me.TextBox236.Size = New System.Drawing.Size(70, 27)
        Me.TextBox236.TabIndex = 212
        '
        'TextBox235
        '
        Me.TextBox235.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox235.Location = New System.Drawing.Point(1147, 348)
        Me.TextBox235.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox235.Multiline = True
        Me.TextBox235.Name = "TextBox235"
        Me.TextBox235.Size = New System.Drawing.Size(103, 27)
        Me.TextBox235.TabIndex = 211
        '
        'TextBox234
        '
        Me.TextBox234.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox234.Location = New System.Drawing.Point(1021, 348)
        Me.TextBox234.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox234.Multiline = True
        Me.TextBox234.Name = "TextBox234"
        Me.TextBox234.Size = New System.Drawing.Size(119, 27)
        Me.TextBox234.TabIndex = 210
        '
        'TextBox233
        '
        Me.TextBox233.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox233.Location = New System.Drawing.Point(901, 348)
        Me.TextBox233.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox233.Multiline = True
        Me.TextBox233.Name = "TextBox233"
        Me.TextBox233.Size = New System.Drawing.Size(113, 27)
        Me.TextBox233.TabIndex = 209
        '
        'TextBox232
        '
        Me.TextBox232.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox232.Location = New System.Drawing.Point(805, 348)
        Me.TextBox232.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox232.Multiline = True
        Me.TextBox232.Name = "TextBox232"
        Me.TextBox232.Size = New System.Drawing.Size(89, 27)
        Me.TextBox232.TabIndex = 208
        '
        'TextBox231
        '
        Me.TextBox231.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox231.Location = New System.Drawing.Point(731, 348)
        Me.TextBox231.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox231.Multiline = True
        Me.TextBox231.Name = "TextBox231"
        Me.TextBox231.Size = New System.Drawing.Size(67, 27)
        Me.TextBox231.TabIndex = 207
        '
        'TextBox230
        '
        Me.TextBox230.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox230.Location = New System.Drawing.Point(627, 348)
        Me.TextBox230.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox230.Multiline = True
        Me.TextBox230.Name = "TextBox230"
        Me.TextBox230.Size = New System.Drawing.Size(97, 27)
        Me.TextBox230.TabIndex = 206
        '
        'TextBox229
        '
        Me.TextBox229.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox229.Location = New System.Drawing.Point(523, 348)
        Me.TextBox229.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox229.Multiline = True
        Me.TextBox229.Name = "TextBox229"
        Me.TextBox229.Size = New System.Drawing.Size(97, 27)
        Me.TextBox229.TabIndex = 205
        '
        'TextBox228
        '
        Me.TextBox228.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox228.Location = New System.Drawing.Point(419, 348)
        Me.TextBox228.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox228.Multiline = True
        Me.TextBox228.Name = "TextBox228"
        Me.TextBox228.Size = New System.Drawing.Size(97, 27)
        Me.TextBox228.TabIndex = 204
        '
        'TextBox227
        '
        Me.TextBox227.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox227.Location = New System.Drawing.Point(302, 348)
        Me.TextBox227.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox227.Multiline = True
        Me.TextBox227.Name = "TextBox227"
        Me.TextBox227.Size = New System.Drawing.Size(110, 27)
        Me.TextBox227.TabIndex = 203
        '
        'TextBox226
        '
        Me.TextBox226.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox226.Location = New System.Drawing.Point(176, 348)
        Me.TextBox226.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox226.Multiline = True
        Me.TextBox226.Name = "TextBox226"
        Me.TextBox226.Size = New System.Drawing.Size(119, 27)
        Me.TextBox226.TabIndex = 202
        '
        'TextBox225
        '
        Me.TextBox225.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox225.Location = New System.Drawing.Point(81, 348)
        Me.TextBox225.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox225.Multiline = True
        Me.TextBox225.Name = "TextBox225"
        Me.TextBox225.Size = New System.Drawing.Size(88, 27)
        Me.TextBox225.TabIndex = 201
        '
        'TextBox224
        '
        Me.TextBox224.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox224.Location = New System.Drawing.Point(4, 348)
        Me.TextBox224.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox224.Multiline = True
        Me.TextBox224.Name = "TextBox224"
        Me.TextBox224.Size = New System.Drawing.Size(70, 27)
        Me.TextBox224.TabIndex = 200
        '
        'TextBox223
        '
        Me.TextBox223.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox223.Location = New System.Drawing.Point(1147, 316)
        Me.TextBox223.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox223.Multiline = True
        Me.TextBox223.Name = "TextBox223"
        Me.TextBox223.Size = New System.Drawing.Size(103, 27)
        Me.TextBox223.TabIndex = 199
        '
        'TextBox222
        '
        Me.TextBox222.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox222.Location = New System.Drawing.Point(1021, 316)
        Me.TextBox222.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox222.Multiline = True
        Me.TextBox222.Name = "TextBox222"
        Me.TextBox222.Size = New System.Drawing.Size(119, 27)
        Me.TextBox222.TabIndex = 198
        '
        'TextBox221
        '
        Me.TextBox221.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox221.Location = New System.Drawing.Point(901, 316)
        Me.TextBox221.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox221.Multiline = True
        Me.TextBox221.Name = "TextBox221"
        Me.TextBox221.Size = New System.Drawing.Size(113, 27)
        Me.TextBox221.TabIndex = 197
        '
        'TextBox220
        '
        Me.TextBox220.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox220.Location = New System.Drawing.Point(805, 316)
        Me.TextBox220.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox220.Multiline = True
        Me.TextBox220.Name = "TextBox220"
        Me.TextBox220.Size = New System.Drawing.Size(89, 27)
        Me.TextBox220.TabIndex = 196
        '
        'TextBox219
        '
        Me.TextBox219.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox219.Location = New System.Drawing.Point(731, 316)
        Me.TextBox219.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox219.Multiline = True
        Me.TextBox219.Name = "TextBox219"
        Me.TextBox219.Size = New System.Drawing.Size(67, 27)
        Me.TextBox219.TabIndex = 195
        '
        'TextBox218
        '
        Me.TextBox218.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox218.Location = New System.Drawing.Point(627, 316)
        Me.TextBox218.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox218.Multiline = True
        Me.TextBox218.Name = "TextBox218"
        Me.TextBox218.Size = New System.Drawing.Size(97, 27)
        Me.TextBox218.TabIndex = 194
        '
        'TextBox217
        '
        Me.TextBox217.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox217.Location = New System.Drawing.Point(523, 316)
        Me.TextBox217.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox217.Multiline = True
        Me.TextBox217.Name = "TextBox217"
        Me.TextBox217.Size = New System.Drawing.Size(97, 27)
        Me.TextBox217.TabIndex = 193
        '
        'TextBox216
        '
        Me.TextBox216.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox216.Location = New System.Drawing.Point(419, 316)
        Me.TextBox216.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox216.Multiline = True
        Me.TextBox216.Name = "TextBox216"
        Me.TextBox216.Size = New System.Drawing.Size(97, 27)
        Me.TextBox216.TabIndex = 192
        '
        'TextBox215
        '
        Me.TextBox215.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox215.Location = New System.Drawing.Point(302, 316)
        Me.TextBox215.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox215.Multiline = True
        Me.TextBox215.Name = "TextBox215"
        Me.TextBox215.Size = New System.Drawing.Size(110, 27)
        Me.TextBox215.TabIndex = 191
        '
        'TextBox214
        '
        Me.TextBox214.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox214.Location = New System.Drawing.Point(176, 316)
        Me.TextBox214.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox214.Multiline = True
        Me.TextBox214.Name = "TextBox214"
        Me.TextBox214.Size = New System.Drawing.Size(119, 27)
        Me.TextBox214.TabIndex = 190
        '
        'TextBox213
        '
        Me.TextBox213.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox213.Location = New System.Drawing.Point(81, 316)
        Me.TextBox213.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox213.Multiline = True
        Me.TextBox213.Name = "TextBox213"
        Me.TextBox213.Size = New System.Drawing.Size(88, 27)
        Me.TextBox213.TabIndex = 189
        '
        'TextBox212
        '
        Me.TextBox212.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox212.Location = New System.Drawing.Point(4, 316)
        Me.TextBox212.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox212.Multiline = True
        Me.TextBox212.Name = "TextBox212"
        Me.TextBox212.Size = New System.Drawing.Size(70, 27)
        Me.TextBox212.TabIndex = 188
        '
        'TextBox211
        '
        Me.TextBox211.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox211.Location = New System.Drawing.Point(1147, 284)
        Me.TextBox211.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox211.Multiline = True
        Me.TextBox211.Name = "TextBox211"
        Me.TextBox211.Size = New System.Drawing.Size(103, 27)
        Me.TextBox211.TabIndex = 187
        '
        'TextBox210
        '
        Me.TextBox210.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox210.Location = New System.Drawing.Point(1021, 284)
        Me.TextBox210.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox210.Multiline = True
        Me.TextBox210.Name = "TextBox210"
        Me.TextBox210.Size = New System.Drawing.Size(119, 27)
        Me.TextBox210.TabIndex = 186
        '
        'TextBox209
        '
        Me.TextBox209.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox209.Location = New System.Drawing.Point(901, 284)
        Me.TextBox209.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox209.Multiline = True
        Me.TextBox209.Name = "TextBox209"
        Me.TextBox209.Size = New System.Drawing.Size(113, 27)
        Me.TextBox209.TabIndex = 185
        '
        'TextBox208
        '
        Me.TextBox208.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox208.Location = New System.Drawing.Point(805, 284)
        Me.TextBox208.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox208.Multiline = True
        Me.TextBox208.Name = "TextBox208"
        Me.TextBox208.Size = New System.Drawing.Size(89, 27)
        Me.TextBox208.TabIndex = 184
        '
        'TextBox207
        '
        Me.TextBox207.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox207.Location = New System.Drawing.Point(731, 284)
        Me.TextBox207.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox207.Multiline = True
        Me.TextBox207.Name = "TextBox207"
        Me.TextBox207.Size = New System.Drawing.Size(67, 27)
        Me.TextBox207.TabIndex = 183
        '
        'TextBox206
        '
        Me.TextBox206.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox206.Location = New System.Drawing.Point(627, 284)
        Me.TextBox206.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox206.Multiline = True
        Me.TextBox206.Name = "TextBox206"
        Me.TextBox206.Size = New System.Drawing.Size(97, 27)
        Me.TextBox206.TabIndex = 182
        '
        'TextBox205
        '
        Me.TextBox205.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox205.Location = New System.Drawing.Point(523, 284)
        Me.TextBox205.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox205.Multiline = True
        Me.TextBox205.Name = "TextBox205"
        Me.TextBox205.Size = New System.Drawing.Size(97, 27)
        Me.TextBox205.TabIndex = 181
        '
        'TextBox204
        '
        Me.TextBox204.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox204.Location = New System.Drawing.Point(419, 284)
        Me.TextBox204.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox204.Multiline = True
        Me.TextBox204.Name = "TextBox204"
        Me.TextBox204.Size = New System.Drawing.Size(97, 27)
        Me.TextBox204.TabIndex = 180
        '
        'TextBox203
        '
        Me.TextBox203.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox203.Location = New System.Drawing.Point(302, 284)
        Me.TextBox203.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox203.Multiline = True
        Me.TextBox203.Name = "TextBox203"
        Me.TextBox203.Size = New System.Drawing.Size(110, 27)
        Me.TextBox203.TabIndex = 179
        '
        'TextBox202
        '
        Me.TextBox202.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox202.Location = New System.Drawing.Point(176, 284)
        Me.TextBox202.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox202.Multiline = True
        Me.TextBox202.Name = "TextBox202"
        Me.TextBox202.Size = New System.Drawing.Size(119, 27)
        Me.TextBox202.TabIndex = 178
        '
        'TextBox201
        '
        Me.TextBox201.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox201.Location = New System.Drawing.Point(81, 284)
        Me.TextBox201.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox201.Multiline = True
        Me.TextBox201.Name = "TextBox201"
        Me.TextBox201.Size = New System.Drawing.Size(88, 27)
        Me.TextBox201.TabIndex = 177
        '
        'TextBox200
        '
        Me.TextBox200.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox200.Location = New System.Drawing.Point(4, 284)
        Me.TextBox200.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox200.Multiline = True
        Me.TextBox200.Name = "TextBox200"
        Me.TextBox200.Size = New System.Drawing.Size(70, 27)
        Me.TextBox200.TabIndex = 176
        '
        'TextBox199
        '
        Me.TextBox199.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox199.Location = New System.Drawing.Point(1147, 252)
        Me.TextBox199.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox199.Multiline = True
        Me.TextBox199.Name = "TextBox199"
        Me.TextBox199.Size = New System.Drawing.Size(103, 27)
        Me.TextBox199.TabIndex = 175
        '
        'TextBox198
        '
        Me.TextBox198.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox198.Location = New System.Drawing.Point(1021, 252)
        Me.TextBox198.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox198.Multiline = True
        Me.TextBox198.Name = "TextBox198"
        Me.TextBox198.Size = New System.Drawing.Size(119, 27)
        Me.TextBox198.TabIndex = 174
        '
        'TextBox197
        '
        Me.TextBox197.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox197.Location = New System.Drawing.Point(901, 252)
        Me.TextBox197.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox197.Multiline = True
        Me.TextBox197.Name = "TextBox197"
        Me.TextBox197.Size = New System.Drawing.Size(113, 27)
        Me.TextBox197.TabIndex = 173
        '
        'TextBox196
        '
        Me.TextBox196.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox196.Location = New System.Drawing.Point(805, 252)
        Me.TextBox196.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox196.Multiline = True
        Me.TextBox196.Name = "TextBox196"
        Me.TextBox196.Size = New System.Drawing.Size(89, 27)
        Me.TextBox196.TabIndex = 172
        '
        'TextBox195
        '
        Me.TextBox195.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox195.Location = New System.Drawing.Point(731, 252)
        Me.TextBox195.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox195.Multiline = True
        Me.TextBox195.Name = "TextBox195"
        Me.TextBox195.Size = New System.Drawing.Size(67, 27)
        Me.TextBox195.TabIndex = 171
        '
        'TextBox194
        '
        Me.TextBox194.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox194.Location = New System.Drawing.Point(627, 252)
        Me.TextBox194.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox194.Multiline = True
        Me.TextBox194.Name = "TextBox194"
        Me.TextBox194.Size = New System.Drawing.Size(97, 27)
        Me.TextBox194.TabIndex = 170
        '
        'TextBox193
        '
        Me.TextBox193.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox193.Location = New System.Drawing.Point(523, 252)
        Me.TextBox193.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox193.Multiline = True
        Me.TextBox193.Name = "TextBox193"
        Me.TextBox193.Size = New System.Drawing.Size(97, 27)
        Me.TextBox193.TabIndex = 169
        '
        'TextBox192
        '
        Me.TextBox192.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox192.Location = New System.Drawing.Point(419, 252)
        Me.TextBox192.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox192.Multiline = True
        Me.TextBox192.Name = "TextBox192"
        Me.TextBox192.Size = New System.Drawing.Size(97, 27)
        Me.TextBox192.TabIndex = 168
        '
        'TextBox191
        '
        Me.TextBox191.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox191.Location = New System.Drawing.Point(302, 252)
        Me.TextBox191.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox191.Multiline = True
        Me.TextBox191.Name = "TextBox191"
        Me.TextBox191.Size = New System.Drawing.Size(110, 27)
        Me.TextBox191.TabIndex = 167
        '
        'TextBox190
        '
        Me.TextBox190.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox190.Location = New System.Drawing.Point(176, 252)
        Me.TextBox190.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox190.Multiline = True
        Me.TextBox190.Name = "TextBox190"
        Me.TextBox190.Size = New System.Drawing.Size(119, 27)
        Me.TextBox190.TabIndex = 166
        '
        'TextBox189
        '
        Me.TextBox189.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox189.Location = New System.Drawing.Point(81, 252)
        Me.TextBox189.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox189.Multiline = True
        Me.TextBox189.Name = "TextBox189"
        Me.TextBox189.Size = New System.Drawing.Size(88, 27)
        Me.TextBox189.TabIndex = 165
        '
        'TextBox188
        '
        Me.TextBox188.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox188.Location = New System.Drawing.Point(4, 252)
        Me.TextBox188.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox188.Multiline = True
        Me.TextBox188.Name = "TextBox188"
        Me.TextBox188.Size = New System.Drawing.Size(70, 27)
        Me.TextBox188.TabIndex = 164
        '
        'TextBox187
        '
        Me.TextBox187.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox187.Location = New System.Drawing.Point(1147, 220)
        Me.TextBox187.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox187.Multiline = True
        Me.TextBox187.Name = "TextBox187"
        Me.TextBox187.Size = New System.Drawing.Size(103, 27)
        Me.TextBox187.TabIndex = 163
        '
        'TextBox186
        '
        Me.TextBox186.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox186.Location = New System.Drawing.Point(1021, 220)
        Me.TextBox186.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox186.Multiline = True
        Me.TextBox186.Name = "TextBox186"
        Me.TextBox186.Size = New System.Drawing.Size(119, 27)
        Me.TextBox186.TabIndex = 162
        '
        'TextBox185
        '
        Me.TextBox185.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox185.Location = New System.Drawing.Point(901, 220)
        Me.TextBox185.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox185.Multiline = True
        Me.TextBox185.Name = "TextBox185"
        Me.TextBox185.Size = New System.Drawing.Size(113, 27)
        Me.TextBox185.TabIndex = 161
        '
        'TextBox184
        '
        Me.TextBox184.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox184.Location = New System.Drawing.Point(805, 220)
        Me.TextBox184.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox184.Multiline = True
        Me.TextBox184.Name = "TextBox184"
        Me.TextBox184.Size = New System.Drawing.Size(89, 27)
        Me.TextBox184.TabIndex = 160
        '
        'TextBox183
        '
        Me.TextBox183.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox183.Location = New System.Drawing.Point(731, 220)
        Me.TextBox183.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox183.Multiline = True
        Me.TextBox183.Name = "TextBox183"
        Me.TextBox183.Size = New System.Drawing.Size(67, 27)
        Me.TextBox183.TabIndex = 159
        '
        'TextBox182
        '
        Me.TextBox182.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox182.Location = New System.Drawing.Point(627, 220)
        Me.TextBox182.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox182.Multiline = True
        Me.TextBox182.Name = "TextBox182"
        Me.TextBox182.Size = New System.Drawing.Size(97, 27)
        Me.TextBox182.TabIndex = 158
        '
        'TextBox181
        '
        Me.TextBox181.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox181.Location = New System.Drawing.Point(523, 220)
        Me.TextBox181.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox181.Multiline = True
        Me.TextBox181.Name = "TextBox181"
        Me.TextBox181.Size = New System.Drawing.Size(97, 27)
        Me.TextBox181.TabIndex = 157
        '
        'TextBox180
        '
        Me.TextBox180.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox180.Location = New System.Drawing.Point(419, 220)
        Me.TextBox180.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox180.Multiline = True
        Me.TextBox180.Name = "TextBox180"
        Me.TextBox180.Size = New System.Drawing.Size(97, 27)
        Me.TextBox180.TabIndex = 156
        '
        'TextBox179
        '
        Me.TextBox179.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox179.Location = New System.Drawing.Point(302, 220)
        Me.TextBox179.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox179.Multiline = True
        Me.TextBox179.Name = "TextBox179"
        Me.TextBox179.Size = New System.Drawing.Size(110, 27)
        Me.TextBox179.TabIndex = 155
        '
        'TextBox178
        '
        Me.TextBox178.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox178.Location = New System.Drawing.Point(176, 220)
        Me.TextBox178.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox178.Multiline = True
        Me.TextBox178.Name = "TextBox178"
        Me.TextBox178.Size = New System.Drawing.Size(119, 27)
        Me.TextBox178.TabIndex = 154
        '
        'TextBox177
        '
        Me.TextBox177.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox177.Location = New System.Drawing.Point(81, 220)
        Me.TextBox177.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox177.Multiline = True
        Me.TextBox177.Name = "TextBox177"
        Me.TextBox177.Size = New System.Drawing.Size(88, 27)
        Me.TextBox177.TabIndex = 153
        '
        'TextBox176
        '
        Me.TextBox176.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox176.Location = New System.Drawing.Point(4, 220)
        Me.TextBox176.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox176.Multiline = True
        Me.TextBox176.Name = "TextBox176"
        Me.TextBox176.Size = New System.Drawing.Size(70, 27)
        Me.TextBox176.TabIndex = 152
        '
        'TextBox175
        '
        Me.TextBox175.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox175.Location = New System.Drawing.Point(1147, 188)
        Me.TextBox175.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox175.Multiline = True
        Me.TextBox175.Name = "TextBox175"
        Me.TextBox175.Size = New System.Drawing.Size(103, 27)
        Me.TextBox175.TabIndex = 151
        '
        'TextBox174
        '
        Me.TextBox174.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox174.Location = New System.Drawing.Point(1021, 188)
        Me.TextBox174.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox174.Multiline = True
        Me.TextBox174.Name = "TextBox174"
        Me.TextBox174.Size = New System.Drawing.Size(119, 27)
        Me.TextBox174.TabIndex = 150
        '
        'TextBox173
        '
        Me.TextBox173.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox173.Location = New System.Drawing.Point(901, 188)
        Me.TextBox173.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox173.Multiline = True
        Me.TextBox173.Name = "TextBox173"
        Me.TextBox173.Size = New System.Drawing.Size(113, 27)
        Me.TextBox173.TabIndex = 149
        '
        'TextBox172
        '
        Me.TextBox172.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox172.Location = New System.Drawing.Point(805, 188)
        Me.TextBox172.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox172.Multiline = True
        Me.TextBox172.Name = "TextBox172"
        Me.TextBox172.Size = New System.Drawing.Size(89, 27)
        Me.TextBox172.TabIndex = 148
        '
        'TextBox171
        '
        Me.TextBox171.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox171.Location = New System.Drawing.Point(731, 188)
        Me.TextBox171.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox171.Multiline = True
        Me.TextBox171.Name = "TextBox171"
        Me.TextBox171.Size = New System.Drawing.Size(67, 27)
        Me.TextBox171.TabIndex = 147
        '
        'TextBox170
        '
        Me.TextBox170.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox170.Location = New System.Drawing.Point(627, 188)
        Me.TextBox170.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox170.Multiline = True
        Me.TextBox170.Name = "TextBox170"
        Me.TextBox170.Size = New System.Drawing.Size(97, 27)
        Me.TextBox170.TabIndex = 146
        '
        'TextBox169
        '
        Me.TextBox169.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox169.Location = New System.Drawing.Point(523, 188)
        Me.TextBox169.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox169.Multiline = True
        Me.TextBox169.Name = "TextBox169"
        Me.TextBox169.Size = New System.Drawing.Size(97, 27)
        Me.TextBox169.TabIndex = 145
        '
        'TextBox168
        '
        Me.TextBox168.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox168.Location = New System.Drawing.Point(419, 188)
        Me.TextBox168.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox168.Multiline = True
        Me.TextBox168.Name = "TextBox168"
        Me.TextBox168.Size = New System.Drawing.Size(97, 27)
        Me.TextBox168.TabIndex = 144
        '
        'TextBox167
        '
        Me.TextBox167.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox167.Location = New System.Drawing.Point(302, 188)
        Me.TextBox167.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox167.Multiline = True
        Me.TextBox167.Name = "TextBox167"
        Me.TextBox167.Size = New System.Drawing.Size(110, 27)
        Me.TextBox167.TabIndex = 143
        '
        'TextBox166
        '
        Me.TextBox166.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox166.Location = New System.Drawing.Point(176, 188)
        Me.TextBox166.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox166.Multiline = True
        Me.TextBox166.Name = "TextBox166"
        Me.TextBox166.Size = New System.Drawing.Size(119, 27)
        Me.TextBox166.TabIndex = 142
        '
        'TextBox165
        '
        Me.TextBox165.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox165.Location = New System.Drawing.Point(81, 188)
        Me.TextBox165.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox165.Multiline = True
        Me.TextBox165.Name = "TextBox165"
        Me.TextBox165.Size = New System.Drawing.Size(88, 27)
        Me.TextBox165.TabIndex = 141
        '
        'TextBox164
        '
        Me.TextBox164.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox164.Location = New System.Drawing.Point(4, 188)
        Me.TextBox164.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox164.Multiline = True
        Me.TextBox164.Name = "TextBox164"
        Me.TextBox164.Size = New System.Drawing.Size(70, 27)
        Me.TextBox164.TabIndex = 140
        '
        'TextBox163
        '
        Me.TextBox163.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox163.Location = New System.Drawing.Point(1147, 156)
        Me.TextBox163.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox163.Multiline = True
        Me.TextBox163.Name = "TextBox163"
        Me.TextBox163.Size = New System.Drawing.Size(103, 27)
        Me.TextBox163.TabIndex = 139
        '
        'TextBox162
        '
        Me.TextBox162.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox162.Location = New System.Drawing.Point(1021, 156)
        Me.TextBox162.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox162.Multiline = True
        Me.TextBox162.Name = "TextBox162"
        Me.TextBox162.Size = New System.Drawing.Size(119, 27)
        Me.TextBox162.TabIndex = 138
        '
        'TextBox161
        '
        Me.TextBox161.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox161.Location = New System.Drawing.Point(901, 156)
        Me.TextBox161.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox161.Multiline = True
        Me.TextBox161.Name = "TextBox161"
        Me.TextBox161.Size = New System.Drawing.Size(113, 27)
        Me.TextBox161.TabIndex = 137
        '
        'TextBox160
        '
        Me.TextBox160.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox160.Location = New System.Drawing.Point(805, 156)
        Me.TextBox160.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox160.Multiline = True
        Me.TextBox160.Name = "TextBox160"
        Me.TextBox160.Size = New System.Drawing.Size(89, 27)
        Me.TextBox160.TabIndex = 136
        '
        'TextBox159
        '
        Me.TextBox159.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox159.Location = New System.Drawing.Point(731, 156)
        Me.TextBox159.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox159.Multiline = True
        Me.TextBox159.Name = "TextBox159"
        Me.TextBox159.Size = New System.Drawing.Size(67, 27)
        Me.TextBox159.TabIndex = 135
        '
        'TextBox158
        '
        Me.TextBox158.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox158.Location = New System.Drawing.Point(627, 156)
        Me.TextBox158.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox158.Multiline = True
        Me.TextBox158.Name = "TextBox158"
        Me.TextBox158.Size = New System.Drawing.Size(97, 27)
        Me.TextBox158.TabIndex = 134
        '
        'TextBox157
        '
        Me.TextBox157.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox157.Location = New System.Drawing.Point(523, 156)
        Me.TextBox157.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox157.Multiline = True
        Me.TextBox157.Name = "TextBox157"
        Me.TextBox157.Size = New System.Drawing.Size(97, 27)
        Me.TextBox157.TabIndex = 133
        '
        'TextBox156
        '
        Me.TextBox156.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox156.Location = New System.Drawing.Point(419, 156)
        Me.TextBox156.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox156.Multiline = True
        Me.TextBox156.Name = "TextBox156"
        Me.TextBox156.Size = New System.Drawing.Size(97, 27)
        Me.TextBox156.TabIndex = 132
        '
        'TextBox155
        '
        Me.TextBox155.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox155.Location = New System.Drawing.Point(302, 156)
        Me.TextBox155.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox155.Multiline = True
        Me.TextBox155.Name = "TextBox155"
        Me.TextBox155.Size = New System.Drawing.Size(110, 27)
        Me.TextBox155.TabIndex = 131
        '
        'TextBox154
        '
        Me.TextBox154.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox154.Location = New System.Drawing.Point(176, 156)
        Me.TextBox154.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox154.Multiline = True
        Me.TextBox154.Name = "TextBox154"
        Me.TextBox154.Size = New System.Drawing.Size(119, 27)
        Me.TextBox154.TabIndex = 130
        '
        'TextBox153
        '
        Me.TextBox153.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox153.Location = New System.Drawing.Point(81, 156)
        Me.TextBox153.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox153.Multiline = True
        Me.TextBox153.Name = "TextBox153"
        Me.TextBox153.Size = New System.Drawing.Size(88, 27)
        Me.TextBox153.TabIndex = 129
        '
        'TextBox152
        '
        Me.TextBox152.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox152.Location = New System.Drawing.Point(4, 156)
        Me.TextBox152.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox152.Multiline = True
        Me.TextBox152.Name = "TextBox152"
        Me.TextBox152.Size = New System.Drawing.Size(70, 27)
        Me.TextBox152.TabIndex = 128
        '
        'TextBox151
        '
        Me.TextBox151.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox151.Location = New System.Drawing.Point(1147, 124)
        Me.TextBox151.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox151.Multiline = True
        Me.TextBox151.Name = "TextBox151"
        Me.TextBox151.Size = New System.Drawing.Size(103, 27)
        Me.TextBox151.TabIndex = 127
        '
        'TextBox150
        '
        Me.TextBox150.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox150.Location = New System.Drawing.Point(1021, 124)
        Me.TextBox150.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox150.Multiline = True
        Me.TextBox150.Name = "TextBox150"
        Me.TextBox150.Size = New System.Drawing.Size(119, 27)
        Me.TextBox150.TabIndex = 126
        '
        'TextBox149
        '
        Me.TextBox149.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox149.Location = New System.Drawing.Point(901, 124)
        Me.TextBox149.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox149.Multiline = True
        Me.TextBox149.Name = "TextBox149"
        Me.TextBox149.Size = New System.Drawing.Size(113, 27)
        Me.TextBox149.TabIndex = 125
        '
        'TextBox148
        '
        Me.TextBox148.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox148.Location = New System.Drawing.Point(805, 124)
        Me.TextBox148.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox148.Multiline = True
        Me.TextBox148.Name = "TextBox148"
        Me.TextBox148.Size = New System.Drawing.Size(89, 27)
        Me.TextBox148.TabIndex = 124
        '
        'TextBox147
        '
        Me.TextBox147.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox147.Location = New System.Drawing.Point(731, 124)
        Me.TextBox147.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox147.Multiline = True
        Me.TextBox147.Name = "TextBox147"
        Me.TextBox147.Size = New System.Drawing.Size(67, 27)
        Me.TextBox147.TabIndex = 123
        '
        'TextBox146
        '
        Me.TextBox146.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox146.Location = New System.Drawing.Point(627, 124)
        Me.TextBox146.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox146.Multiline = True
        Me.TextBox146.Name = "TextBox146"
        Me.TextBox146.Size = New System.Drawing.Size(97, 27)
        Me.TextBox146.TabIndex = 122
        '
        'TextBox145
        '
        Me.TextBox145.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox145.Location = New System.Drawing.Point(523, 124)
        Me.TextBox145.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox145.Multiline = True
        Me.TextBox145.Name = "TextBox145"
        Me.TextBox145.Size = New System.Drawing.Size(97, 27)
        Me.TextBox145.TabIndex = 121
        '
        'TextBox144
        '
        Me.TextBox144.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox144.Location = New System.Drawing.Point(419, 124)
        Me.TextBox144.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox144.Multiline = True
        Me.TextBox144.Name = "TextBox144"
        Me.TextBox144.Size = New System.Drawing.Size(97, 27)
        Me.TextBox144.TabIndex = 120
        '
        'TextBox143
        '
        Me.TextBox143.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox143.Location = New System.Drawing.Point(302, 124)
        Me.TextBox143.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox143.Multiline = True
        Me.TextBox143.Name = "TextBox143"
        Me.TextBox143.Size = New System.Drawing.Size(110, 27)
        Me.TextBox143.TabIndex = 119
        '
        'TextBox142
        '
        Me.TextBox142.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox142.Location = New System.Drawing.Point(176, 124)
        Me.TextBox142.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox142.Multiline = True
        Me.TextBox142.Name = "TextBox142"
        Me.TextBox142.Size = New System.Drawing.Size(119, 27)
        Me.TextBox142.TabIndex = 118
        '
        'TextBox141
        '
        Me.TextBox141.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox141.Location = New System.Drawing.Point(81, 124)
        Me.TextBox141.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox141.Multiline = True
        Me.TextBox141.Name = "TextBox141"
        Me.TextBox141.Size = New System.Drawing.Size(88, 27)
        Me.TextBox141.TabIndex = 117
        '
        'TextBox140
        '
        Me.TextBox140.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox140.Location = New System.Drawing.Point(4, 124)
        Me.TextBox140.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox140.Multiline = True
        Me.TextBox140.Name = "TextBox140"
        Me.TextBox140.Size = New System.Drawing.Size(70, 27)
        Me.TextBox140.TabIndex = 116
        '
        'TextBox139
        '
        Me.TextBox139.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox139.Location = New System.Drawing.Point(1147, 92)
        Me.TextBox139.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox139.Multiline = True
        Me.TextBox139.Name = "TextBox139"
        Me.TextBox139.Size = New System.Drawing.Size(103, 27)
        Me.TextBox139.TabIndex = 115
        '
        'TextBox138
        '
        Me.TextBox138.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox138.Location = New System.Drawing.Point(1021, 92)
        Me.TextBox138.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox138.Multiline = True
        Me.TextBox138.Name = "TextBox138"
        Me.TextBox138.Size = New System.Drawing.Size(119, 27)
        Me.TextBox138.TabIndex = 114
        '
        'TextBox137
        '
        Me.TextBox137.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox137.Location = New System.Drawing.Point(901, 92)
        Me.TextBox137.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox137.Multiline = True
        Me.TextBox137.Name = "TextBox137"
        Me.TextBox137.Size = New System.Drawing.Size(113, 27)
        Me.TextBox137.TabIndex = 113
        '
        'TextBox136
        '
        Me.TextBox136.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox136.Location = New System.Drawing.Point(805, 92)
        Me.TextBox136.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox136.Multiline = True
        Me.TextBox136.Name = "TextBox136"
        Me.TextBox136.Size = New System.Drawing.Size(89, 27)
        Me.TextBox136.TabIndex = 112
        '
        'TextBox135
        '
        Me.TextBox135.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox135.Location = New System.Drawing.Point(731, 92)
        Me.TextBox135.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox135.Multiline = True
        Me.TextBox135.Name = "TextBox135"
        Me.TextBox135.Size = New System.Drawing.Size(67, 27)
        Me.TextBox135.TabIndex = 111
        '
        'TextBox134
        '
        Me.TextBox134.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox134.Location = New System.Drawing.Point(627, 92)
        Me.TextBox134.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox134.Multiline = True
        Me.TextBox134.Name = "TextBox134"
        Me.TextBox134.Size = New System.Drawing.Size(97, 27)
        Me.TextBox134.TabIndex = 110
        '
        'TextBox133
        '
        Me.TextBox133.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox133.Location = New System.Drawing.Point(523, 92)
        Me.TextBox133.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox133.Multiline = True
        Me.TextBox133.Name = "TextBox133"
        Me.TextBox133.Size = New System.Drawing.Size(97, 27)
        Me.TextBox133.TabIndex = 109
        '
        'TextBox132
        '
        Me.TextBox132.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox132.Location = New System.Drawing.Point(419, 92)
        Me.TextBox132.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox132.Multiline = True
        Me.TextBox132.Name = "TextBox132"
        Me.TextBox132.Size = New System.Drawing.Size(97, 27)
        Me.TextBox132.TabIndex = 108
        '
        'TextBox131
        '
        Me.TextBox131.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox131.Location = New System.Drawing.Point(302, 92)
        Me.TextBox131.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox131.Multiline = True
        Me.TextBox131.Name = "TextBox131"
        Me.TextBox131.Size = New System.Drawing.Size(110, 27)
        Me.TextBox131.TabIndex = 107
        '
        'TextBox130
        '
        Me.TextBox130.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox130.Location = New System.Drawing.Point(176, 92)
        Me.TextBox130.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox130.Multiline = True
        Me.TextBox130.Name = "TextBox130"
        Me.TextBox130.Size = New System.Drawing.Size(119, 27)
        Me.TextBox130.TabIndex = 106
        '
        'TextBox129
        '
        Me.TextBox129.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox129.Location = New System.Drawing.Point(81, 92)
        Me.TextBox129.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox129.Multiline = True
        Me.TextBox129.Name = "TextBox129"
        Me.TextBox129.Size = New System.Drawing.Size(88, 27)
        Me.TextBox129.TabIndex = 105
        '
        'TextBox128
        '
        Me.TextBox128.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox128.Location = New System.Drawing.Point(4, 92)
        Me.TextBox128.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox128.Multiline = True
        Me.TextBox128.Name = "TextBox128"
        Me.TextBox128.Size = New System.Drawing.Size(70, 27)
        Me.TextBox128.TabIndex = 104
        '
        'TextBox127
        '
        Me.TextBox127.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox127.Location = New System.Drawing.Point(1147, 60)
        Me.TextBox127.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox127.Multiline = True
        Me.TextBox127.Name = "TextBox127"
        Me.TextBox127.Size = New System.Drawing.Size(103, 27)
        Me.TextBox127.TabIndex = 103
        '
        'TextBox126
        '
        Me.TextBox126.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox126.Location = New System.Drawing.Point(1021, 60)
        Me.TextBox126.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox126.Multiline = True
        Me.TextBox126.Name = "TextBox126"
        Me.TextBox126.Size = New System.Drawing.Size(119, 27)
        Me.TextBox126.TabIndex = 102
        '
        'TextBox125
        '
        Me.TextBox125.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox125.Location = New System.Drawing.Point(901, 60)
        Me.TextBox125.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox125.Multiline = True
        Me.TextBox125.Name = "TextBox125"
        Me.TextBox125.Size = New System.Drawing.Size(113, 27)
        Me.TextBox125.TabIndex = 101
        '
        'TextBox124
        '
        Me.TextBox124.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox124.Location = New System.Drawing.Point(805, 60)
        Me.TextBox124.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox124.Multiline = True
        Me.TextBox124.Name = "TextBox124"
        Me.TextBox124.Size = New System.Drawing.Size(89, 27)
        Me.TextBox124.TabIndex = 100
        '
        'TextBox123
        '
        Me.TextBox123.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox123.Location = New System.Drawing.Point(731, 60)
        Me.TextBox123.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox123.Multiline = True
        Me.TextBox123.Name = "TextBox123"
        Me.TextBox123.Size = New System.Drawing.Size(67, 27)
        Me.TextBox123.TabIndex = 99
        '
        'TextBox122
        '
        Me.TextBox122.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox122.Location = New System.Drawing.Point(627, 60)
        Me.TextBox122.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox122.Multiline = True
        Me.TextBox122.Name = "TextBox122"
        Me.TextBox122.Size = New System.Drawing.Size(97, 27)
        Me.TextBox122.TabIndex = 98
        '
        'TextBox121
        '
        Me.TextBox121.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox121.Location = New System.Drawing.Point(523, 60)
        Me.TextBox121.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox121.Multiline = True
        Me.TextBox121.Name = "TextBox121"
        Me.TextBox121.Size = New System.Drawing.Size(97, 27)
        Me.TextBox121.TabIndex = 97
        '
        'TextBox120
        '
        Me.TextBox120.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox120.Location = New System.Drawing.Point(419, 60)
        Me.TextBox120.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox120.Multiline = True
        Me.TextBox120.Name = "TextBox120"
        Me.TextBox120.Size = New System.Drawing.Size(97, 27)
        Me.TextBox120.TabIndex = 96
        '
        'TextBox119
        '
        Me.TextBox119.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox119.Location = New System.Drawing.Point(302, 60)
        Me.TextBox119.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox119.Multiline = True
        Me.TextBox119.Name = "TextBox119"
        Me.TextBox119.Size = New System.Drawing.Size(110, 27)
        Me.TextBox119.TabIndex = 95
        '
        'TextBox118
        '
        Me.TextBox118.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox118.Location = New System.Drawing.Point(176, 60)
        Me.TextBox118.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox118.Multiline = True
        Me.TextBox118.Name = "TextBox118"
        Me.TextBox118.Size = New System.Drawing.Size(119, 27)
        Me.TextBox118.TabIndex = 94
        '
        'TextBox117
        '
        Me.TextBox117.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox117.Location = New System.Drawing.Point(81, 60)
        Me.TextBox117.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox117.Multiline = True
        Me.TextBox117.Name = "TextBox117"
        Me.TextBox117.Size = New System.Drawing.Size(88, 27)
        Me.TextBox117.TabIndex = 93
        '
        'TextBox116
        '
        Me.TextBox116.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox116.Location = New System.Drawing.Point(4, 60)
        Me.TextBox116.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox116.Multiline = True
        Me.TextBox116.Name = "TextBox116"
        Me.TextBox116.Size = New System.Drawing.Size(70, 27)
        Me.TextBox116.TabIndex = 92
        '
        'label17
        '
        Me.label17.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label17.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label17.Location = New System.Drawing.Point(1147, 1)
        Me.label17.Name = "label17"
        Me.label17.Size = New System.Drawing.Size(103, 56)
        Me.label17.TabIndex = 38
        Me.label17.Text = "Start" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "EARFCN1"
        Me.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label16
        '
        Me.label16.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label16.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label16.Location = New System.Drawing.Point(1021, 1)
        Me.label16.Name = "label16"
        Me.label16.Size = New System.Drawing.Size(119, 56)
        Me.label16.TabIndex = 37
        Me.label16.Text = "EARFCN_UL"
        Me.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label15
        '
        Me.label15.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label15.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label15.Location = New System.Drawing.Point(901, 1)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(113, 56)
        Me.label15.TabIndex = 36
        Me.label15.Text = "EARFCN_DL"
        Me.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label14
        '
        Me.label14.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label14.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label14.Location = New System.Drawing.Point(805, 1)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(89, 56)
        Me.label14.TabIndex = 35
        Me.label14.Text = "RACH"
        Me.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label13
        '
        Me.label13.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label13.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label13.Location = New System.Drawing.Point(731, 1)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(67, 56)
        Me.label13.TabIndex = 34
        Me.label13.Text = "PCI"
        Me.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label12
        '
        Me.label12.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label12.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label12.Location = New System.Drawing.Point(627, 1)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(97, 56)
        Me.label12.TabIndex = 33
        Me.label12.Text = "RS Boost"
        Me.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label11
        '
        Me.label11.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label11.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label11.Location = New System.Drawing.Point(523, 1)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(97, 56)
        Me.label11.TabIndex = 32
        Me.label11.Text = "Tx Path" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Assignment"
        Me.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label9
        '
        Me.label9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label9.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label9.Location = New System.Drawing.Point(419, 1)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(97, 56)
        Me.label9.TabIndex = 31
        Me.label9.Text = "Rx Diversity"
        Me.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label4
        '
        Me.label4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label4.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.Location = New System.Drawing.Point(302, 1)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(110, 56)
        Me.label4.TabIndex = 30
        Me.label4.Text = "Tx Diversity"
        Me.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label3
        '
        Me.label3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label3.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New System.Drawing.Point(176, 1)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(119, 56)
        Me.label3.TabIndex = 29
        Me.label3.Text = "Cell ID on" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " CDU30"
        Me.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label1
        '
        Me.label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label1.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(4, 1)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(70, 56)
        Me.label1.TabIndex = 27
        Me.label1.Text = "Current" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Cell ID"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label2
        '
        Me.label2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label2.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(81, 1)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(88, 56)
        Me.label2.TabIndex = 28
        Me.label2.Text = "FDD/TDD"
        Me.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TddLabel
        '
        Me.TddLabel.BackColor = System.Drawing.Color.White
        Me.TddLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TddLabel.Location = New System.Drawing.Point(8, 12)
        Me.TddLabel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TddLabel.Multiline = True
        Me.TddLabel.Name = "TddLabel"
        Me.TddLabel.Size = New System.Drawing.Size(59, 538)
        Me.TddLabel.TabIndex = 60
        Me.TddLabel.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "T" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "D" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "D"
        Me.TddLabel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'label5
        '
        Me.label5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label5.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label5.Location = New System.Drawing.Point(6, 5)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(214, 38)
        Me.label5.TabIndex = 2
        Me.label5.Text = "Cabinet"
        Me.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tableLayoutPanel5
        '
        Me.tableLayoutPanel5.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel5.ColumnCount = 1
        Me.tableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.27027!))
        Me.tableLayoutPanel5.Controls.Add(Me.textBox21, 0, 1)
        Me.tableLayoutPanel5.Controls.Add(Me.label10, 0, 0)
        Me.tableLayoutPanel5.Location = New System.Drawing.Point(988, 913)
        Me.tableLayoutPanel5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tableLayoutPanel5.Name = "tableLayoutPanel5"
        Me.tableLayoutPanel5.RowCount = 2
        Me.tableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.tableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.tableLayoutPanel5.Size = New System.Drawing.Size(200, 151)
        Me.tableLayoutPanel5.TabIndex = 40
        '
        'textBox21
        '
        Me.textBox21.Location = New System.Drawing.Point(6, 95)
        Me.textBox21.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.textBox21.Multiline = True
        Me.textBox21.Name = "textBox21"
        Me.textBox21.Size = New System.Drawing.Size(186, 49)
        Me.textBox21.TabIndex = 16
        '
        'label10
        '
        Me.label10.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label10.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label10.Location = New System.Drawing.Point(6, 7)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(187, 76)
        Me.label10.TabIndex = 23
        Me.label10.Text = "CDU30 BH" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Port"
        Me.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label6
        '
        Me.label6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label6.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label6.Location = New System.Drawing.Point(230, 5)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(215, 38)
        Me.label6.TabIndex = 3
        Me.label6.Text = "TAC(Hex)"
        Me.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cdu30Grow_Button
        '
        Me.cdu30Grow_Button.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.cdu30Grow_Button.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.cdu30Grow_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cdu30Grow_Button.Location = New System.Drawing.Point(1069, 386)
        Me.cdu30Grow_Button.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cdu30Grow_Button.Name = "cdu30Grow_Button"
        Me.cdu30Grow_Button.Size = New System.Drawing.Size(172, 60)
        Me.cdu30Grow_Button.TabIndex = 31
        Me.cdu30Grow_Button.Text = "CDU30 Grow" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Template" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.cdu30Grow_Button.UseVisualStyleBackColor = False
        '
        'tableLayoutPanel2
        '
        Me.tableLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel2.ColumnCount = 2
        Me.tableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel2.Controls.Add(Me.TacTextBox, 1, 1)
        Me.tableLayoutPanel2.Controls.Add(Me.CabinetTextBox, 0, 1)
        Me.tableLayoutPanel2.Controls.Add(Me.label6, 1, 0)
        Me.tableLayoutPanel2.Controls.Add(Me.label5, 0, 0)
        Me.tableLayoutPanel2.Location = New System.Drawing.Point(4, 234)
        Me.tableLayoutPanel2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tableLayoutPanel2.Name = "tableLayoutPanel2"
        Me.tableLayoutPanel2.RowCount = 2
        Me.tableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tableLayoutPanel2.Size = New System.Drawing.Size(452, 96)
        Me.tableLayoutPanel2.TabIndex = 26
        '
        'TargetPanel
        '
        Me.TargetPanel.AutoScroll = True
        Me.TargetPanel.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.TargetPanel.Controls.Add(Me.ENBID1TextBox)
        Me.TargetPanel.Controls.Add(Me.tableLayoutPanel6)
        Me.TargetPanel.Controls.Add(Me.tableLayoutPanel5)
        Me.TargetPanel.Controls.Add(Me.tableLayoutPanel4)
        Me.TargetPanel.Controls.Add(Me.tableLayoutPanel3)
        Me.TargetPanel.Controls.Add(Me.ENBID1_search)
        Me.TargetPanel.Controls.Add(Me.cdu30Grow_Button)
        Me.TargetPanel.Controls.Add(Me.Cdu30Env_button)
        Me.TargetPanel.Controls.Add(Me.Cdu30Atp)
        Me.TargetPanel.Controls.Add(Me.Cdu30Comm_Button)
        Me.TargetPanel.Controls.Add(Me.Cdu30Audit_Button)
        Me.TargetPanel.Controls.Add(Me.Name_idTable)
        Me.TargetPanel.Controls.Add(Me.tableLayoutPanel1)
        Me.TargetPanel.Controls.Add(Me.tableLayoutPanel2)
        Me.TargetPanel.Location = New System.Drawing.Point(1271, 4)
        Me.TargetPanel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TargetPanel.Name = "TargetPanel"
        Me.TargetPanel.Size = New System.Drawing.Size(1257, 1081)
        Me.TargetPanel.TabIndex = 2
        '
        'ENBID1TextBox
        '
        Me.ENBID1TextBox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ENBID1TextBox.Location = New System.Drawing.Point(4, 12)
        Me.ENBID1TextBox.Multiline = True
        Me.ENBID1TextBox.Name = "ENBID1TextBox"
        Me.ENBID1TextBox.Size = New System.Drawing.Size(295, 39)
        Me.ENBID1TextBox.TabIndex = 42
        Me.ENBID1TextBox.Text = "eNB ID"
        Me.ENBID1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Cdu30Env_button
        '
        Me.Cdu30Env_button.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Cdu30Env_button.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Cdu30Env_button.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cdu30Env_button.Location = New System.Drawing.Point(1069, 305)
        Me.Cdu30Env_button.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Cdu30Env_button.Name = "Cdu30Env_button"
        Me.Cdu30Env_button.Size = New System.Drawing.Size(172, 36)
        Me.Cdu30Env_button.TabIndex = 30
        Me.Cdu30Env_button.Text = "CDU30 ENV"
        Me.Cdu30Env_button.UseVisualStyleBackColor = False
        '
        'Cdu30Atp
        '
        Me.Cdu30Atp.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Cdu30Atp.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Cdu30Atp.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cdu30Atp.Location = New System.Drawing.Point(1069, 346)
        Me.Cdu30Atp.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Cdu30Atp.Name = "Cdu30Atp"
        Me.Cdu30Atp.Size = New System.Drawing.Size(172, 36)
        Me.Cdu30Atp.TabIndex = 29
        Me.Cdu30Atp.Text = "CDU30 ATP"
        Me.Cdu30Atp.UseVisualStyleBackColor = False
        '
        'Cdu30Comm_Button
        '
        Me.Cdu30Comm_Button.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Cdu30Comm_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cdu30Comm_Button.Location = New System.Drawing.Point(1069, 247)
        Me.Cdu30Comm_Button.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Cdu30Comm_Button.Name = "Cdu30Comm_Button"
        Me.Cdu30Comm_Button.Size = New System.Drawing.Size(172, 55)
        Me.Cdu30Comm_Button.TabIndex = 28
        Me.Cdu30Comm_Button.Text = "  CDU30" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Commissioning"
        Me.Cdu30Comm_Button.UseVisualStyleBackColor = True
        '
        'Cdu30Audit_Button
        '
        Me.Cdu30Audit_Button.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Cdu30Audit_Button.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Cdu30Audit_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cdu30Audit_Button.Location = New System.Drawing.Point(1069, 207)
        Me.Cdu30Audit_Button.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Cdu30Audit_Button.Name = "Cdu30Audit_Button"
        Me.Cdu30Audit_Button.Size = New System.Drawing.Size(172, 36)
        Me.Cdu30Audit_Button.TabIndex = 27
        Me.Cdu30Audit_Button.Text = "CDU30 Audit"
        Me.Cdu30Audit_Button.UseVisualStyleBackColor = False
        '
        'Name_idTable
        '
        Me.Name_idTable.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Name_idTable.BackColor = System.Drawing.Color.Transparent
        Me.Name_idTable.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.Name_idTable.ColumnCount = 2
        Me.Name_idTable.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.Name_idTable.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.Name_idTable.Controls.Add(Me.ENodeBName_label, 0, 0)
        Me.Name_idTable.Controls.Add(Me.textBox20, 0, 1)
        Me.Name_idTable.Controls.Add(Me.ENodeBNameTextbox, 1, 0)
        Me.Name_idTable.Controls.Add(Me.ENodeBIdTextbox, 1, 1)
        Me.Name_idTable.Location = New System.Drawing.Point(6, 109)
        Me.Name_idTable.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name_idTable.Name = "Name_idTable"
        Me.Name_idTable.RowCount = 2
        Me.Name_idTable.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.Name_idTable.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.Name_idTable.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.Name_idTable.Size = New System.Drawing.Size(548, 90)
        Me.Name_idTable.TabIndex = 24
        Me.Name_idTable.TabStop = True
        '
        'tableLayoutPanel1
        '
        Me.tableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel1.ColumnCount = 2
        Me.tableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel1.Controls.Add(Me.textBox24, 0, 1)
        Me.tableLayoutPanel1.Controls.Add(Me.textBox23, 0, 0)
        Me.tableLayoutPanel1.Controls.Add(Me.LsmNameTextbox, 1, 0)
        Me.tableLayoutPanel1.Controls.Add(Me.LsmrIpTextbox, 1, 1)
        Me.tableLayoutPanel1.Location = New System.Drawing.Point(630, 109)
        Me.tableLayoutPanel1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tableLayoutPanel1.Name = "tableLayoutPanel1"
        Me.tableLayoutPanel1.RowCount = 2
        Me.tableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tableLayoutPanel1.Size = New System.Drawing.Size(548, 90)
        Me.tableLayoutPanel1.TabIndex = 25
        '
        'textBox39
        '
        Me.textBox39.Location = New System.Drawing.Point(192, 68)
        Me.textBox39.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox39.Multiline = True
        Me.textBox39.Name = "textBox39"
        Me.textBox39.Size = New System.Drawing.Size(176, 60)
        Me.textBox39.TabIndex = 16
        '
        'textBox40
        '
        Me.textBox40.Location = New System.Drawing.Point(6, 68)
        Me.textBox40.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox40.Multiline = True
        Me.textBox40.Name = "textBox40"
        Me.textBox40.Size = New System.Drawing.Size(177, 60)
        Me.textBox40.TabIndex = 16
        '
        'label38
        '
        Me.label38.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label38.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label38.Location = New System.Drawing.Point(192, 4)
        Me.label38.Name = "label38"
        Me.label38.Size = New System.Drawing.Size(176, 57)
        Me.label38.TabIndex = 3
        Me.label38.Text = "eNB S&B" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "VLAN"
        Me.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label39
        '
        Me.label39.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label39.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label39.Location = New System.Drawing.Point(6, 6)
        Me.label39.Name = "label39"
        Me.label39.Size = New System.Drawing.Size(177, 53)
        Me.label39.TabIndex = 23
        Me.label39.Text = "eNB OAM" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "VLAN"
        Me.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tableLayoutPanel17
        '
        Me.tableLayoutPanel17.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tableLayoutPanel17.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel17.ColumnCount = 2
        Me.tableLayoutPanel17.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.27027!))
        Me.tableLayoutPanel17.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.72973!))
        Me.tableLayoutPanel17.Controls.Add(Me.textBox39, 1, 1)
        Me.tableLayoutPanel17.Controls.Add(Me.textBox40, 0, 1)
        Me.tableLayoutPanel17.Controls.Add(Me.label38, 1, 0)
        Me.tableLayoutPanel17.Controls.Add(Me.label39, 0, 0)
        Me.tableLayoutPanel17.Location = New System.Drawing.Point(657, 202)
        Me.tableLayoutPanel17.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tableLayoutPanel17.Name = "tableLayoutPanel17"
        Me.tableLayoutPanel17.RowCount = 2
        Me.tableLayoutPanel17.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.90511!))
        Me.tableLayoutPanel17.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.09489!))
        Me.tableLayoutPanel17.Size = New System.Drawing.Size(374, 133)
        Me.tableLayoutPanel17.TabIndex = 61
        '
        'textBox38
        '
        Me.textBox38.Location = New System.Drawing.Point(6, 84)
        Me.textBox38.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox38.Multiline = True
        Me.textBox38.Name = "textBox38"
        Me.textBox38.Size = New System.Drawing.Size(159, 48)
        Me.textBox38.TabIndex = 16
        '
        'label37
        '
        Me.label37.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label37.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label37.Location = New System.Drawing.Point(6, 6)
        Me.label37.Name = "label37"
        Me.label37.Size = New System.Drawing.Size(159, 69)
        Me.label37.TabIndex = 23
        Me.label37.Text = "CDU30 BH" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Port"
        Me.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tableLayoutPanel16
        '
        Me.tableLayoutPanel16.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.tableLayoutPanel16.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel16.ColumnCount = 1
        Me.tableLayoutPanel16.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.27027!))
        Me.tableLayoutPanel16.Controls.Add(Me.textBox38, 0, 1)
        Me.tableLayoutPanel16.Controls.Add(Me.label37, 0, 0)
        Me.tableLayoutPanel16.Location = New System.Drawing.Point(1056, 198)
        Me.tableLayoutPanel16.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tableLayoutPanel16.Name = "tableLayoutPanel16"
        Me.tableLayoutPanel16.RowCount = 2
        Me.tableLayoutPanel16.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.tableLayoutPanel16.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.tableLayoutPanel16.Size = New System.Drawing.Size(171, 137)
        Me.tableLayoutPanel16.TabIndex = 62
        '
        'tableLayoutPanel15
        '
        Me.tableLayoutPanel15.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tableLayoutPanel15.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel15.ColumnCount = 2
        Me.tableLayoutPanel15.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel15.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel15.Controls.Add(Me.textBox36, 1, 1)
        Me.tableLayoutPanel15.Controls.Add(Me.textBox37, 0, 1)
        Me.tableLayoutPanel15.Controls.Add(Me.label35, 1, 0)
        Me.tableLayoutPanel15.Controls.Add(Me.label36, 0, 0)
        Me.tableLayoutPanel15.Location = New System.Drawing.Point(78, 244)
        Me.tableLayoutPanel15.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tableLayoutPanel15.Name = "tableLayoutPanel15"
        Me.tableLayoutPanel15.RowCount = 2
        Me.tableLayoutPanel15.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel15.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel15.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tableLayoutPanel15.Size = New System.Drawing.Size(452, 98)
        Me.tableLayoutPanel15.TabIndex = 63
        '
        'textBox36
        '
        Me.textBox36.Location = New System.Drawing.Point(230, 52)
        Me.textBox36.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox36.Multiline = True
        Me.textBox36.Name = "textBox36"
        Me.textBox36.Size = New System.Drawing.Size(216, 41)
        Me.textBox36.TabIndex = 16
        '
        'textBox37
        '
        Me.textBox37.Location = New System.Drawing.Point(6, 52)
        Me.textBox37.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox37.Multiline = True
        Me.textBox37.Name = "textBox37"
        Me.textBox37.Size = New System.Drawing.Size(215, 41)
        Me.textBox37.TabIndex = 16
        '
        'label35
        '
        Me.label35.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label35.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label35.Location = New System.Drawing.Point(230, 6)
        Me.label35.Name = "label35"
        Me.label35.Size = New System.Drawing.Size(215, 38)
        Me.label35.TabIndex = 3
        Me.label35.Text = "TAC(Hex)"
        Me.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label36
        '
        Me.label36.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label36.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label36.Location = New System.Drawing.Point(6, 6)
        Me.label36.Name = "label36"
        Me.label36.Size = New System.Drawing.Size(214, 38)
        Me.label36.TabIndex = 2
        Me.label36.Text = "Cabinet"
        Me.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'panel2
        '
        Me.panel2.AutoScroll = True
        Me.panel2.BackColor = System.Drawing.Color.DarkSalmon
        Me.panel2.Controls.Add(Me.TableLayoutPanel12)
        Me.panel2.Controls.Add(Me.TableLayoutPanel11)
        Me.panel2.Controls.Add(Me.button2)
        Me.panel2.Controls.Add(Me.ENBIdName)
        Me.panel2.Controls.Add(Me.tableLayoutPanel7)
        Me.panel2.Controls.Add(Me.tableLayoutPanel8)
        Me.panel2.Controls.Add(Me.tableLayoutPanel9)
        Me.panel2.Controls.Add(Me.tableLayoutPanel10)
        Me.panel2.Controls.Add(Me.label30)
        Me.panel2.Controls.Add(Me.name_id)
        Me.panel2.Controls.Add(Me.TddLabel)
        Me.panel2.Location = New System.Drawing.Point(11, 4)
        Me.panel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(1246, 568)
        Me.panel2.TabIndex = 3
        '
        'TableLayoutPanel12
        '
        Me.TableLayoutPanel12.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel12.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel12.ColumnCount = 2
        Me.TableLayoutPanel12.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.51568!))
        Me.TableLayoutPanel12.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.48432!))
        Me.TableLayoutPanel12.Controls.Add(Me.Label31, 0, 3)
        Me.TableLayoutPanel12.Controls.Add(Me.Label32, 0, 0)
        Me.TableLayoutPanel12.Controls.Add(Me.Label33, 0, 1)
        Me.TableLayoutPanel12.Controls.Add(Me.Label34, 0, 2)
        Me.TableLayoutPanel12.Controls.Add(Me.TextBox64, 1, 0)
        Me.TableLayoutPanel12.Controls.Add(Me.TextBox65, 1, 1)
        Me.TableLayoutPanel12.Controls.Add(Me.TextBox66, 1, 2)
        Me.TableLayoutPanel12.Controls.Add(Me.TextBox67, 1, 3)
        Me.TableLayoutPanel12.Location = New System.Drawing.Point(662, 432)
        Me.TableLayoutPanel12.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel12.Name = "TableLayoutPanel12"
        Me.TableLayoutPanel12.RowCount = 4
        Me.TableLayoutPanel12.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel12.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel12.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel12.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel12.Size = New System.Drawing.Size(575, 123)
        Me.TableLayoutPanel12.TabIndex = 72
        '
        'Label31
        '
        Me.Label31.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label31.BackColor = System.Drawing.Color.OldLace
        Me.Label31.Location = New System.Drawing.Point(4, 91)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(260, 31)
        Me.Label31.TabIndex = 12
        Me.Label31.Text = "MMBS S&B IP"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label32
        '
        Me.Label32.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label32.BackColor = System.Drawing.Color.OldLace
        Me.Label32.Location = New System.Drawing.Point(4, 1)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(260, 29)
        Me.Label32.TabIndex = 9
        Me.Label32.Text = "CSROAMIP"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label33
        '
        Me.Label33.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label33.BackColor = System.Drawing.Color.OldLace
        Me.Label33.Location = New System.Drawing.Point(4, 31)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(260, 29)
        Me.Label33.TabIndex = 10
        Me.Label33.Text = "MMBS OAMIP"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label34
        '
        Me.Label34.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label34.BackColor = System.Drawing.Color.OldLace
        Me.Label34.Location = New System.Drawing.Point(4, 61)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(260, 29)
        Me.Label34.TabIndex = 11
        Me.Label34.Text = "CSR&BIP "
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox64
        '
        Me.TextBox64.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox64.Location = New System.Drawing.Point(271, 3)
        Me.TextBox64.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox64.Multiline = True
        Me.TextBox64.Name = "TextBox64"
        Me.TextBox64.Size = New System.Drawing.Size(300, 25)
        Me.TextBox64.TabIndex = 19
        '
        'TextBox65
        '
        Me.TextBox65.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox65.Location = New System.Drawing.Point(271, 33)
        Me.TextBox65.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox65.Multiline = True
        Me.TextBox65.Name = "TextBox65"
        Me.TextBox65.Size = New System.Drawing.Size(300, 25)
        Me.TextBox65.TabIndex = 20
        '
        'TextBox66
        '
        Me.TextBox66.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox66.Location = New System.Drawing.Point(271, 63)
        Me.TextBox66.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox66.Multiline = True
        Me.TextBox66.Name = "TextBox66"
        Me.TextBox66.Size = New System.Drawing.Size(300, 25)
        Me.TextBox66.TabIndex = 21
        '
        'TextBox67
        '
        Me.TextBox67.Location = New System.Drawing.Point(271, 93)
        Me.TextBox67.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox67.Multiline = True
        Me.TextBox67.Name = "TextBox67"
        Me.TextBox67.Size = New System.Drawing.Size(300, 27)
        Me.TextBox67.TabIndex = 22
        '
        'TableLayoutPanel11
        '
        Me.TableLayoutPanel11.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel11.ColumnCount = 4
        Me.TableLayoutPanel11.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel11.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel11.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 122.0!))
        Me.TableLayoutPanel11.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 168.0!))
        Me.TableLayoutPanel11.Controls.Add(Me.TextBox55, 0, 3)
        Me.TableLayoutPanel11.Controls.Add(Me.Label23, 0, 1)
        Me.TableLayoutPanel11.Controls.Add(Me.Label24, 2, 0)
        Me.TableLayoutPanel11.Controls.Add(Me.Label25, 3, 0)
        Me.TableLayoutPanel11.Controls.Add(Me.Label26, 0, 0)
        Me.TableLayoutPanel11.Controls.Add(Me.Label27, 1, 0)
        Me.TableLayoutPanel11.Controls.Add(Me.Label28, 0, 2)
        Me.TableLayoutPanel11.Controls.Add(Me.TextBox56, 1, 1)
        Me.TableLayoutPanel11.Controls.Add(Me.TextBox57, 2, 1)
        Me.TableLayoutPanel11.Controls.Add(Me.TextBox58, 3, 1)
        Me.TableLayoutPanel11.Controls.Add(Me.TextBox59, 1, 3)
        Me.TableLayoutPanel11.Controls.Add(Me.TextBox60, 1, 2)
        Me.TableLayoutPanel11.Controls.Add(Me.TextBox61, 2, 2)
        Me.TableLayoutPanel11.Controls.Add(Me.TextBox62, 3, 2)
        Me.TableLayoutPanel11.Controls.Add(Me.TextBox63, 2, 3)
        Me.TableLayoutPanel11.Controls.Add(Me.Label29, 0, 3)
        Me.TableLayoutPanel11.Location = New System.Drawing.Point(81, 398)
        Me.TableLayoutPanel11.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel11.Name = "TableLayoutPanel11"
        Me.TableLayoutPanel11.RowCount = 4
        Me.TableLayoutPanel11.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.50505!))
        Me.TableLayoutPanel11.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.49495!))
        Me.TableLayoutPanel11.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37.0!))
        Me.TableLayoutPanel11.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.TableLayoutPanel11.Size = New System.Drawing.Size(576, 157)
        Me.TableLayoutPanel11.TabIndex = 71
        '
        'TextBox55
        '
        Me.TextBox55.Location = New System.Drawing.Point(145, 125)
        Me.TextBox55.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox55.Multiline = True
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.Size = New System.Drawing.Size(134, 29)
        Me.TextBox55.TabIndex = 25
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label23.BackColor = System.Drawing.Color.OldLace
        Me.Label23.Location = New System.Drawing.Point(4, 43)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(134, 41)
        Me.Label23.TabIndex = 8
        Me.Label23.Text = "Alpha"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label24
        '
        Me.Label24.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label24.BackColor = System.Drawing.Color.DarkGray
        Me.Label24.Location = New System.Drawing.Point(286, 2)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(116, 38)
        Me.Label24.TabIndex = 7
        Me.Label24.Text = "RACH"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label25.BackColor = System.Drawing.Color.DarkGray
        Me.Label25.Location = New System.Drawing.Point(414, 2)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(153, 38)
        Me.Label25.TabIndex = 6
        Me.Label25.Text = "Tilt"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label26.BackColor = System.Drawing.Color.DarkGray
        Me.Label26.Location = New System.Drawing.Point(4, 2)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(134, 38)
        Me.Label26.TabIndex = 5
        Me.Label26.Text = "Sector"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label27
        '
        Me.Label27.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label27.BackColor = System.Drawing.Color.DarkGray
        Me.Label27.Location = New System.Drawing.Point(145, 2)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(134, 38)
        Me.Label27.TabIndex = 4
        Me.Label27.Text = "PCI"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label28
        '
        Me.Label28.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label28.BackColor = System.Drawing.Color.OldLace
        Me.Label28.Location = New System.Drawing.Point(4, 87)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(134, 33)
        Me.Label28.TabIndex = 9
        Me.Label28.Text = "Beta"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox56
        '
        Me.TextBox56.Location = New System.Drawing.Point(145, 45)
        Me.TextBox56.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox56.Multiline = True
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Size = New System.Drawing.Size(134, 37)
        Me.TextBox56.TabIndex = 17
        '
        'TextBox57
        '
        Me.TextBox57.Location = New System.Drawing.Point(286, 45)
        Me.TextBox57.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox57.Multiline = True
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Size = New System.Drawing.Size(116, 37)
        Me.TextBox57.TabIndex = 18
        '
        'TextBox58
        '
        Me.TextBox58.Location = New System.Drawing.Point(409, 45)
        Me.TextBox58.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox58.Multiline = True
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Size = New System.Drawing.Size(153, 37)
        Me.TextBox58.TabIndex = 19
        '
        'TextBox59
        '
        Me.TextBox59.Location = New System.Drawing.Point(286, 125)
        Me.TextBox59.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox59.Multiline = True
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Size = New System.Drawing.Size(116, 29)
        Me.TextBox59.TabIndex = 20
        '
        'TextBox60
        '
        Me.TextBox60.Location = New System.Drawing.Point(145, 87)
        Me.TextBox60.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox60.Multiline = True
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Size = New System.Drawing.Size(134, 33)
        Me.TextBox60.TabIndex = 21
        '
        'TextBox61
        '
        Me.TextBox61.Location = New System.Drawing.Point(286, 87)
        Me.TextBox61.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox61.Multiline = True
        Me.TextBox61.Name = "TextBox61"
        Me.TextBox61.Size = New System.Drawing.Size(116, 33)
        Me.TextBox61.TabIndex = 22
        '
        'TextBox62
        '
        Me.TextBox62.Location = New System.Drawing.Point(409, 87)
        Me.TextBox62.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox62.Multiline = True
        Me.TextBox62.Name = "TextBox62"
        Me.TextBox62.Size = New System.Drawing.Size(153, 33)
        Me.TextBox62.TabIndex = 23
        '
        'TextBox63
        '
        Me.TextBox63.Location = New System.Drawing.Point(409, 125)
        Me.TextBox63.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox63.Multiline = True
        Me.TextBox63.Name = "TextBox63"
        Me.TextBox63.Size = New System.Drawing.Size(153, 29)
        Me.TextBox63.TabIndex = 24
        '
        'Label29
        '
        Me.Label29.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label29.BackColor = System.Drawing.Color.OldLace
        Me.Label29.Location = New System.Drawing.Point(4, 123)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(134, 33)
        Me.Label29.TabIndex = 10
        Me.Label29.Text = "Gamma"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'button2
        '
        Me.button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.button2.Location = New System.Drawing.Point(994, 14)
        Me.button2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(236, 46)
        Me.button2.TabIndex = 70
        Me.button2.Text = "TDD Audit"
        Me.button2.UseVisualStyleBackColor = True
        '
        'ENBIdName
        '
        Me.ENBIdName.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.ENBIdName.Location = New System.Drawing.Point(81, 14)
        Me.ENBIdName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ENBIdName.Multiline = True
        Me.ENBIdName.Name = "ENBIdName"
        Me.ENBIdName.Size = New System.Drawing.Size(336, 42)
        Me.ENBIdName.TabIndex = 69
        Me.ENBIdName.Text = "eNB ID 1 "
        Me.ENBIdName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tableLayoutPanel7
        '
        Me.tableLayoutPanel7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tableLayoutPanel7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel7.ColumnCount = 2
        Me.tableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel7.Controls.Add(Me.textBox1, 0, 1)
        Me.tableLayoutPanel7.Controls.Add(Me.textBox4, 0, 0)
        Me.tableLayoutPanel7.Controls.Add(Me.textBox8, 1, 0)
        Me.tableLayoutPanel7.Controls.Add(Me.textBox7, 1, 1)
        Me.tableLayoutPanel7.Location = New System.Drawing.Point(84, 159)
        Me.tableLayoutPanel7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tableLayoutPanel7.Name = "tableLayoutPanel7"
        Me.tableLayoutPanel7.RowCount = 2
        Me.tableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tableLayoutPanel7.Size = New System.Drawing.Size(548, 84)
        Me.tableLayoutPanel7.TabIndex = 68
        '
        'textBox1
        '
        Me.textBox1.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox1.Location = New System.Drawing.Point(6, 45)
        Me.textBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox1.Multiline = True
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(262, 34)
        Me.textBox1.TabIndex = 28
        Me.textBox1.Text = "LSMR IP"
        Me.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox4
        '
        Me.textBox4.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox4.Location = New System.Drawing.Point(6, 5)
        Me.textBox4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox4.Multiline = True
        Me.textBox4.Name = "textBox4"
        Me.textBox4.Size = New System.Drawing.Size(262, 33)
        Me.textBox4.TabIndex = 29
        Me.textBox4.Text = "LSM Name"
        Me.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox8
        '
        Me.textBox8.Location = New System.Drawing.Point(278, 5)
        Me.textBox8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox8.Multiline = True
        Me.textBox8.Name = "textBox8"
        Me.textBox8.Size = New System.Drawing.Size(264, 33)
        Me.textBox8.TabIndex = 16
        '
        'textBox7
        '
        Me.textBox7.Location = New System.Drawing.Point(278, 45)
        Me.textBox7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox7.Multiline = True
        Me.textBox7.Name = "textBox7"
        Me.textBox7.Size = New System.Drawing.Size(264, 34)
        Me.textBox7.TabIndex = 16
        '
        'tableLayoutPanel8
        '
        Me.tableLayoutPanel8.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.tableLayoutPanel8.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel8.ColumnCount = 1
        Me.tableLayoutPanel8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.27027!))
        Me.tableLayoutPanel8.Controls.Add(Me.textBox5, 0, 1)
        Me.tableLayoutPanel8.Controls.Add(Me.label18, 0, 0)
        Me.tableLayoutPanel8.Location = New System.Drawing.Point(1065, 238)
        Me.tableLayoutPanel8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tableLayoutPanel8.Name = "tableLayoutPanel8"
        Me.tableLayoutPanel8.RowCount = 2
        Me.tableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.tableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.tableLayoutPanel8.Size = New System.Drawing.Size(171, 144)
        Me.tableLayoutPanel8.TabIndex = 66
        '
        'textBox5
        '
        Me.textBox5.Location = New System.Drawing.Point(6, 89)
        Me.textBox5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox5.Multiline = True
        Me.textBox5.Name = "textBox5"
        Me.textBox5.Size = New System.Drawing.Size(159, 50)
        Me.textBox5.TabIndex = 16
        '
        'label18
        '
        Me.label18.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label18.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label18.Location = New System.Drawing.Point(6, 4)
        Me.label18.Name = "label18"
        Me.label18.Size = New System.Drawing.Size(158, 78)
        Me.label18.TabIndex = 23
        Me.label18.Text = "CDU30 BH" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Port"
        Me.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tableLayoutPanel9
        '
        Me.tableLayoutPanel9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tableLayoutPanel9.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel9.ColumnCount = 2
        Me.tableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.27027!))
        Me.tableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.72973!))
        Me.tableLayoutPanel9.Controls.Add(Me.textBox6, 1, 1)
        Me.tableLayoutPanel9.Controls.Add(Me.textBox9, 0, 1)
        Me.tableLayoutPanel9.Controls.Add(Me.label19, 1, 0)
        Me.tableLayoutPanel9.Controls.Add(Me.label20, 0, 0)
        Me.tableLayoutPanel9.Location = New System.Drawing.Point(680, 238)
        Me.tableLayoutPanel9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tableLayoutPanel9.Name = "tableLayoutPanel9"
        Me.tableLayoutPanel9.RowCount = 2
        Me.tableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.tableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.tableLayoutPanel9.Size = New System.Drawing.Size(374, 144)
        Me.tableLayoutPanel9.TabIndex = 65
        '
        'textBox6
        '
        Me.textBox6.Location = New System.Drawing.Point(192, 89)
        Me.textBox6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox6.Multiline = True
        Me.textBox6.Name = "textBox6"
        Me.textBox6.Size = New System.Drawing.Size(176, 50)
        Me.textBox6.TabIndex = 16
        '
        'textBox9
        '
        Me.textBox9.Location = New System.Drawing.Point(6, 89)
        Me.textBox9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox9.Multiline = True
        Me.textBox9.Name = "textBox9"
        Me.textBox9.Size = New System.Drawing.Size(177, 50)
        Me.textBox9.TabIndex = 16
        '
        'label19
        '
        Me.label19.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label19.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label19.Location = New System.Drawing.Point(193, 4)
        Me.label19.Name = "label19"
        Me.label19.Size = New System.Drawing.Size(174, 78)
        Me.label19.TabIndex = 3
        Me.label19.Text = "eNB S&B" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "VLAN"
        Me.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label20
        '
        Me.label20.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label20.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label20.Location = New System.Drawing.Point(7, 4)
        Me.label20.Name = "label20"
        Me.label20.Size = New System.Drawing.Size(174, 78)
        Me.label20.TabIndex = 23
        Me.label20.Text = "eNB OAM" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "VLAN"
        Me.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tableLayoutPanel10
        '
        Me.tableLayoutPanel10.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tableLayoutPanel10.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel10.ColumnCount = 2
        Me.tableLayoutPanel10.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel10.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel10.Controls.Add(Me.textBox10, 1, 1)
        Me.tableLayoutPanel10.Controls.Add(Me.textBox11, 0, 1)
        Me.tableLayoutPanel10.Controls.Add(Me.label21, 1, 0)
        Me.tableLayoutPanel10.Controls.Add(Me.label22, 0, 0)
        Me.tableLayoutPanel10.Location = New System.Drawing.Point(83, 284)
        Me.tableLayoutPanel10.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tableLayoutPanel10.Name = "tableLayoutPanel10"
        Me.tableLayoutPanel10.RowCount = 2
        Me.tableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tableLayoutPanel10.Size = New System.Drawing.Size(452, 98)
        Me.tableLayoutPanel10.TabIndex = 67
        '
        'textBox10
        '
        Me.textBox10.Location = New System.Drawing.Point(230, 52)
        Me.textBox10.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox10.Multiline = True
        Me.textBox10.Name = "textBox10"
        Me.textBox10.Size = New System.Drawing.Size(216, 41)
        Me.textBox10.TabIndex = 16
        '
        'textBox11
        '
        Me.textBox11.Location = New System.Drawing.Point(6, 52)
        Me.textBox11.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox11.Multiline = True
        Me.textBox11.Name = "textBox11"
        Me.textBox11.Size = New System.Drawing.Size(215, 41)
        Me.textBox11.TabIndex = 16
        '
        'label21
        '
        Me.label21.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label21.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label21.Location = New System.Drawing.Point(230, 6)
        Me.label21.Name = "label21"
        Me.label21.Size = New System.Drawing.Size(215, 38)
        Me.label21.TabIndex = 3
        Me.label21.Text = "TAC(Hex)"
        Me.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label22
        '
        Me.label22.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label22.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.label22.Location = New System.Drawing.Point(6, 6)
        Me.label22.Name = "label22"
        Me.label22.Size = New System.Drawing.Size(214, 38)
        Me.label22.TabIndex = 2
        Me.label22.Text = "Cabinet"
        Me.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SourcePanel
        '
        Me.SourcePanel.BackColor = System.Drawing.Color.Transparent
        Me.SourcePanel.Controls.Add(Me.panel3)
        Me.SourcePanel.Location = New System.Drawing.Point(7, 4)
        Me.SourcePanel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.SourcePanel.Name = "SourcePanel"
        Me.SourcePanel.Size = New System.Drawing.Size(1250, 1084)
        Me.SourcePanel.TabIndex = 4
        '
        'panel3
        '
        Me.panel3.BackColor = System.Drawing.Color.DarkSalmon
        Me.panel3.Controls.Add(Me.button1)
        Me.panel3.Controls.Add(Me.ENBIdTextBox)
        Me.panel3.Controls.Add(Me.tableLayoutPanel13)
        Me.panel3.Controls.Add(Me.tableLayoutPanel14)
        Me.panel3.Controls.Add(Me.tableLayoutPanel15)
        Me.panel3.Controls.Add(Me.tableLayoutPanel16)
        Me.panel3.Controls.Add(Me.tableLayoutPanel17)
        Me.panel3.Controls.Add(Me.label40)
        Me.panel3.Controls.Add(Me.tableLayoutPanel18)
        Me.panel3.Controls.Add(Me.tableLayoutPanel19)
        Me.panel3.Controls.Add(Me.textBox41)
        Me.panel3.Location = New System.Drawing.Point(4, 574)
        Me.panel3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panel3.Name = "panel3"
        Me.panel3.Size = New System.Drawing.Size(1243, 510)
        Me.panel3.TabIndex = 2
        '
        'button1
        '
        Me.button1.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.button1.Location = New System.Drawing.Point(998, 45)
        Me.button1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(236, 46)
        Me.button1.TabIndex = 67
        Me.button1.Text = "FDD Audit"
        Me.button1.UseVisualStyleBackColor = True
        '
        'ENBIdTextBox
        '
        Me.ENBIdTextBox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ENBIdTextBox.Location = New System.Drawing.Point(79, 8)
        Me.ENBIdTextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ENBIdTextBox.Multiline = True
        Me.ENBIdTextBox.Name = "ENBIdTextBox"
        Me.ENBIdTextBox.Size = New System.Drawing.Size(336, 42)
        Me.ENBIdTextBox.TabIndex = 66
        Me.ENBIdTextBox.Text = "eNB ID 1 "
        Me.ENBIdTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tableLayoutPanel13
        '
        Me.tableLayoutPanel13.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tableLayoutPanel13.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel13.ColumnCount = 2
        Me.tableLayoutPanel13.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel13.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel13.Controls.Add(Me.textBox28, 0, 1)
        Me.tableLayoutPanel13.Controls.Add(Me.textBox29, 0, 0)
        Me.tableLayoutPanel13.Controls.Add(Me.textBox30, 1, 0)
        Me.tableLayoutPanel13.Controls.Add(Me.textBox31, 1, 1)
        Me.tableLayoutPanel13.Location = New System.Drawing.Point(78, 151)
        Me.tableLayoutPanel13.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tableLayoutPanel13.Name = "tableLayoutPanel13"
        Me.tableLayoutPanel13.RowCount = 2
        Me.tableLayoutPanel13.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel13.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel13.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tableLayoutPanel13.Size = New System.Drawing.Size(548, 84)
        Me.tableLayoutPanel13.TabIndex = 65
        '
        'textBox28
        '
        Me.textBox28.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox28.Location = New System.Drawing.Point(6, 45)
        Me.textBox28.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox28.Multiline = True
        Me.textBox28.Name = "textBox28"
        Me.textBox28.Size = New System.Drawing.Size(262, 30)
        Me.textBox28.TabIndex = 28
        Me.textBox28.Text = "LSMR IP"
        Me.textBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox29
        '
        Me.textBox29.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox29.Location = New System.Drawing.Point(6, 5)
        Me.textBox29.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox29.Multiline = True
        Me.textBox29.Name = "textBox29"
        Me.textBox29.Size = New System.Drawing.Size(262, 30)
        Me.textBox29.TabIndex = 29
        Me.textBox29.Text = "LSM Name"
        Me.textBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox30
        '
        Me.textBox30.Location = New System.Drawing.Point(278, 5)
        Me.textBox30.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox30.Multiline = True
        Me.textBox30.Name = "textBox30"
        Me.textBox30.Size = New System.Drawing.Size(264, 33)
        Me.textBox30.TabIndex = 16
        '
        'textBox31
        '
        Me.textBox31.Location = New System.Drawing.Point(278, 45)
        Me.textBox31.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox31.Multiline = True
        Me.textBox31.Name = "textBox31"
        Me.textBox31.Size = New System.Drawing.Size(264, 34)
        Me.textBox31.TabIndex = 16
        '
        'tableLayoutPanel14
        '
        Me.tableLayoutPanel14.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.tableLayoutPanel14.BackColor = System.Drawing.Color.Transparent
        Me.tableLayoutPanel14.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble
        Me.tableLayoutPanel14.ColumnCount = 2
        Me.tableLayoutPanel14.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel14.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel14.Controls.Add(Me.textBox32, 0, 0)
        Me.tableLayoutPanel14.Controls.Add(Me.textBox33, 0, 1)
        Me.tableLayoutPanel14.Controls.Add(Me.textBox34, 1, 0)
        Me.tableLayoutPanel14.Controls.Add(Me.textBox35, 1, 1)
        Me.tableLayoutPanel14.Location = New System.Drawing.Point(78, 60)
        Me.tableLayoutPanel14.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tableLayoutPanel14.Name = "tableLayoutPanel14"
        Me.tableLayoutPanel14.RowCount = 2
        Me.tableLayoutPanel14.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel14.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel14.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tableLayoutPanel14.Size = New System.Drawing.Size(548, 82)
        Me.tableLayoutPanel14.TabIndex = 64
        '
        'textBox32
        '
        Me.textBox32.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox32.Location = New System.Drawing.Point(6, 5)
        Me.textBox32.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox32.Multiline = True
        Me.textBox32.Name = "textBox32"
        Me.textBox32.Size = New System.Drawing.Size(262, 29)
        Me.textBox32.TabIndex = 27
        Me.textBox32.Text = "eNodeB Name"
        Me.textBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox33
        '
        Me.textBox33.BackColor = System.Drawing.Color.LemonChiffon
        Me.textBox33.Location = New System.Drawing.Point(6, 44)
        Me.textBox33.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox33.Multiline = True
        Me.textBox33.Name = "textBox33"
        Me.textBox33.Size = New System.Drawing.Size(262, 30)
        Me.textBox33.TabIndex = 26
        Me.textBox33.Text = "eNodeB ID"
        Me.textBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'textBox34
        '
        Me.textBox34.Location = New System.Drawing.Point(278, 5)
        Me.textBox34.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox34.Multiline = True
        Me.textBox34.Name = "textBox34"
        Me.textBox34.Size = New System.Drawing.Size(264, 32)
        Me.textBox34.TabIndex = 16
        '
        'textBox35
        '
        Me.textBox35.Location = New System.Drawing.Point(278, 44)
        Me.textBox35.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox35.Multiline = True
        Me.textBox35.Name = "textBox35"
        Me.textBox35.Size = New System.Drawing.Size(264, 33)
        Me.textBox35.TabIndex = 16
        '
        'label40
        '
        Me.label40.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.label40.BackColor = System.Drawing.Color.DarkGray
        Me.label40.Location = New System.Drawing.Point(660, 350)
        Me.label40.Name = "label40"
        Me.label40.Size = New System.Drawing.Size(569, 35)
        Me.label40.TabIndex = 60
        Me.label40.Text = "4G IP Plan"
        Me.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tableLayoutPanel18
        '
        Me.tableLayoutPanel18.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.tableLayoutPanel18.ColumnCount = 4
        Me.tableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 122.0!))
        Me.tableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 168.0!))
        Me.tableLayoutPanel18.Controls.Add(Me.TextBox50, 0, 3)
        Me.tableLayoutPanel18.Controls.Add(Me.label41, 0, 1)
        Me.tableLayoutPanel18.Controls.Add(Me.label42, 2, 0)
        Me.tableLayoutPanel18.Controls.Add(Me.label43, 3, 0)
        Me.tableLayoutPanel18.Controls.Add(Me.label44, 0, 0)
        Me.tableLayoutPanel18.Controls.Add(Me.label45, 1, 0)
        Me.tableLayoutPanel18.Controls.Add(Me.label47, 0, 2)
        Me.tableLayoutPanel18.Controls.Add(Me.TextBox42, 1, 1)
        Me.tableLayoutPanel18.Controls.Add(Me.TextBox43, 2, 1)
        Me.tableLayoutPanel18.Controls.Add(Me.TextBox44, 3, 1)
        Me.tableLayoutPanel18.Controls.Add(Me.TextBox45, 1, 3)
        Me.tableLayoutPanel18.Controls.Add(Me.TextBox46, 1, 2)
        Me.tableLayoutPanel18.Controls.Add(Me.TextBox47, 2, 2)
        Me.tableLayoutPanel18.Controls.Add(Me.TextBox48, 3, 2)
        Me.tableLayoutPanel18.Controls.Add(Me.TextBox49, 2, 3)
        Me.tableLayoutPanel18.Controls.Add(Me.label46, 0, 3)
        Me.tableLayoutPanel18.Location = New System.Drawing.Point(73, 352)
        Me.tableLayoutPanel18.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tableLayoutPanel18.Name = "tableLayoutPanel18"
        Me.tableLayoutPanel18.RowCount = 4
        Me.tableLayoutPanel18.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 58.33333!))
        Me.tableLayoutPanel18.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.66667!))
        Me.tableLayoutPanel18.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28.0!))
        Me.tableLayoutPanel18.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26.0!))
        Me.tableLayoutPanel18.Size = New System.Drawing.Size(576, 146)
        Me.tableLayoutPanel18.TabIndex = 58
        '
        'TextBox50
        '
        Me.TextBox50.Location = New System.Drawing.Point(145, 120)
        Me.TextBox50.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox50.Multiline = True
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(134, 23)
        Me.TextBox50.TabIndex = 25
        '
        'label41
        '
        Me.label41.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label41.BackColor = System.Drawing.Color.OldLace
        Me.label41.Location = New System.Drawing.Point(4, 57)
        Me.label41.Name = "label41"
        Me.label41.Size = New System.Drawing.Size(134, 26)
        Me.label41.TabIndex = 8
        Me.label41.Text = "Alpha"
        Me.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label42
        '
        Me.label42.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label42.BackColor = System.Drawing.Color.DarkGray
        Me.label42.Location = New System.Drawing.Point(286, 7)
        Me.label42.Name = "label42"
        Me.label42.Size = New System.Drawing.Size(115, 38)
        Me.label42.TabIndex = 7
        Me.label42.Text = "RACH"
        Me.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label43
        '
        Me.label43.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label43.BackColor = System.Drawing.Color.DarkGray
        Me.label43.Location = New System.Drawing.Point(422, 7)
        Me.label43.Name = "label43"
        Me.label43.Size = New System.Drawing.Size(136, 38)
        Me.label43.TabIndex = 6
        Me.label43.Text = "Tilt"
        Me.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label44
        '
        Me.label44.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label44.BackColor = System.Drawing.Color.DarkGray
        Me.label44.Location = New System.Drawing.Point(4, 7)
        Me.label44.Name = "label44"
        Me.label44.Size = New System.Drawing.Size(134, 38)
        Me.label44.TabIndex = 5
        Me.label44.Text = "Sector"
        Me.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label45
        '
        Me.label45.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label45.BackColor = System.Drawing.Color.DarkGray
        Me.label45.Location = New System.Drawing.Point(145, 7)
        Me.label45.Name = "label45"
        Me.label45.Size = New System.Drawing.Size(134, 38)
        Me.label45.TabIndex = 4
        Me.label45.Text = "PCI"
        Me.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label47
        '
        Me.label47.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label47.BackColor = System.Drawing.Color.OldLace
        Me.label47.Location = New System.Drawing.Point(4, 93)
        Me.label47.Name = "label47"
        Me.label47.Size = New System.Drawing.Size(134, 20)
        Me.label47.TabIndex = 9
        Me.label47.Text = "Beta"
        Me.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox42
        '
        Me.TextBox42.Location = New System.Drawing.Point(145, 54)
        Me.TextBox42.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox42.Multiline = True
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(134, 32)
        Me.TextBox42.TabIndex = 17
        '
        'TextBox43
        '
        Me.TextBox43.Location = New System.Drawing.Point(286, 54)
        Me.TextBox43.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox43.Multiline = True
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(114, 32)
        Me.TextBox43.TabIndex = 18
        '
        'TextBox44
        '
        Me.TextBox44.Location = New System.Drawing.Point(409, 54)
        Me.TextBox44.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox44.Multiline = True
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Size = New System.Drawing.Size(157, 28)
        Me.TextBox44.TabIndex = 19
        '
        'TextBox45
        '
        Me.TextBox45.Location = New System.Drawing.Point(286, 120)
        Me.TextBox45.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox45.Multiline = True
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Size = New System.Drawing.Size(114, 23)
        Me.TextBox45.TabIndex = 20
        '
        'TextBox46
        '
        Me.TextBox46.Location = New System.Drawing.Point(145, 91)
        Me.TextBox46.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox46.Multiline = True
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Size = New System.Drawing.Size(134, 24)
        Me.TextBox46.TabIndex = 21
        '
        'TextBox47
        '
        Me.TextBox47.Location = New System.Drawing.Point(286, 91)
        Me.TextBox47.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox47.Multiline = True
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(114, 24)
        Me.TextBox47.TabIndex = 22
        '
        'TextBox48
        '
        Me.TextBox48.Location = New System.Drawing.Point(409, 91)
        Me.TextBox48.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox48.Multiline = True
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(157, 22)
        Me.TextBox48.TabIndex = 23
        '
        'TextBox49
        '
        Me.TextBox49.Location = New System.Drawing.Point(409, 120)
        Me.TextBox49.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox49.Multiline = True
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Size = New System.Drawing.Size(157, 22)
        Me.TextBox49.TabIndex = 24
        '
        'label46
        '
        Me.label46.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label46.BackColor = System.Drawing.Color.OldLace
        Me.label46.Location = New System.Drawing.Point(4, 121)
        Me.label46.Name = "label46"
        Me.label46.Size = New System.Drawing.Size(134, 21)
        Me.label46.TabIndex = 10
        Me.label46.Text = "Gamma"
        Me.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tableLayoutPanel19
        '
        Me.tableLayoutPanel19.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tableLayoutPanel19.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.tableLayoutPanel19.ColumnCount = 2
        Me.tableLayoutPanel19.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.45454!))
        Me.tableLayoutPanel19.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.54546!))
        Me.tableLayoutPanel19.Controls.Add(Me.label48, 0, 3)
        Me.tableLayoutPanel19.Controls.Add(Me.label49, 0, 0)
        Me.tableLayoutPanel19.Controls.Add(Me.label50, 0, 1)
        Me.tableLayoutPanel19.Controls.Add(Me.label51, 0, 2)
        Me.tableLayoutPanel19.Controls.Add(Me.TextBox51, 1, 0)
        Me.tableLayoutPanel19.Controls.Add(Me.TextBox52, 1, 1)
        Me.tableLayoutPanel19.Controls.Add(Me.TextBox53, 1, 2)
        Me.tableLayoutPanel19.Controls.Add(Me.TextBox54, 1, 3)
        Me.tableLayoutPanel19.Location = New System.Drawing.Point(657, 384)
        Me.tableLayoutPanel19.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tableLayoutPanel19.Name = "tableLayoutPanel19"
        Me.tableLayoutPanel19.RowCount = 4
        Me.tableLayoutPanel19.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tableLayoutPanel19.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tableLayoutPanel19.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tableLayoutPanel19.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.tableLayoutPanel19.Size = New System.Drawing.Size(564, 116)
        Me.tableLayoutPanel19.TabIndex = 59
        '
        'label48
        '
        Me.label48.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label48.BackColor = System.Drawing.Color.OldLace
        Me.label48.Location = New System.Drawing.Point(4, 85)
        Me.label48.Name = "label48"
        Me.label48.Size = New System.Drawing.Size(248, 30)
        Me.label48.TabIndex = 12
        Me.label48.Text = "MMBS S&B IP"
        Me.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label49
        '
        Me.label49.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label49.BackColor = System.Drawing.Color.OldLace
        Me.label49.Location = New System.Drawing.Point(4, 1)
        Me.label49.Name = "label49"
        Me.label49.Size = New System.Drawing.Size(248, 27)
        Me.label49.TabIndex = 9
        Me.label49.Text = "CSROAMIP"
        Me.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label50
        '
        Me.label50.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label50.BackColor = System.Drawing.Color.OldLace
        Me.label50.Location = New System.Drawing.Point(4, 29)
        Me.label50.Name = "label50"
        Me.label50.Size = New System.Drawing.Size(248, 27)
        Me.label50.TabIndex = 10
        Me.label50.Text = "MMBS OAMIP"
        Me.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label51
        '
        Me.label51.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.label51.BackColor = System.Drawing.Color.OldLace
        Me.label51.Location = New System.Drawing.Point(4, 57)
        Me.label51.Name = "label51"
        Me.label51.Size = New System.Drawing.Size(248, 27)
        Me.label51.TabIndex = 11
        Me.label51.Text = "CSR&BIP "
        Me.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox51
        '
        Me.TextBox51.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox51.Location = New System.Drawing.Point(259, 3)
        Me.TextBox51.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox51.Multiline = True
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(300, 23)
        Me.TextBox51.TabIndex = 19
        '
        'TextBox52
        '
        Me.TextBox52.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox52.Location = New System.Drawing.Point(259, 31)
        Me.TextBox52.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox52.Multiline = True
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(300, 23)
        Me.TextBox52.TabIndex = 20
        '
        'TextBox53
        '
        Me.TextBox53.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox53.Location = New System.Drawing.Point(259, 59)
        Me.TextBox53.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox53.Multiline = True
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.Size = New System.Drawing.Size(300, 23)
        Me.TextBox53.TabIndex = 21
        '
        'TextBox54
        '
        Me.TextBox54.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox54.Location = New System.Drawing.Point(259, 87)
        Me.TextBox54.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox54.Multiline = True
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.Size = New System.Drawing.Size(300, 26)
        Me.TextBox54.TabIndex = 22
        '
        'textBox41
        '
        Me.textBox41.BackColor = System.Drawing.Color.White
        Me.textBox41.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textBox41.Location = New System.Drawing.Point(11, 8)
        Me.textBox41.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.textBox41.Multiline = True
        Me.textBox41.Name = "textBox41"
        Me.textBox41.Size = New System.Drawing.Size(59, 492)
        Me.textBox41.TabIndex = 57
        Me.textBox41.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "F" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "D" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "D"
        Me.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CDU30
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(1836, 1021)
        Me.Controls.Add(Me.TargetPanel)
        Me.Controls.Add(Me.panel2)
        Me.Controls.Add(Me.SourcePanel)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "CDU30"
        Me.Text = "CDU30 Source - Target"
        Me.tableLayoutPanel4.ResumeLayout(False)
        Me.tableLayoutPanel4.PerformLayout()
        Me.tableLayoutPanel3.ResumeLayout(False)
        Me.tableLayoutPanel3.PerformLayout()
        Me.name_id.ResumeLayout(False)
        Me.name_id.PerformLayout()
        Me.tableLayoutPanel6.ResumeLayout(False)
        Me.tableLayoutPanel6.PerformLayout()
        Me.tableLayoutPanel5.ResumeLayout(False)
        Me.tableLayoutPanel5.PerformLayout()
        Me.tableLayoutPanel2.ResumeLayout(False)
        Me.tableLayoutPanel2.PerformLayout()
        Me.TargetPanel.ResumeLayout(False)
        Me.TargetPanel.PerformLayout()
        Me.Name_idTable.ResumeLayout(False)
        Me.Name_idTable.PerformLayout()
        Me.tableLayoutPanel1.ResumeLayout(False)
        Me.tableLayoutPanel1.PerformLayout()
        Me.tableLayoutPanel17.ResumeLayout(False)
        Me.tableLayoutPanel17.PerformLayout()
        Me.tableLayoutPanel16.ResumeLayout(False)
        Me.tableLayoutPanel16.PerformLayout()
        Me.tableLayoutPanel15.ResumeLayout(False)
        Me.tableLayoutPanel15.PerformLayout()
        Me.panel2.ResumeLayout(False)
        Me.panel2.PerformLayout()
        Me.TableLayoutPanel12.ResumeLayout(False)
        Me.TableLayoutPanel12.PerformLayout()
        Me.TableLayoutPanel11.ResumeLayout(False)
        Me.TableLayoutPanel11.PerformLayout()
        Me.tableLayoutPanel7.ResumeLayout(False)
        Me.tableLayoutPanel7.PerformLayout()
        Me.tableLayoutPanel8.ResumeLayout(False)
        Me.tableLayoutPanel8.PerformLayout()
        Me.tableLayoutPanel9.ResumeLayout(False)
        Me.tableLayoutPanel9.PerformLayout()
        Me.tableLayoutPanel10.ResumeLayout(False)
        Me.tableLayoutPanel10.PerformLayout()
        Me.SourcePanel.ResumeLayout(False)
        Me.panel3.ResumeLayout(False)
        Me.panel3.PerformLayout()
        Me.tableLayoutPanel13.ResumeLayout(False)
        Me.tableLayoutPanel13.PerformLayout()
        Me.tableLayoutPanel14.ResumeLayout(False)
        Me.tableLayoutPanel14.PerformLayout()
        Me.tableLayoutPanel18.ResumeLayout(False)
        Me.tableLayoutPanel18.PerformLayout()
        Me.tableLayoutPanel19.ResumeLayout(False)
        Me.tableLayoutPanel19.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents TacTextBox As TextBox
    Private WithEvents tableLayoutPanel4 As TableLayoutPanel
    Private WithEvents textBox18 As TextBox
    Private WithEvents textBox19 As TextBox
    Private WithEvents label8 As Label
    Private WithEvents label7 As Label
    Private WithEvents textBox24 As TextBox
    Private WithEvents textBox23 As TextBox
    Private WithEvents LsmNameTextbox As TextBox
    Private WithEvents LsmrIpTextbox As TextBox
    Private WithEvents ENodeBName_label As TextBox
    Private WithEvents textBox20 As TextBox
    Private WithEvents ENodeBIdTextbox As TextBox
    Private WithEvents tableLayoutPanel3 As TableLayoutPanel
    Private WithEvents textBox17 As TextBox
    Private WithEvents textBox15 As TextBox
    Private WithEvents textBox14 As TextBox
    Private WithEvents textBox2 As TextBox
    Private WithEvents textBox3 As TextBox
    Private WithEvents textBox12 As TextBox
    Private WithEvents textBox13 As TextBox
    Private WithEvents textBox16 As TextBox
    Private WithEvents ENBID1_search As Button
    Private WithEvents ENodeBNameTextbox As TextBox
    Private WithEvents CabinetTextBox As TextBox
    Private WithEvents label30 As Label
    Private WithEvents name_id As TableLayoutPanel
    Private WithEvents textBox22 As TextBox
    Private WithEvents textBox25 As TextBox
    Private WithEvents textBox26 As TextBox
    Private WithEvents textBox27 As TextBox
    Private WithEvents tableLayoutPanel6 As TableLayoutPanel
    Private WithEvents label17 As Label
    Private WithEvents label16 As Label
    Private WithEvents label15 As Label
    Private WithEvents label14 As Label
    Private WithEvents label13 As Label
    Private WithEvents label12 As Label
    Private WithEvents label11 As Label
    Private WithEvents label9 As Label
    Private WithEvents label4 As Label
    Private WithEvents label3 As Label
    Private WithEvents label1 As Label
    Private WithEvents label2 As Label
    Private WithEvents TddLabel As TextBox
    Private WithEvents label5 As Label
    Private WithEvents tableLayoutPanel5 As TableLayoutPanel
    Private WithEvents textBox21 As TextBox
    Private WithEvents label10 As Label
    Private WithEvents label6 As Label
    Private WithEvents cdu30Grow_Button As Button
    Private WithEvents tableLayoutPanel2 As TableLayoutPanel
    Private WithEvents TargetPanel As Panel
    Private WithEvents Cdu30Env_button As Button
    Private WithEvents Cdu30Atp As Button
    Private WithEvents Cdu30Comm_Button As Button
    Private WithEvents Cdu30Audit_Button As Button
    Private WithEvents Name_idTable As TableLayoutPanel
    Private WithEvents tableLayoutPanel1 As TableLayoutPanel
    Private WithEvents textBox39 As TextBox
    Private WithEvents textBox40 As TextBox
    Private WithEvents label38 As Label
    Private WithEvents label39 As Label
    Private WithEvents tableLayoutPanel17 As TableLayoutPanel
    Private WithEvents textBox38 As TextBox
    Private WithEvents label37 As Label
    Private WithEvents tableLayoutPanel16 As TableLayoutPanel
    Private WithEvents tableLayoutPanel15 As TableLayoutPanel
    Private WithEvents textBox36 As TextBox
    Private WithEvents textBox37 As TextBox
    Private WithEvents label35 As Label
    Private WithEvents label36 As Label
    Private WithEvents panel2 As Panel
    Private WithEvents button2 As Button
    Private WithEvents ENBIdName As TextBox
    Private WithEvents tableLayoutPanel7 As TableLayoutPanel
    Private WithEvents textBox1 As TextBox
    Private WithEvents textBox4 As TextBox
    Private WithEvents textBox8 As TextBox
    Private WithEvents textBox7 As TextBox
    Private WithEvents tableLayoutPanel8 As TableLayoutPanel
    Private WithEvents textBox5 As TextBox
    Private WithEvents label18 As Label
    Private WithEvents tableLayoutPanel9 As TableLayoutPanel
    Private WithEvents textBox6 As TextBox
    Private WithEvents textBox9 As TextBox
    Private WithEvents label19 As Label
    Private WithEvents label20 As Label
    Private WithEvents tableLayoutPanel10 As TableLayoutPanel
    Private WithEvents textBox10 As TextBox
    Private WithEvents textBox11 As TextBox
    Private WithEvents label21 As Label
    Private WithEvents label22 As Label
    Private WithEvents SourcePanel As Panel
    Private WithEvents panel3 As Panel
    Private WithEvents button1 As Button
    Private WithEvents ENBIdTextBox As TextBox
    Private WithEvents tableLayoutPanel13 As TableLayoutPanel
    Private WithEvents textBox28 As TextBox
    Private WithEvents textBox29 As TextBox
    Private WithEvents textBox30 As TextBox
    Private WithEvents textBox31 As TextBox
    Private WithEvents tableLayoutPanel14 As TableLayoutPanel
    Private WithEvents textBox32 As TextBox
    Private WithEvents textBox33 As TextBox
    Private WithEvents textBox34 As TextBox
    Private WithEvents textBox35 As TextBox
    Private WithEvents textBox41 As TextBox
    Private WithEvents TableLayoutPanel12 As TableLayoutPanel
    Private WithEvents Label31 As Label
    Private WithEvents Label32 As Label
    Private WithEvents Label33 As Label
    Private WithEvents Label34 As Label
    Private WithEvents TextBox64 As TextBox
    Private WithEvents TextBox65 As TextBox
    Private WithEvents TextBox66 As TextBox
    Private WithEvents TextBox67 As TextBox
    Private WithEvents TableLayoutPanel11 As TableLayoutPanel
    Private WithEvents TextBox55 As TextBox
    Private WithEvents Label23 As Label
    Private WithEvents Label24 As Label
    Private WithEvents Label25 As Label
    Private WithEvents Label26 As Label
    Private WithEvents Label27 As Label
    Private WithEvents Label28 As Label
    Private WithEvents TextBox56 As TextBox
    Private WithEvents TextBox57 As TextBox
    Private WithEvents TextBox58 As TextBox
    Private WithEvents TextBox59 As TextBox
    Private WithEvents TextBox60 As TextBox
    Private WithEvents TextBox61 As TextBox
    Private WithEvents TextBox62 As TextBox
    Private WithEvents TextBox63 As TextBox
    Private WithEvents Label29 As Label
    Private WithEvents label40 As Label
    Private WithEvents tableLayoutPanel18 As TableLayoutPanel
    Private WithEvents TextBox50 As TextBox
    Private WithEvents label41 As Label
    Private WithEvents label42 As Label
    Private WithEvents label43 As Label
    Private WithEvents label44 As Label
    Private WithEvents label45 As Label
    Private WithEvents label47 As Label
    Private WithEvents TextBox42 As TextBox
    Private WithEvents TextBox43 As TextBox
    Private WithEvents TextBox44 As TextBox
    Private WithEvents TextBox45 As TextBox
    Private WithEvents TextBox46 As TextBox
    Private WithEvents TextBox47 As TextBox
    Private WithEvents TextBox48 As TextBox
    Private WithEvents TextBox49 As TextBox
    Private WithEvents label46 As Label
    Private WithEvents tableLayoutPanel19 As TableLayoutPanel
    Private WithEvents label48 As Label
    Private WithEvents label49 As Label
    Private WithEvents label50 As Label
    Private WithEvents label51 As Label
    Private WithEvents TextBox51 As TextBox
    Private WithEvents TextBox52 As TextBox
    Private WithEvents TextBox53 As TextBox
    Private WithEvents TextBox54 As TextBox
    Friend WithEvents TextBox259 As TextBox
    Friend WithEvents TextBox258 As TextBox
    Friend WithEvents TextBox257 As TextBox
    Friend WithEvents TextBox256 As TextBox
    Friend WithEvents TextBox255 As TextBox
    Friend WithEvents TextBox254 As TextBox
    Friend WithEvents TextBox253 As TextBox
    Friend WithEvents TextBox252 As TextBox
    Friend WithEvents TextBox251 As TextBox
    Friend WithEvents TextBox250 As TextBox
    Friend WithEvents TextBox249 As TextBox
    Friend WithEvents TextBox248 As TextBox
    Friend WithEvents TextBox247 As TextBox
    Friend WithEvents TextBox246 As TextBox
    Friend WithEvents TextBox245 As TextBox
    Friend WithEvents TextBox244 As TextBox
    Friend WithEvents TextBox243 As TextBox
    Friend WithEvents TextBox242 As TextBox
    Friend WithEvents TextBox241 As TextBox
    Friend WithEvents TextBox240 As TextBox
    Friend WithEvents TextBox239 As TextBox
    Friend WithEvents TextBox238 As TextBox
    Friend WithEvents TextBox237 As TextBox
    Friend WithEvents TextBox236 As TextBox
    Friend WithEvents TextBox235 As TextBox
    Friend WithEvents TextBox234 As TextBox
    Friend WithEvents TextBox233 As TextBox
    Friend WithEvents TextBox232 As TextBox
    Friend WithEvents TextBox231 As TextBox
    Friend WithEvents TextBox230 As TextBox
    Friend WithEvents TextBox229 As TextBox
    Friend WithEvents TextBox228 As TextBox
    Friend WithEvents TextBox227 As TextBox
    Friend WithEvents TextBox226 As TextBox
    Friend WithEvents TextBox225 As TextBox
    Friend WithEvents TextBox224 As TextBox
    Friend WithEvents TextBox223 As TextBox
    Friend WithEvents TextBox222 As TextBox
    Friend WithEvents TextBox221 As TextBox
    Friend WithEvents TextBox220 As TextBox
    Friend WithEvents TextBox219 As TextBox
    Friend WithEvents TextBox218 As TextBox
    Friend WithEvents TextBox217 As TextBox
    Friend WithEvents TextBox216 As TextBox
    Friend WithEvents TextBox215 As TextBox
    Friend WithEvents TextBox214 As TextBox
    Friend WithEvents TextBox213 As TextBox
    Friend WithEvents TextBox212 As TextBox
    Friend WithEvents TextBox211 As TextBox
    Friend WithEvents TextBox210 As TextBox
    Friend WithEvents TextBox209 As TextBox
    Friend WithEvents TextBox208 As TextBox
    Friend WithEvents TextBox207 As TextBox
    Friend WithEvents TextBox206 As TextBox
    Friend WithEvents TextBox205 As TextBox
    Friend WithEvents TextBox204 As TextBox
    Friend WithEvents TextBox203 As TextBox
    Friend WithEvents TextBox202 As TextBox
    Friend WithEvents TextBox201 As TextBox
    Friend WithEvents TextBox200 As TextBox
    Friend WithEvents TextBox199 As TextBox
    Friend WithEvents TextBox198 As TextBox
    Friend WithEvents TextBox197 As TextBox
    Friend WithEvents TextBox196 As TextBox
    Friend WithEvents TextBox195 As TextBox
    Friend WithEvents TextBox194 As TextBox
    Friend WithEvents TextBox193 As TextBox
    Friend WithEvents TextBox192 As TextBox
    Friend WithEvents TextBox191 As TextBox
    Friend WithEvents TextBox190 As TextBox
    Friend WithEvents TextBox189 As TextBox
    Friend WithEvents TextBox188 As TextBox
    Friend WithEvents TextBox187 As TextBox
    Friend WithEvents TextBox186 As TextBox
    Friend WithEvents TextBox185 As TextBox
    Friend WithEvents TextBox184 As TextBox
    Friend WithEvents TextBox183 As TextBox
    Friend WithEvents TextBox182 As TextBox
    Friend WithEvents TextBox181 As TextBox
    Friend WithEvents TextBox180 As TextBox
    Friend WithEvents TextBox179 As TextBox
    Friend WithEvents TextBox178 As TextBox
    Friend WithEvents TextBox177 As TextBox
    Friend WithEvents TextBox176 As TextBox
    Friend WithEvents TextBox175 As TextBox
    Friend WithEvents TextBox174 As TextBox
    Friend WithEvents TextBox173 As TextBox
    Friend WithEvents TextBox172 As TextBox
    Friend WithEvents TextBox171 As TextBox
    Friend WithEvents TextBox170 As TextBox
    Friend WithEvents TextBox169 As TextBox
    Friend WithEvents TextBox168 As TextBox
    Friend WithEvents TextBox167 As TextBox
    Friend WithEvents TextBox166 As TextBox
    Friend WithEvents TextBox165 As TextBox
    Friend WithEvents TextBox164 As TextBox
    Friend WithEvents TextBox163 As TextBox
    Friend WithEvents TextBox162 As TextBox
    Friend WithEvents TextBox161 As TextBox
    Friend WithEvents TextBox160 As TextBox
    Friend WithEvents TextBox159 As TextBox
    Friend WithEvents TextBox158 As TextBox
    Friend WithEvents TextBox157 As TextBox
    Friend WithEvents TextBox156 As TextBox
    Friend WithEvents TextBox155 As TextBox
    Friend WithEvents TextBox154 As TextBox
    Friend WithEvents TextBox153 As TextBox
    Friend WithEvents TextBox152 As TextBox
    Friend WithEvents TextBox151 As TextBox
    Friend WithEvents TextBox150 As TextBox
    Friend WithEvents TextBox149 As TextBox
    Friend WithEvents TextBox148 As TextBox
    Friend WithEvents TextBox147 As TextBox
    Friend WithEvents TextBox146 As TextBox
    Friend WithEvents TextBox145 As TextBox
    Friend WithEvents TextBox144 As TextBox
    Friend WithEvents TextBox143 As TextBox
    Friend WithEvents TextBox142 As TextBox
    Friend WithEvents TextBox141 As TextBox
    Friend WithEvents TextBox140 As TextBox
    Friend WithEvents TextBox139 As TextBox
    Friend WithEvents TextBox138 As TextBox
    Friend WithEvents TextBox137 As TextBox
    Friend WithEvents TextBox136 As TextBox
    Friend WithEvents TextBox135 As TextBox
    Friend WithEvents TextBox134 As TextBox
    Friend WithEvents TextBox133 As TextBox
    Friend WithEvents TextBox132 As TextBox
    Friend WithEvents TextBox131 As TextBox
    Friend WithEvents TextBox130 As TextBox
    Friend WithEvents TextBox129 As TextBox
    Friend WithEvents TextBox128 As TextBox
    Friend WithEvents TextBox127 As TextBox
    Friend WithEvents TextBox126 As TextBox
    Friend WithEvents TextBox125 As TextBox
    Friend WithEvents TextBox124 As TextBox
    Friend WithEvents TextBox123 As TextBox
    Friend WithEvents TextBox122 As TextBox
    Friend WithEvents TextBox121 As TextBox
    Friend WithEvents TextBox120 As TextBox
    Friend WithEvents TextBox119 As TextBox
    Friend WithEvents TextBox118 As TextBox
    Friend WithEvents TextBox117 As TextBox
    Friend WithEvents TextBox116 As TextBox
    Friend WithEvents ENBID1TextBox As TextBox
End Class
