﻿Imports System.IO
Public Class Form5
    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ''here i load the user list in
        Try
            Dim reader As StreamReader = My.Computer.FileSystem.OpenTextFileReader("userfile.txt")
            Dim a As String

            Do
                a = reader.ReadLine
                ListBox1.Items.Add(a)
            Loop Until a Is Nothing

            reader.Close()
        Catch
        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ListBox1.Items.Add(TextBox1.Text)
        writeFile()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        ListBox1.Items.Clear()
        writeFile()


    End Sub

    Public Sub writeFile()
        ''now rewrite file..
        Try
            Dim writer As StreamWriter = My.Computer.FileSystem.OpenTextFileWriter("userfile.txt", False)
            Dim a As String
            If ListBox1.Items.Count > 0 Then
                For i = 0 To ListBox1.Items.Count - 1
                    writer.WriteLine(ListBox1.Items.Item(i))
                Next
            End If

            writer.Close()
        Catch
        End Try
    End Sub
End Class