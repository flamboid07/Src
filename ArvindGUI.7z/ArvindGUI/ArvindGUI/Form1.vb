﻿Imports System.IO
Public Class Form1
    'login form
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ''check username
        Dim users As New Collection
        'users.Add("jim", "jim")
        'users.Add("bill", "bill")
        'users.Add("bob", "bob")
        users.Add("Ashur", "Ashur")
        users.Add("Praseeda", "Praseeda")
        users.Add("Arvind", "Arvind")
        users.Add("Suruchi", "Suruchi")
        users.Add("Renee", "Renne")
        users.Add("Vijay", "Vijay")

        ''get users from file..
        Dim reader As StreamReader
        Try
            reader = My.Computer.FileSystem.OpenTextFileReader("userfile.txt")
            Dim a As String

            Do
                a = reader.ReadLine
                users.Add(a, a)
            Loop Until a Is Nothing

            reader.Close()
        Catch
        End Try

        If users.Contains(TextBox1.Text) Then
            ''check password
            If TextBox2.Text = "password" Then
                ''load home screen
                Form2.Show()
                Me.Close()
            Else
                MsgBox("incorrect login details")
            End If
        Else
            MsgBox("incorrect login details")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim pwd = InputBox("admin password?")
        If pwd = "password" Then
            Form5.Show()

        End If
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged



    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
